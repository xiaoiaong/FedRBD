# FedBiCert

FedBiCert implements one-shot bidirectional knowledge transfer under data and
model heterogeneity.

## Protocol

1. Every client trains locally and reserves a deterministic 10% validation
   split.
2. Every client uploads one model checkpoint, one calibrated risk certificate,
   and optional client-side synthetic anchors generated locally by
   same-class mixup/mosaic and model-confidence filtering.
3. The server starts from an independent random initialization.
4. The server trains with uploaded synthetic anchors plus server-generated
   coverage/inversion queries through sample-level certified routing.
5. The server broadcasts its model and the synthetic query bank once.
6. Every client performs locally gated distillation and sends nothing back.

The server never copies, averages, blends, or loads client parameters.
Client checkpoints are selected using local validation only.

## Requirements

- Python 3.9 or later
- PyTorch with CUDA support
- torchvision
- numpy
- tqdm
- matplotlib

Run commands from this directory:

```powershell
cd C:\Users\xiaoi\Documents\oneshot\oneshot_src\oneshot
```

## One-command experiments

CIFAR10, CNN3, five clients, Dirichlet alpha 0.1:

```powershell
.\run\run_fedbicert.ps1 -Dataset cifar10 -Seed 1
```

If PowerShell script execution is disabled, use the CMD entry:

```bat
run\run_fedbicert.cmd cifar10 1 1
```

SVHN:

```powershell
.\run\run_fedbicert.ps1 -Dataset svhn -Seed 1
```

```bat
run\run_fedbicert.cmd svhn 1 1
```

## Rerun V2 without client pretraining

If the V1 client checkpoint already exists, rerun only the corrected server
and downlink stages:

```bat
run\run_fedbicert_v2_distill.cmd cifar10 1 0
```

The first diagnostics to inspect are:

```text
[FedBiCert][Diagnostic only; never used for selection]
[FedBiCert][Router]
[FedBiCert][QueryBank]
```

`class_owner_oracle` or `certified_oracle` below 50% indicates that the
available client knowledge or routing remains insufficient. Query-bank target
and augmented target accuracy should both be high before interpreting server
distillation results.

Three seeds on both datasets:

```powershell
.\run\run_fedbicert_all.ps1 -Seeds 1,2,3 -Strict 0
```

`-Strict 1` raises an error when the requested accuracy or strict client
improvement is not reached. Checkpoints and the report are saved before that
error is raised.

## Heterogeneous models

V3 setting with a ResNet18 server and heterogeneous clients
`cnn3,lenet,vgg,googlenet,resnet18`:

```powershell
.\run\run_fedbicert_v3_hetero_pretrain.ps1 -Dataset cifar10 -Seed 1
.\run\run_fedbicert_v3_hetero_distill.ps1 -Dataset cifar10 -Seed 1 -Strict 0
```

```bat
run\run_fedbicert_v3_hetero_pretrain.cmd cifar10 1
run\run_fedbicert_v3_hetero_distill.cmd cifar10 1 0
```

For SVHN, replace `cifar10` with `svhn`; the script uses a server target of
62%.

## Communication-round study (CIFAR-10, beta 0.5)

Run the 1, 2, 3, 4, and 5 communication-round experiments with clients
`GoogleNet, ResNet18, CNN2, CNN3, LeNet`, a ResNet18 server, and exactly 100
total local-training epochs:

```bash
bash run_fedbicert_cifar10_comm_rounds_1to5.sh
```

Run only one setting, for example the two-communication experiment:

```bash
COMM_ROUNDS=2 bash run_fedbicert_cifar10_comm_rounds_1to5.sh
```

Use `SWANLAB_PROJECT_NAME` to override the SwanLab project. Do not export
`SWANLAB_PROJECT`; SwanLab itself reserves that environment variable for its
settings parser.

The local epoch ranges are:

- 1 round: `1-100`
- 2 rounds: `1-50`, `51-100`
- 3 rounds: `1-33`, `34-66`, `67-100`
- 4 rounds: `1-25`, `26-50`, `51-75`, `76-100`
- 5 rounds: `1-20`, `21-40`, `41-60`, `61-80`, `81-100`

The total anchor-warmup budget is 120 epochs and the total client-downlink
budget is 80 epochs. Both are divided across communication rounds, while each
server uplink-distillation stage retains its proxy-based early stopping with
`bicert_patience=16` and a maximum of 200 epochs. For example, two
communications use `60 + 60` warmup epochs and `40 + 40` downlink epochs.
Server distillation accuracy keeps the existing SwanLab keys
`server/uplink/test_acc` and `compare/server_distill_test_acc`. Each later
communication starts at the step immediately after the previous round's actual
early-stopped epoch count, so both keys remain one continuous curve.

SwanLab creates five independent runs, one for each communication-count
setting. Within a setting, all local-train/distill stages resume that setting's
run. The experiment name, group, and run ID use
`fedbicert_cifar10_hetero5_beta05_comm{1..5}_seed{seed}`.

At every boundary the clients upload their current heterogeneous models and
risk certificates. FedBiCert continues the ResNet18 server from its previous
round, performs server distillation, and saves the downlinked heterogeneous
client states. The following local segment starts from those client states.
All five experiments reuse one saved Dirichlet split so that the communication
count is the only changed variable. `CNN2` is the command-line alias for this
repository's existing `two_layer` model. The runner writes the final accuracy,
cumulative communication volume, and cumulative FedBiCert runtime summary to
`logs/fedbicert_cifar10_comm_rounds_seed1_summary.csv`.

V3 uses `--bicert_query_source hybrid`, direct inversion queries, and
client-side synthetic anchors uploaded once by clients. By default those
anchors use `--bicert_client_anchor_mode hybrid_mixup`: each client locally
mixes same-class training images, adds noise/cutout, scores candidates with
its own model, and uploads only the selected synthetic anchors plus soft
logits. The server receives no raw real samples and uses no real server-side
samples by default. Keep `--bicert_public_anchor_per_class 0` for the strict
data-free protocol. Public anchors are a separate public-data variant;
enabling them requires `--bicert_allow_public_anchor 1` and should not be mixed
with the main data-free result.

The distillation scripts first run an anchor-only server warmup using only the
uploaded synthetic anchors (`--bicert_anchor_warmup_epochs`). This is the
recommended no-real-server-data path when the random server stays near chance:
the server learns a usable decision boundary from one-shot synthetic client
payloads before the generator/inversion refinement stage.

Downlink distillation uses a soft safety gate instead of the earlier hard
all-or-nothing gate. On real local client data, server KD is weighted whenever
the server predicts the true local label; on synthetic global queries, the
client learns high-confidence server pseudo labels with both KD and hard
synthetic CE. A candidate client is accepted when local validation does not
drop beyond `--bicert_downlink_max_val_drop` and the synthetic global proxy
improves, which avoids rejecting useful global knowledge only because the
client validation split is highly non-IID.

For visible client-side gains, the default V3 distillation scripts now use
aggressive server-to-client replay: each local batch is paired with multiple
server-labeled synthetic replay batches
(`--bicert_downlink_synth_replay_steps 4`,
`--bicert_downlink_synth_batch_multiplier 2.0`) and the replay objective is
scaled into the gradient. If client and server feature dimensions match, an
extra feature distillation term is enabled by
`--bicert_downlink_feature_weight`.

After this hybrid mixup anchor update, rerun the pretraining command before
distillation. Older checkpoints either do not contain anchors or contain weak
noise-optimized anchors, so reusing them will reproduce the low server
accuracy.

## Homogeneous CNN3 models

Use this setting to verify that the method is effective under data
heterogeneity alone: the server and all five clients are `cnn3`, with
Dirichlet `beta=0.1`.

```bat
run\run_fedbicert_v3_cnn3_pretrain.cmd cifar10 1
run\run_fedbicert_v3_cnn3_distill.cmd cifar10 1 0
```

SVHN:

```bat
run\run_fedbicert_v3_cnn3_pretrain.cmd svhn 1
run\run_fedbicert_v3_cnn3_distill.cmd svhn 1 0
```

The default distillation script is strict data-free. It uses uploaded
client-side synthetic anchors, but no public real anchors. Do not pass a sixth
argument for the main result:

```bat
run\run_fedbicert_v3_cnn3_distill.cmd cifar10 1 0
```

Only for a clearly labeled public-data variant, pass a positive sixth argument;
the script will then set `--bicert_allow_public_anchor 1`.

## Outputs

```text
pkl/{timestr}-{dataset}_{clients}clients_{alpha}.pkl
df_ckpt/{timestr}-fedbicert-server.pth
df_ckpt/{timestr}-fedbicert-clients.pth
df_ckpt/{timestr}-fedbicert-report.pth
logs/{timestr}_{dataset}_{clients}clients.log
```

Audit an existing run:

```powershell
python check_fedbicert_results.py --timestr fedbicert_cifar10_cnn3_a01_s1 --server-target 50 --client-target 50
```

## Essential ablations

Use the same pretraining checkpoint and seed.

- No conflict queries: `--bicert_conflict_ratio 0`
- No certified support: `--bicert_support_weight 0`
- Uniform routing approximation: use a very high
  `--bicert_routing_temperature 100`
- No worst-class objective: `--bicert_cvar_weight 0`
- No safe downlink KD: `--downlink_kd 0 --bicert_synthetic_kd_weight 0`
- No preservation constraint: `--bicert_preserve_weight 0`

Accuracy thresholds are experimental targets, not mathematical guarantees.
Report mean and standard deviation over at least five seeds for publication.
