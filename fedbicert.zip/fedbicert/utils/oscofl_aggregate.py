import torch

def aggregate_client_stats(client_stats, device="cuda", eps=1e-8):
    """
    OS-CoFL 第 2 阶段：固定权重类级语义聚合。
    输入:
        client_stats: list，每个元素包含:
            class_probs:   [C, C]
            class_centers: [C, D]
            class_counts:  [C]
    输出:
        global_probs:   [C, C]
        global_centers: [C, D]
        class_weights:  [K, C]
    """
    client_class_probs = torch.stack(
        [stat["class_probs"] for stat in client_stats],
        dim=0
    ).to(device)  # [K, C, C]

    client_class_centers = torch.stack(
        [stat["class_centers"] for stat in client_stats],
        dim=0
    ).to(device)  # [K, C, D]

    client_class_counts = torch.stack(
        [stat["class_counts"] for stat in client_stats],
        dim=0
    ).to(device)  # [K, C]

    # 添加过滤机制：将样本数少于 20 的类忽略，避免少样本类别污染全局语义
    min_count = 20
    valid_mask = (client_class_counts >= min_count).float()
    masked_counts = client_class_counts * valid_mask

    # 每个类别单独按有效样本数加权
    class_weights = masked_counts / (
        masked_counts.sum(dim=0, keepdim=True) + eps
    )  # [K, C]

    # 标记哪些类别在所有客户端上至少有 1 个满足极小值的有效样本
    class_valid = masked_counts.sum(dim=0) > 0  # [C]

    # 根据按样本算出的权重聚合分布与中心
    global_probs = torch.sum(
        class_weights.unsqueeze(-1) * client_class_probs,
        dim=0
    )  # [C, C]

    global_centers = torch.sum(
        class_weights.unsqueeze(-1) * client_class_centers,
        dim=0
    )  # [C, D]

    # 对没有样本的类别做兜底
    if (~class_valid).any():
        C = global_probs.size(0)
        global_probs[~class_valid] = torch.ones(C, device=device) / C
        global_centers[~class_valid] = 0.0

    # 防止数值误差，重新归一化 global_probs
    global_probs = global_probs / (global_probs.sum(dim=1, keepdim=True) + eps)

    return global_probs, global_centers, class_weights
