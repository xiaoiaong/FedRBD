import math

import torch
import torch.nn.functional as F


def _collect_logits(model, loader, device):
    logits_list = []
    labels_list = []
    model.eval()
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device).long()
            logits_list.append(model(images))
            labels_list.append(labels)
    if not logits_list:
        raise ValueError("Cannot build a risk certificate from an empty loader.")
    return torch.cat(logits_list, dim=0), torch.cat(labels_list, dim=0)


def calibrate_temperature(model, val_loader, device, steps=80):
    logits, labels = _collect_logits(model, val_loader, device)
    log_temperature = torch.zeros((), device=device, requires_grad=True)
    optimizer = torch.optim.Adam([log_temperature], lr=0.05)
    best_loss = float("inf")
    best_temperature = 1.0

    for _ in range(steps):
        temperature = log_temperature.exp().clamp(0.5, 5.0)
        loss = F.cross_entropy(logits / temperature, labels)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        current_loss = float(loss.detach())
        if current_loss < best_loss:
            best_loss = current_loss
            best_temperature = float(temperature.detach())

    return best_temperature


def extract_risk_certificate(
    model,
    train_loader,
    val_loader,
    num_classes,
    device,
    temperature_steps=80,
):
    """Build model-local support and calibration statistics.

    Feature dimensions are intentionally left client-specific. The server
    evaluates support in each client's own feature space.
    """
    model.eval()
    temperature = calibrate_temperature(
        model,
        val_loader,
        device,
        steps=temperature_steps,
    )

    feature_sum = None
    feature_sq_sum = None
    class_counts = torch.zeros(num_classes, device=device)
    train_margin_sum = torch.zeros(num_classes, device=device)
    train_margin_sq_sum = torch.zeros(num_classes, device=device)
    logit_sum = torch.zeros(num_classes, num_classes, device=device)
    logit_sq_sum = torch.zeros(num_classes, num_classes, device=device)
    prob_sum = torch.zeros(num_classes, num_classes, device=device)

    with torch.no_grad():
        for images, labels in train_loader:
            images = images.to(device)
            labels = labels.to(device).long()
            logits, features = model(images, return_feature=True)
            features = F.normalize(features.float(), dim=1)
            calibrated_logits = logits.float() / temperature
            probabilities = F.softmax(calibrated_logits, dim=1)
            target_logits = calibrated_logits.gather(1, labels[:, None]).squeeze(1)
            other_logits = calibrated_logits.clone()
            other_logits.scatter_(1, labels[:, None], -float("inf"))
            margins = target_logits - other_logits.max(dim=1).values

            if feature_sum is None:
                feature_dim = features.size(1)
                feature_sum = torch.zeros(
                    num_classes,
                    feature_dim,
                    device=device,
                )
                feature_sq_sum = torch.zeros_like(feature_sum)

            for class_id in labels.unique():
                class_index = int(class_id)
                mask = labels.eq(class_index)
                selected_features = features[mask]
                selected_margins = margins[mask]
                count = mask.sum()
                class_counts[class_index] += count
                feature_sum[class_index] += selected_features.sum(dim=0)
                feature_sq_sum[class_index] += selected_features.square().sum(dim=0)
                train_margin_sum[class_index] += selected_margins.sum()
                train_margin_sq_sum[class_index] += selected_margins.square().sum()
                selected_logits = calibrated_logits[mask]
                selected_probs = probabilities[mask]
                logit_sum[class_index] += selected_logits.sum(dim=0)
                logit_sq_sum[class_index] += selected_logits.square().sum(dim=0)
                prob_sum[class_index] += selected_probs.sum(dim=0)

    if feature_sum is None:
        raise ValueError("Cannot build a risk certificate from empty client data.")

    safe_counts = class_counts.clamp_min(1.0).unsqueeze(1)
    feature_mean = feature_sum / safe_counts
    feature_var = feature_sq_sum / safe_counts - feature_mean.square()
    feature_var = feature_var.clamp_min(1e-4)

    margin_mean = train_margin_sum / class_counts.clamp_min(1.0)
    margin_var = (
        train_margin_sq_sum / class_counts.clamp_min(1.0)
        - margin_mean.square()
    ).clamp_min(1e-4)
    margin_std = margin_var.sqrt()

    missing = class_counts.eq(0)
    feature_mean[missing] = 0.0
    feature_var[missing] = 1.0
    margin_mean[missing] = 0.0
    margin_std[missing] = 1.0
    logit_mean = logit_sum / class_counts.clamp_min(1.0).unsqueeze(1)
    logit_var = (
        logit_sq_sum / class_counts.clamp_min(1.0).unsqueeze(1)
        - logit_mean.square()
    ).clamp_min(1e-4)
    prob_mean = prob_sum / class_counts.clamp_min(1.0).unsqueeze(1)
    prob_mean = prob_mean / prob_mean.sum(dim=1, keepdim=True).clamp_min(1e-8)
    logit_mean[missing] = 0.0
    logit_var[missing] = 1.0
    prob_mean[missing] = 1.0 / num_classes

    class_correct = torch.zeros(num_classes, device=device)
    class_total = torch.zeros(num_classes, device=device)
    val_nll_sum = torch.zeros(num_classes, device=device)
    val_conf_sum = torch.zeros(num_classes, device=device)

    with torch.no_grad():
        for images, labels in val_loader:
            images = images.to(device)
            labels = labels.to(device).long()
            logits = model(images) / temperature
            probabilities = F.softmax(logits, dim=1)
            predictions = probabilities.argmax(dim=1)
            losses = F.cross_entropy(logits, labels, reduction="none")
            confidence = probabilities.gather(1, labels[:, None]).squeeze(1)
            for class_id in labels.unique():
                class_index = int(class_id)
                mask = labels.eq(class_index)
                class_total[class_index] += mask.sum()
                class_correct[class_index] += predictions[mask].eq(labels[mask]).sum()
                val_nll_sum[class_index] += losses[mask].sum()
                val_conf_sum[class_index] += confidence[mask].sum()

    reliability = (class_correct + 1.0) / (class_total + 2.0)
    class_nll = val_nll_sum / class_total.clamp_min(1.0)
    class_confidence = val_conf_sum / class_total.clamp_min(1.0)
    no_validation = class_total.eq(0)
    reliability[no_validation] = 0.5
    class_nll[no_validation] = math.log(max(num_classes, 2))
    class_confidence[no_validation] = 1.0 / num_classes

    return {
        "protocol": "fedbicert_v1",
        "temperature": torch.tensor(float(temperature)),
        "class_counts": class_counts.detach().cpu(),
        "feature_mean": feature_mean.detach().cpu(),
        "feature_var": feature_var.detach().cpu(),
        "margin_mean": margin_mean.detach().cpu(),
        "margin_std": margin_std.detach().cpu(),
        "class_correct": class_correct.detach().cpu(),
        "class_total": class_total.detach().cpu(),
        "reliability": reliability.detach().cpu(),
        "class_nll": class_nll.detach().cpu(),
        "class_confidence": class_confidence.detach().cpu(),
        "class_logit_mean": logit_mean.detach().cpu(),
        "class_logit_var": logit_var.detach().cpu(),
        "class_prob_mean": prob_mean.detach().cpu(),
    }


def validate_risk_certificate(certificate, num_classes):
    required = {
        "temperature",
        "class_counts",
        "feature_mean",
        "feature_var",
        "margin_mean",
        "margin_std",
        "class_correct",
        "class_total",
        "reliability",
        "class_nll",
        "class_confidence",
    }
    missing = required.difference(certificate)
    if missing:
        raise ValueError(
            "Risk certificate is missing fields: " + ", ".join(sorted(missing))
        )
    for key in required:
        value = certificate[key]
        if not torch.is_tensor(value):
            raise TypeError(f"Risk certificate field '{key}' must be a tensor.")
        if not torch.isfinite(value).all():
            raise ValueError(f"Risk certificate field '{key}' is not finite.")
    if certificate["class_counts"].numel() != num_classes:
        raise ValueError("Risk certificate class count does not match the dataset.")
    if certificate["feature_mean"].size(0) != num_classes:
        raise ValueError("Risk certificate feature statistics have invalid shape.")
    if certificate["feature_mean"].shape != certificate["feature_var"].shape:
        raise ValueError("Risk certificate feature mean/variance shapes differ.")
    if float(certificate["temperature"]) <= 0:
        raise ValueError("Risk certificate temperature must be positive.")
    optional = {
        "class_logit_mean",
        "class_logit_var",
        "class_prob_mean",
    }
    for key in optional.intersection(certificate):
        value = certificate[key]
        if not torch.is_tensor(value):
            raise TypeError(f"Risk certificate field '{key}' must be a tensor.")
        if not torch.isfinite(value).all():
            raise ValueError(f"Risk certificate field '{key}' is not finite.")
        if value.shape != (num_classes, num_classes):
            raise ValueError(f"Risk certificate field '{key}' has invalid shape.")
    return True
