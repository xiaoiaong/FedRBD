import atexit
from typing import Any, Dict, Iterable, List, Optional

import numpy as np
import torch

try:
    import swanlab
except ImportError:  # pragma: no cover - optional dependency
    swanlab = None


def _to_builtin(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, np.generic):
        return value.item()
    if torch.is_tensor(value):
        if value.numel() == 1:
            return value.detach().cpu().item()
        return value.detach().cpu().tolist()
    if isinstance(value, dict):
        return {
            str(key): _to_builtin(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_to_builtin(item) for item in value]
    return str(value)


def _filter_config(args) -> Dict[str, Any]:
    keys = [
        "algorithm",
        "type",
        "method",
        "dataset",
        "model",
        "server_model",
        "client_models",
        "teacher",
        "student",
        "fl_model",
        "num_users",
        "partition",
        "beta",
        "sigma",
        "epochs",
        "local_ep",
        "local_epoch_start",
        "local_epoch_offset",
        "local_total_epochs",
        "local_lr",
        "local_bs",
        "batch_size",
        "seed",
        "communication_round",
        "communication_rounds",
        "server_epoch_start",
        "server_total_epochs",
        "kd_lr",
        "g_steps",
        "target_acc",
        "server_target_acc",
        "downlink_epochs",
        "downlink_epoch_offset",
        "downlink_lr",
        "downlink_kd",
        "downlink_ce",
        "bicert_query_source",
        "bicert_generator_steps",
        "bicert_support_temperature",
        "bicert_margin_temperature",
        "bicert_routing_temperature",
        "bicert_ownership_power",
        "bicert_min_evidence",
        "bicert_reliability_floor",
        "bicert_query_floor",
        "bicert_anchor_warmup_epochs",
        "bicert_anchor_warmup_epoch_offset",
    ]
    config = {}
    for key in keys:
        if hasattr(args, key):
            config[key] = _to_builtin(getattr(args, key))
    return config


def _resolve_swanlab_experiment_name(args) -> Optional[str]:
    explicit_name = getattr(args, "swanlab_experiment_name", "").strip()
    if explicit_name:
        return explicit_name
    if bool(getattr(args, "swanlab_single_experiment", 0)):
        group_name = getattr(args, "swanlab_group", "").strip()
        if group_name:
            return group_name
    timestr = getattr(args, "timestr", "").strip()
    return timestr or None


def _resolve_swanlab_run_id(args) -> Optional[str]:
    explicit_id = getattr(args, "swanlab_run_id", "").strip()
    if explicit_id:
        return explicit_id
    if not bool(getattr(args, "swanlab_single_experiment", 0)):
        return None
    for candidate in [
        getattr(args, "swanlab_group", "").strip(),
        getattr(args, "swanlab_experiment_name", "").strip(),
        getattr(args, "timestr", "").strip(),
    ]:
        if candidate:
            return candidate
    return None


def _resolve_swanlab_resume(args) -> Optional[str]:
    explicit_resume = getattr(args, "swanlab_resume", "").strip()
    if explicit_resume:
        return explicit_resume
    if not bool(getattr(args, "swanlab_single_experiment", 0)):
        return None
    if str(getattr(args, "type", "")).lower() == "pretrain":
        return "allow"
    return "must"


class SwanLabSession:
    def __init__(self, run=None):
        self.run = run
        self.enabled = run is not None and swanlab is not None

    def log(self, payload: Dict[str, Any], step: Optional[int] = None) -> None:
        if not self.enabled or not payload:
            return
        sanitized = {}
        for key, value in payload.items():
            if isinstance(value, (int, float)):
                sanitized[key] = value
            elif isinstance(value, np.generic):
                sanitized[key] = value.item()
            elif torch.is_tensor(value) and value.numel() == 1:
                sanitized[key] = value.detach().cpu().item()
            else:
                sanitized[key] = value
        if step is None:
            self.run.log(sanitized)
        else:
            self.run.log(sanitized, step=step)

    def log_line(
        self,
        key: str,
        xaxis: Iterable[Any],
        series: Dict[str, List[Optional[float]]],
    ) -> None:
        if not self.enabled:
            return
        line = swanlab.echarts.Line()
        line.add_xaxis([str(item) for item in xaxis])
        for name, values in series.items():
            line.add_yaxis(name, values)
        self.run.log({key: line})

    def log_bar(
        self,
        key: str,
        xaxis: Iterable[Any],
        series: Dict[str, List[Optional[float]]],
    ) -> None:
        if not self.enabled:
            return
        bar = swanlab.echarts.Bar()
        bar.add_xaxis([str(item) for item in xaxis])
        for name, values in series.items():
            bar.add_yaxis(name, values)
        self.run.log({key: bar})

    def log_table(
        self,
        key: str,
        headers: List[str],
        rows: List[List[Any]],
    ) -> None:
        if not self.enabled:
            return
        table = swanlab.echarts.Table()
        table.add(headers, rows)
        self.run.log({key: table})

    def finish(self) -> None:
        if self.enabled:
            self.run.finish()


def init_swanlab(args) -> SwanLabSession:
    if not bool(getattr(args, "use_swanlab", 0)):
        return SwanLabSession()
    if swanlab is None:
        raise ImportError(
            "SwanLab is not installed. Please `pip install swanlab` "
            "or add it to your environment before using --use_swanlab 1."
        )

    experiment_name = _resolve_swanlab_experiment_name(args)
    run_id = _resolve_swanlab_run_id(args)
    resume_mode = _resolve_swanlab_resume(args)
    tags = [
        tag.strip()
        for tag in getattr(args, "swanlab_tags", "").split(",")
        if tag.strip()
    ]
    run = swanlab.init(
        project=getattr(args, "swanlab_project", "fedbicert-comparison"),
        experiment_name=experiment_name,
        description=(
            f"{getattr(args, 'algorithm', 'experiment')}"
            f"-{getattr(args, 'type', 'run')}"
            f"-{getattr(args, 'dataset', 'dataset')}"
        ),
        config=_filter_config(args),
        workspace=getattr(args, "swanlab_workspace", "") or None,
        logdir=getattr(args, "swanlab_logdir", "swanlog"),
        mode=getattr(args, "swanlab_mode", "online"),
        group=getattr(args, "swanlab_group", "") or None,
        id=run_id,
        resume=resume_mode,
        tags=tags or None,
    )
    session = SwanLabSession(run=run)
    atexit.register(session.finish)
    return session
