#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6
import argparse
import copy
# import osmo
import shutil
import sys
import warnings
import torchvision.models as models
import torchvision.transforms as tv_transforms
import numpy as np
from tqdm import tqdm
# import pdb
import datetime
import math
import os
import time
import matplotlib.pyplot as plt

from helpers.datasets import partition_data
from helpers.synthesizers import SASynthesizer
from helpers.utils import get_dataset, average_weights, DatasetSplit, DeepInversionHook, KLDiv, KLCom,setup_seed, test
from models.generator import Generator
from models.nets import (
    CNNMnist,
    CNNMnistFiveLayer,
    CNNMnistTwoLayer,
    CNN3,
    GoogleNetSmall,
    LeNet,
    VGGSmall,
)
from models.oscofl_stage3 import SimpleConditionalGenerator
from utils.oscofl_aggregate import aggregate_client_stats
from utils.swanlab_helper import init_swanlab
import torch
from torch.utils.data import DataLoader, Dataset, Subset
import torch.nn.functional as F


warnings.filterwarnings('ignore')
upsample = torch.nn.Upsample(mode='nearest', scale_factor=7)


def make_local_validation_dataset(args, dataset):
    validation_dataset = copy.copy(dataset)
    dataset_name = args.dataset.lower()
    if dataset_name == "cifar10":
        validation_dataset.transform = tv_transforms.Compose([
            tv_transforms.ToTensor(),
            tv_transforms.Normalize(
                (0.4914, 0.4822, 0.4465),
                (0.2470, 0.2435, 0.2616),
            ),
        ])
    elif dataset_name == "svhn":
        validation_dataset.transform = tv_transforms.Compose([
            tv_transforms.ToTensor(),
            tv_transforms.Normalize(
                (0.4377, 0.4438, 0.4728),
                (0.1980, 0.2010, 0.1970),
            ),
        ])
    elif dataset_name in ["miniimagenet", "miniimage", "mini"]:
        validation_dataset.transform = tv_transforms.Compose([
            tv_transforms.Resize(92),
            tv_transforms.CenterCrop(84),
            tv_transforms.ToTensor(),
        ])
    elif dataset_name in ["webvision", "webvision20"]:
        validation_dataset.transform = tv_transforms.Compose([
            tv_transforms.Resize(72),
            tv_transforms.CenterCrop(64),
            tv_transforms.ToTensor(),
            tv_transforms.Normalize(
                (0.485, 0.456, 0.406),
                (0.229, 0.224, 0.225),
            ),
        ])
    return validation_dataset


def build_test_loader(args, test_dataset):
    subset_size = int(getattr(args, "test_subset_size", 0) or 0)
    if subset_size <= 0 or subset_size >= len(test_dataset):
        return DataLoader(
            test_dataset,
            batch_size=256,
            shuffle=False,
            num_workers=0,
        )

    subset_seed = getattr(args, "test_subset_seed", -1)
    if subset_seed < 0:
        subset_seed = args.seed
    rng = np.random.RandomState(subset_seed)
    subset_indices = rng.choice(
        len(test_dataset),
        size=subset_size,
        replace=False,
    ).tolist()
    args.test_subset_indices = subset_indices
    return DataLoader(
        Subset(test_dataset, subset_indices),
        batch_size=min(256, subset_size),
        shuffle=False,
        num_workers=0,
    )


def build_full_test_loader(test_dataset):
    return DataLoader(
        test_dataset,
        batch_size=256,
        shuffle=False,
        num_workers=0,
    )



class LocalUpdate(object):
    """
    客户端本地训练类（相当于联邦学习中的各个 Client）
    每个参与方（手机/机构）在自己的设备上用分配到的本地数据训练模型
    """
    def __init__(self, args, dataset, idxs):
        self.args = args
        # DatasetSplit 是一个工具类，根据传入的索引(idxs)只提取该客户端对应的数据
        all_indices = np.asarray([int(i) for i in idxs], dtype=np.int64)
        split_rng = np.random.RandomState(self.args.seed + 7919 + int(all_indices.sum() % 100000))
        dataset_labels = getattr(dataset, "targets", getattr(dataset, "labels", None))
        if dataset_labels is not None:
            dataset_labels = np.asarray(dataset_labels)
            train_indices = []
            val_indices = []
            for class_id in np.unique(dataset_labels[all_indices]):
                class_indices = all_indices[dataset_labels[all_indices] == class_id].copy()
                split_rng.shuffle(class_indices)
                if len(class_indices) > 1:
                    class_val_size = max(1, int(round(0.10 * len(class_indices))))
                    class_val_size = min(class_val_size, len(class_indices) - 1)
                else:
                    class_val_size = 0
                val_indices.extend(class_indices[:class_val_size].tolist())
                train_indices.extend(class_indices[class_val_size:].tolist())
            self.val_indices = val_indices
            self.train_indices = train_indices
        else:
            shuffled = all_indices.copy()
            split_rng.shuffle(shuffled)
            val_size = max(1, int(round(0.10 * len(shuffled))))
            if len(shuffled) > 1:
                val_size = min(val_size, len(shuffled) - 1)
            self.val_indices = shuffled[:val_size].tolist()
            self.train_indices = shuffled[val_size:].tolist()
        if len(self.val_indices) == 0:
            self.val_indices = self.train_indices[:1]
            self.train_indices = self.train_indices[1:]
        if len(self.train_indices) == 0:
            self.train_indices = self.val_indices
        self.train_loader = DataLoader(
            DatasetSplit(dataset, self.train_indices),
            batch_size=self.args.local_bs,
            shuffle=True,
            num_workers=0,
        )
        validation_dataset = make_local_validation_dataset(args, dataset)
        self.val_loader = DataLoader(
            DatasetSplit(validation_dataset, self.val_indices),
            batch_size=max(self.args.local_bs, 64),
            shuffle=False,
            num_workers=0,
        )

    def evaluate_local_validation(self, model):
        return test(model, self.val_loader)

    def update_weights(self, model, client_id, test_loader=None):
        # 开启模型的训练模式
        model.train()
        start_time = time.perf_counter()
        # 更深的 CNN 在原始超参下更容易发散，加入轻量正则项增强稳定性。
        optimizer = torch.optim.SGD(
            model.parameters(),
            lr=self.args.local_lr,
            momentum=0.9,
            weight_decay=5e-4,
            nesterov=True,
        )
        local_offset = max(0, int(getattr(self.args, "local_epoch_offset", 0)))
        configured_total = int(getattr(self.args, "local_total_epochs", 0))
        local_total = max(
            configured_total if configured_total > 0 else local_offset + self.args.local_ep,
            local_offset + self.args.local_ep,
            1,
        )
        base_lr = float(self.args.local_lr)
        eta_min = min(1e-4, base_lr)

        def local_lr_factor(segment_epoch):
            global_epoch = min(local_offset + int(segment_epoch), local_total)
            cosine = 0.5 * (1.0 + math.cos(math.pi * global_epoch / local_total))
            absolute_lr = eta_min + (base_lr - eta_min) * cosine
            return absolute_lr / max(base_lr, 1e-12)

        scheduler = torch.optim.lr_scheduler.LambdaLR(
            optimizer,
            lr_lambda=local_lr_factor,
        )

        local_acc_list = []
        local_test_acc_list = []
        best_state = copy.deepcopy(model.state_dict())
        best_acc = float("-inf")
        # 本地迭代训练 args.local_ep 个 Epoch（轮数）
        for iter in tqdm(range(self.args.local_ep)):
            for batch_idx, (images, labels) in enumerate(self.train_loader):
                images, labels = images.cuda(), labels.cuda()
                optimizer.zero_grad(set_to_none=True) # 清空过往梯度
                # ---------------------------------------
                # 前向传播：模型预测
                output = model(images)
                # 计算损失：多分类交叉熵损失
                loss = F.cross_entropy(
                    output,
                    labels,
                    label_smoothing=self.args.label_smoothing,
                )
                # ---------------------------------------
                # 反向传播：计算梯度并更新权重
                if not torch.isfinite(loss):
                    raise ValueError(
                        f"Non-finite loss detected for client {client_id} "
                    f"at local epoch {local_offset + iter}, batch {batch_idx}"
                    )
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0)
                optimizer.step()
            scheduler.step()
            # Select the local checkpoint only on the client's held-out validation split.
            acc, _ = self.evaluate_local_validation(model)
            if test_loader is not None:
                test_acc, _ = test(model, test_loader)
            else:
                test_acc = acc

            local_acc_list.append(acc)
            local_test_acc_list.append(test_acc)
            self.args.swanlab_run.log(
                {
                    f"client/local_train_test_acc/client_{client_id}": float(test_acc),
                    f"compare/client_local_test_acc/client_{client_id}": float(test_acc),
                },
                step=local_offset + iter + 1,
            )
            if acc > best_acc:
                best_acc = acc
                best_state = copy.deepcopy(model.state_dict())
        # 训练结束后，返回更新后的本地模型权重(state_dict)和准确率记录
        return (
            model.state_dict(),
            np.array(local_acc_list),
            np.array(local_test_acc_list),
            best_state,
            best_acc,
            time.perf_counter() - start_time,
        )

    def extract_oscofl_stats(self, model, num_classes=10, temperature=2.0):
        """
        提取 OS-CoFL 第 1 阶段需要的客户端统计信息。
        返回:
          class_probs: [C, C]，第 k 个客户端每个类别的平均预测分布
          class_centers: [C, D]，第 k 个客户端每个类别的特征中心
          class_counts: [C]，每个类别样本数
          client_embedding: [C + 5]，客户端整体统计嵌入，后续输入 AWPN
        """
        model.eval()
        class_probs = None
        class_centers = None
        class_counts = torch.zeros(num_classes).cuda()
        
        all_feats = []
        all_labels = []
        all_conf = []

        with torch.no_grad():
            for images, labels in self.train_loader:
                images, labels = images.cuda(), labels.cuda()
                logits, feats = model(images, return_feature=True)
                
                probs = F.softmax(logits / temperature, dim=1)
                conf = probs.max(dim=1)[0]
                
                if class_probs is None:
                    feature_dim = feats.size(1)
                    class_probs = torch.zeros(num_classes, num_classes).cuda()
                    class_centers = torch.zeros(num_classes, feature_dim).cuda()
                    
                all_feats.append(feats)
                all_labels.append(labels)
                all_conf.append(conf)

                for c in range(num_classes):
                    mask = labels == c
                    if mask.sum() > 0:
                        class_probs[c] += probs[mask].sum(dim=0)
                        class_centers[c] += feats[mask].sum(dim=0)
                        class_counts[c] += mask.sum()

        # 计算每个类别的平均预测分布和特征中心
        for c in range(num_classes):
            if class_counts[c] > 0:
                class_probs[c] = class_probs[c] / class_counts[c]
                class_centers[c] = class_centers[c] / class_counts[c]
            else:
                # 如果某个客户端没有该类别样本，则用均匀分布和零向量占位
                class_probs[c] = torch.ones(num_classes).cuda() / num_classes
                class_centers[c] = torch.zeros_like(class_centers[c])

        # Heterogeneous clients can have incompatible feature dimensions.
        # Probability prototypes are model-agnostic and keep aggregation valid.
        if getattr(self.args, "client_models", ""):
            class_centers = class_probs.clone()

        all_feats = torch.cat(all_feats, dim=0)
        all_labels = torch.cat(all_labels, dim=0)
        all_conf = torch.cat(all_conf, dim=0)

        # 设备级统计信息
        total_num = class_counts.sum()
        label_hist = class_counts / (total_num + 1e-8)
        
        label_entropy = -torch.sum(
            label_hist * torch.log(label_hist + 1e-8),
            dim=0,
            keepdim=True
        )
        sample_num = torch.log(total_num.view(1) + 1.0)
        feat_mean_scalar = all_feats.mean().view(1)
        feat_var_scalar = all_feats.var().view(1)
        avg_conf = all_conf.mean().view(1)

        # 这个向量后面作为 AWPN 的输入
        client_embedding = torch.cat([
            label_hist,          # C 维，标签分布
            label_entropy,       # 1 维，标签熵
            sample_num,          # 1 维，样本数规模
            feat_mean_scalar,    # 1 维，特征均值
            feat_var_scalar,     # 1 维，特征方差
            avg_conf             # 1 维，平均置信度
        ], dim=0)
        
        stat = {
            "class_probs": class_probs.detach().cpu(),
            "class_centers": class_centers.detach().cpu(),
            "class_counts": class_counts.detach().cpu(),
            "client_embedding": client_embedding.detach().cpu(),
            "label_hist": label_hist.detach().cpu(),
            "real_labels": all_labels.detach().cpu().long()
        }
        
        return stat


import logging
def get_logger(logpath):
    logger = logging.getLogger('main')
    logger.setLevel(level=logging.DEBUG)
    formatter1 = logging.Formatter('%(filename)s: %(message)s')
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG)
    stream_handler.setFormatter(formatter1)

    formatter2 = logging.Formatter('%(asctime)s - %(filename)s[line:%(lineno)d]: %(message)s')
    # os.makedirs(logpath, exist_ok=True)
    file_handler = logging.FileHandler(logpath)
    file_handler.setLevel(level=logging.DEBUG)
    file_handler.setFormatter(formatter2)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    # logging.basicConfig(format='%(asctime)s - %(filename)s[line:%(lineno)d]: %(message)s', level=logging.DEBUG,
    #                     filename=logpath, filemode='a')

    return logger

def args_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--algorithm', type=str, default='dense', help='dense or dense_pro')

    # federated arguments (Notation for the arguments followed from paper)
    parser.add_argument('--epochs', type=int, default=10,
                        help="number of rounds of training")
    parser.add_argument('--num_users', type=int, default=5,
                        help="number of users: K")
    parser.add_argument('--frac', type=float, default=1,
                        help='the fraction of clients: C')
    parser.add_argument('--local_ep', type=int, default=100,
                        help="the number of local epochs: E")
    parser.add_argument('--local_epoch_offset', type=int, default=0,
                        help='completed local epochs before this communication segment')
    parser.add_argument('--local_total_epochs', type=int, default=0,
                        help='total local-training budget across all communication rounds; 0 uses local_ep')
    parser.add_argument('--local_bs', type=int, default=128,
                        help="local batch size: B")
    parser.add_argument('--lr', type=float, default=0.01,
                        help='learning rate')
    parser.add_argument('--local_lr', type=float, default=0.05,
                        help='client pretraining learning rate')
    parser.add_argument('--label_smoothing', type=float, default=0.05,
                        help='label smoothing used for CNN client pretraining')
    parser.add_argument('--momentum', type=float, default=0.9,
                        help='SGD momentum (default: 0.5)')
    # other arguments
    parser.add_argument('--dataset', type=str, default='cifar10', help="name \
                        of dataset")
    parser.add_argument('--data_root', default='', type=str,
                        help='optional dataset root; defaults to ./dataset')
    parser.add_argument('--test_subset_size', default=0, type=int,
                        help='optional test-set subset size; 0 keeps the full test set')
    parser.add_argument('--test_subset_seed', default=-1, type=int,
                        help='seed for test subset sampling; negative values reuse --seed')
    parser.add_argument('--iid', type=int, default=1,
                        help='Default set to IID. Set to 0 for non-IID.')

    # Data Free
    parser.add_argument('--adv', default=0, type=float, help='scaling factor for adv loss')

    parser.add_argument('--bn', default=0, type=float, help='scaling factor for BN regularization')
    parser.add_argument('--oh', default=0, type=float, help='scaling factor for one hot loss (cross entropy)')
    parser.add_argument('--act', default=0, type=float, help='scaling factor for activation loss used in DAFL')
    parser.add_argument('--save_dir', default='run/synthesis', type=str)
    parser.add_argument('--partition', default='dirichlet', type=str,
                        help='data partition: iid, dirichlet, or two_class/2c')
    parser.add_argument('--beta', default=0.5, type=float,
                        help=' If beta is set to a smaller value, '
                             'then the partition is more unbalanced')
    parser.add_argument('--split_file', default='', type=str,
                        help='optional path to a saved client split file; when set, partition generation is skipped')
    parser.add_argument('--save_split_file', default='', type=str,
                        help='optional output path for saving the generated client split file')
    parser.add_argument('--split_only', default=0, type=int,
                        help='set to 1 to generate/validate the split file and exit before training')

    # Basic
    parser.add_argument('--lr_g', default=1e-3, type=float,
                        help='initial learning rate for generation')
    parser.add_argument('--T', default=1, type=float)
    parser.add_argument('--kl_alpha1', default=0, type=float)
    parser.add_argument('--kl_alpha2', default=1, type=float)

    parser.add_argument('--g_steps', default=20, type=int, metavar='N',
                        help='number of iterations for generation')
    parser.add_argument('--batch_size', default=256, type=int, metavar='N',
                        help='number of total iterations in each epoch')
    parser.add_argument('--nz', default=256, type=int, metavar='N',
                        help='number of total iterations in each epoch')
    parser.add_argument('--synthesis_batch_size', default=256, type=int)
    # Misc
    parser.add_argument('--seed', default=42, type=int,
                        help='seed for initializing training.')
    parser.add_argument('--type', default="pretrain", type=str,
                        help='seed for initializing training.')
    parser.add_argument('--model', default="", type=str,
                        help='seed for initializing training.')
    parser.add_argument('--server_model', default="", type=str,
                        help='server model name; falls back to --model when empty')
    parser.add_argument('--client_models', default="", type=str,
                        help='comma separated heterogeneous client model names, e.g. lenet,vgg,googlenet,resnet18')
    parser.add_argument('--client_init_checkpoint', default='', type=str,
                        help='optional prior FedBiCert downlink client checkpoint used to continue local training')
    parser.add_argument('--fedbicert_server_init_checkpoint', default='', type=str,
                        help='optional prior FedBiCert server checkpoint used by the next communication round')
    parser.add_argument('--communication_round', default=1, type=int,
                        help='one-based communication round index for logging and checkpoint metadata')
    parser.add_argument('--communication_rounds', default=1, type=int,
                        help='total number of FedBiCert communication rounds')
    parser.add_argument('--downlink_epochs', default=5, type=int,
                        help='local epochs for server-to-client downlink distillation')
    parser.add_argument('--downlink_epoch_offset', default=0, type=int,
                        help='completed downlink epochs before this communication round')
    parser.add_argument('--downlink_lr', default=3e-4, type=float,
                        help='learning rate for downlink client distillation')
    parser.add_argument('--downlink_kd', default=1.0, type=float,
                        help='KD loss weight in downlink distillation')
    parser.add_argument('--downlink_ce', default=0.2, type=float,
                        help='real-data CE loss weight in downlink distillation')
    parser.add_argument('--downlink_temperature', default=3.0, type=float,
                        help='temperature for downlink distillation')
    parser.add_argument('--uplink_kd', default=1.0, type=float,
                        help='client-logit KD weight in uplink distillation; use 0 for ablation')
    parser.add_argument('--param_kd', default=0.0, type=float,
                        help='deprecated; parameter copying is disabled in bidirectional mode')
    parser.add_argument('--downlink_param_kd', default=0.0, type=float,
                        help='deprecated; parameter copying is disabled in bidirectional mode')
    parser.add_argument('--target_acc', default=50.0, type=float,
                        help='required client accuracy for strict bidirectional validation')
    parser.add_argument('--server_target_acc', default=-1.0, type=float,
                        help='required server accuracy; SVHN defaults to strictly above 62.1')
    parser.add_argument('--strict_target', default=1, type=int,
                        help='raise an error when bidirectional accuracy targets are not met')
    parser.add_argument('--bicert_generator_steps', default=600, type=int,
                        help='initial FedBiCert generator optimization steps')
    parser.add_argument('--bicert_refresh_steps', default=80, type=int,
                        help='generator steps at each query-bank refresh')
    parser.add_argument('--bicert_refresh_interval', default=8, type=int,
                        help='server epochs between query-bank refreshes')
    parser.add_argument('--bicert_bank_batches', default=24, type=int,
                        help='number of training batches in the synthetic query bank')
    parser.add_argument('--bicert_proxy_batches', default=12, type=int,
                        help='held-out synthetic batches used for server selection')
    parser.add_argument('--bicert_generator_width', default=64, type=int)
    parser.add_argument('--bicert_generator_lr', default=1e-4, type=float)
    parser.add_argument('--bicert_server_lr', default=3e-4, type=float)
    parser.add_argument('--bicert_support_temperature', default=1.0, type=float)
    parser.add_argument('--bicert_margin_temperature', default=2.0, type=float,
                        help='tau_m: scale of the certificate margin standard deviation')
    parser.add_argument('--bicert_routing_temperature', default=0.5, type=float)
    parser.add_argument('--bicert_router_chunk_size', default=0, type=int,
                        help='optional router batch chunk size to reduce peak GPU memory; 0 disables chunking')
    parser.add_argument('--bicert_min_evidence', default=0.02, type=float)
    parser.add_argument('--bicert_ownership_power', default=1.5, type=float)
    parser.add_argument('--bicert_min_class_count', default=10, type=int)
    parser.add_argument('--bicert_support_floor', default=0.25, type=float)
    parser.add_argument('--bicert_reliability_floor', default=0.05, type=float,
                        help='lambda_r: minimum class reliability used by certified routing')
    parser.add_argument('--bicert_query_floor', default=0.02, type=float,
                        help='lambda_q: minimum query certainty used by certified routing')
    parser.add_argument('--bicert_conflict_ratio', default=0.0, type=float)
    parser.add_argument('--bicert_disagreement_weight', default=0.0, type=float)
    parser.add_argument('--bicert_support_weight', default=1.0, type=float)
    parser.add_argument('--bicert_bn_weight', default=0.05, type=float)
    parser.add_argument('--bicert_tv_weight', default=0.001, type=float)
    parser.add_argument('--bicert_diversity_weight', default=0.05, type=float)
    parser.add_argument('--bicert_generator_min_confidence', default=0.65, type=float)
    parser.add_argument('--bicert_temperature', default=2.0, type=float)
    parser.add_argument('--bicert_hard_weight', default=1.0, type=float)
    parser.add_argument('--bicert_kd_warmup_epochs', default=10, type=int)
    parser.add_argument('--bicert_cvar_weight', default=0.3, type=float)
    parser.add_argument('--bicert_cvar_fraction', default=0.3, type=float)
    parser.add_argument('--bicert_consistency_weight', default=0.1, type=float)
    parser.add_argument('--bicert_ema_decay', default=0.95, type=float)
    parser.add_argument('--bicert_patience', default=16, type=int)
    parser.add_argument('--bicert_grad_clip', default=1.0, type=float)
    parser.add_argument('--bicert_downlink_margin', default=0.05, type=float)
    parser.add_argument('--bicert_downlink_confidence', default=0.55, type=float)
    parser.add_argument('--bicert_downlink_soft_gate', default=1, type=int,
                        help='use confidence-weighted downlink KD instead of binary hard gates')
    parser.add_argument('--bicert_downlink_min_weight', default=0.20, type=float,
                        help='minimum KD weight for server-correct real samples in soft-gated downlink')
    parser.add_argument('--bicert_downlink_synth_ce_weight', default=1.0, type=float,
                        help='hard pseudo-label CE weight on server-labeled synthetic downlink queries')
    parser.add_argument('--bicert_downlink_teacher_confidence', default=0.35, type=float,
                        help='minimum server confidence for synthetic downlink pseudo labels')
    parser.add_argument('--bicert_downlink_synth_replay_steps', default=3, type=int,
                        help='number of server-labeled synthetic replay batches per local batch')
    parser.add_argument('--bicert_downlink_synth_batch_multiplier', default=2.0, type=float,
                        help='synthetic downlink batch size multiplier relative to the local batch')
    parser.add_argument('--bicert_downlink_synth_replay_loss_scale', default=3.0, type=float,
                        help='loss multiplier for the averaged synthetic replay objective')
    parser.add_argument('--bicert_downlink_feature_weight', default=0.2, type=float,
                        help='feature distillation weight when client/server feature dimensions match')
    parser.add_argument('--bicert_downlink_proxy_weight', default=0.50, type=float,
                        help='selection weight for synthetic global proxy improvement')
    parser.add_argument('--bicert_downlink_max_val_drop', default=1.0, type=float,
                        help='maximum allowed local validation accuracy drop when accepting downlink')
    parser.add_argument('--bicert_downlink_min_proxy_gain', default=0.0, type=float,
                        help='minimum synthetic proxy accuracy gain for accepting downlink')
    parser.add_argument('--bicert_synthetic_kd_weight', default=0.5, type=float)
    parser.add_argument('--bicert_preserve_weight', default=0.5, type=float)
    parser.add_argument('--bicert_trust_weight', default=1e-6, type=float)
    parser.add_argument('--bicert_fisher_batches', default=8, type=int)
    parser.add_argument('--bicert_min_val_gain', default=0.0, type=float)
    parser.add_argument('--bicert_min_downlink_server_acc', default=40.0, type=float)
    parser.add_argument('--bicert_query_source', default='hybrid', type=str,
                        help='fedbicert query source: generator, inversion, or hybrid')
    parser.add_argument('--bicert_inversion_steps', default=80, type=int,
                        help='direct image optimization steps for FedBiCert inversion queries')
    parser.add_argument('--bicert_inversion_lr', default=0.08, type=float,
                        help='learning rate for direct FedBiCert inversion queries')
    parser.add_argument('--bicert_public_anchor_per_class', default=0, type=int,
                        help='optional public anchor samples per class; 0 disables anchor distillation')
    parser.add_argument('--bicert_public_anchor_batches', default=16, type=int,
                        help='maximum public anchor batches used in each FedBiCert bank')
    parser.add_argument('--bicert_allow_public_anchor', default=0, type=int,
                        help='must be 1 to allow real public-anchor samples on the server')
    parser.add_argument('--bicert_client_anchor_per_class', default=32, type=int,
                        help='client-side synthetic anchors uploaded per observed class; 0 disables')
    parser.add_argument('--bicert_client_anchor_steps', default=120, type=int,
                        help='local optimization steps for client-side synthetic anchors')
    parser.add_argument('--bicert_client_anchor_lr', default=0.08, type=float,
                        help='local optimization learning rate for client-side synthetic anchors')
    parser.add_argument('--bicert_client_anchor_batch_size', default=64, type=int,
                        help='client-side synthetic anchor optimization batch size')
    parser.add_argument('--bicert_client_anchor_min_count', default=10, type=int,
                        help='minimum local class count before generating anchors for that class')
    parser.add_argument('--bicert_client_anchor_mode', default='hybrid_mixup', type=str,
                        help='client anchor protocol: hybrid_mixup, mixup, mosaic, or deepinversion')
    parser.add_argument('--bicert_client_anchor_mix_k', default=4, type=int,
                        help='number of same-class local samples mixed per uploaded synthetic anchor')
    parser.add_argument('--bicert_client_anchor_candidate_multiplier', default=3, type=int,
                        help='client-side candidate multiplier before confidence filtering anchors')
    parser.add_argument('--bicert_client_anchor_noise_std', default=0.03, type=float,
                        help='normalized Gaussian noise applied to local synthetic mixup anchors')
    parser.add_argument('--bicert_client_anchor_cutout', default=0.25, type=float,
                        help='normalized-space cutout fraction for local synthetic mixup anchors')
    parser.add_argument('--bicert_client_anchor_loss_weight', default=2.0, type=float,
                        help='server uplink loss multiplier for uploaded client synthetic anchors')
    parser.add_argument('--bicert_client_anchor_use_all', default=1, type=int,
                        help='use all uploaded client synthetic anchors instead of truncating by bank batches')
    parser.add_argument('--bicert_anchor_warmup_epochs', default=80, type=int,
                        help='server warmup epochs using only uploaded client synthetic anchors')
    parser.add_argument('--bicert_anchor_warmup_epoch_offset', default=0, type=int,
                        help='completed anchor-warmup epochs before this communication round')
    parser.add_argument('--bicert_anchor_warmup_lr', default=1e-3, type=float,
                        help='server learning rate for client-anchor-only warmup')
    parser.add_argument('--bicert_use_client_anchors', default=1, type=int,
                        help='use uploaded client-side synthetic anchors in server query banks')
    parser.add_argument('--bicert_client_anchor_feature_weight', default=1.0, type=float,
                        help='feature prototype matching weight for client synthetic anchors')
    parser.add_argument('--bicert_client_anchor_logit_weight', default=0.5, type=float,
                        help='logit/probability prototype matching weight for client synthetic anchors')
    parser.add_argument('--bicert_client_anchor_margin_weight', default=0.2, type=float,
                        help='margin distribution matching weight for client synthetic anchors')
    parser.add_argument('--bicert_client_anchor_regularization_weight', default=1.0, type=float,
                        help='scale BN, TV, and pixel-stat regularization in optimized client anchors')
    parser.add_argument('--bicert_regenerate_client_anchors', default=0, type=int,
                        help='regenerate client anchor payloads from saved client models and certificates during distill')
    parser.add_argument('--bicert_freeze_server_bn', default=1, type=int,
                        help='freeze server BN running statistics during data-free uplink distillation')
    parser.add_argument('--bicert_ablation', default='a0', type=str,
                        choices=['a0', 'a1_model_only', 'a2_uniform', 'a3_ungated_downlink',
                                 'a4_client_only', 'a5_no_warmup', 'a2_class_only',
                                 'a2_class_feature', 'a2_class_margin',
                                 'd0_no_downlink', 'd1_fixed_downlink', 'd2_real_only',
                                 'd3_synthetic_gated', 'l15_full_di', 'l15_wo_feature',
                                 'l15_wo_margin', 'l15_wo_soft',
                                 'l15_wo_regularization', 'l28_wo_balancing',
                                 'l28_wo_consistency', 'l28_ce_kd'],
                        help='FedBiCert ablation protocol; a0 keeps the complete method')
    parser.add_argument('--other', default="", type=str,
                        help='seed for initializing training.')

    parser.add_argument('--pretrainid', type=str, default='')
    parser.add_argument('--timestr', type=str, default='')
    parser.add_argument('--use_swanlab', default=0, type=int,
                        help='enable SwanLab experiment tracking')
    parser.add_argument('--swanlab_project', default='fedbicert-comparison', type=str,
                        help='SwanLab project name')
    parser.add_argument('--swanlab_workspace', default='', type=str,
                        help='optional SwanLab workspace name')
    parser.add_argument('--swanlab_experiment_name', default='', type=str,
                        help='optional SwanLab experiment name; defaults to timestr')
    parser.add_argument('--swanlab_mode', default='online', type=str,
                        help='SwanLab mode, e.g. online or local')
    parser.add_argument('--swanlab_logdir', default='swanlog', type=str,
                        help='directory used by SwanLab for local logs')
    parser.add_argument('--swanlab_group', default='', type=str,
                        help='optional SwanLab group name')
    parser.add_argument('--swanlab_single_experiment', default=0, type=int,
                        help='resume pretrain and distill into one SwanLab experiment')
    parser.add_argument('--swanlab_run_id', default='', type=str,
                        help='optional SwanLab run id used for resume/single-experiment tracking')
    parser.add_argument('--swanlab_resume', default='', type=str,
                        help='optional SwanLab resume mode, e.g. never, allow, or must')
    parser.add_argument('--swanlab_tags', default='', type=str,
                        help='optional comma separated SwanLab tags')
    parser.add_argument('--swanlab_eval_interval', default=5, type=int,
                        help='server test evaluation interval for SwanLab plots')
    parser.add_argument('--gpus', default='0,')
    args = parser.parse_args()
    return args


class Ensemble(torch.nn.Module):
    def __init__(self, model_list):
        super(Ensemble, self).__init__()
        self.models = model_list

    def forward(self, x):
        logits_total = 0
        for i in range(len(self.models)):
            logits = self.models[i](x)
            logits_total += logits
        logits_e = logits_total / len(self.models)

        return logits_e

class EnsemblePro(torch.nn.Module):
    def __init__(self, model_list, id=-1):
        super(EnsemblePro, self).__init__()
        self.models = model_list
        self.seleted_index = id   # -1 means all

    def select_client(self, id=-1):
        print(f'selected model id : {id}')
        assert -1 <= id < len(self.models)
        self.seleted_index = id

    def forward(self, x):
        if self.seleted_index == -1:
            logits_total = 0
            for i in range(len(self.models)):
                logits = self.models[i](x)
                logits_total += logits
            logits_e = logits_total / len(self.models)

            return logits_e
        else:
            assert 0 <= self.seleted_index < len(self.models)
            return self.models[self.seleted_index](x)


def kd_train(synthesizer, model, criterion, optimizer, args=None):
    student, teacher = model
    student.train()
    teacher.eval()
    description = "loss={:.4f} acc={:.2f}%"
    total_loss = 0.0
    correct = 0.0
    with tqdm(synthesizer.get_data()) as epochs:
        for idx, (images) in enumerate(epochs):
            optimizer.zero_grad()
            images = images.cuda()
            with torch.no_grad():
                t_out = teacher(images)
            s_out = student(images.detach())
            loss_s = criterion(s_out, t_out.detach())

            loss_s.backward()
            optimizer.step()

            total_loss += loss_s.detach().item()
            avg_loss = total_loss / (idx + 1)
            pred = s_out.argmax(dim=1)
            target = t_out.argmax(dim=1)
            correct += pred.eq(target.view_as(pred)).sum().item()
            acc = correct / len(synthesizer.data_loader.dataset) * 100

            args.flogger.info(f'[{idx}/{len(epochs)}: avg loss[{avg_loss}], acc[{acc}]')

            epochs.set_description(description.format(avg_loss, acc))

def sa_kd_train_legacy_unused(synthesizer, model, criterion, optimizer, args=None):
    """
    服务器端核心:联邦数据无预学习环境下的知识蒸馏(Knowledge Distillation)
    此阶段完全发生在一个只有伪数据的服务器上，没有真实客户端的数据。
    :param synthesizer: 数据合成器对象，用于实时提供由生成器(GAN)凭空产生的假图片
    :param model: [student, teacher]- `student`代表要训练提升的全局聚合模型，`teacher`代表集成了所有人经验的模型
    :param criterion: 损失函数，通常是 KL 散度，用于对比教师和学生对同张图的预测差距
    :param optimizer: 优化器，用于更新学生模型的权重
    :param args: 其他参数配置
    """
    student, teacher = model # 把传入的model参数解包，拆分成学生模型 student和教师模型 teacher两个独立变量，方便后续分别操作ccc
    student.train() # 全局模型开启训练状态，它是我们需要更新优化的目标
    teacher.cuda()  # 将教师模型送入 GPU
    teacher.eval()  # 教师模型开启评估状态（不计算梯度不更新），它只负责“教”
    description = "loss={:.4f} acc={:.2f}%"
    total_loss = 0.0
    correct = 0.0

    # 遍历合成器生成出来的一批批假图片数据
    with tqdm(synthesizer.get_data()) as epochs:
        for idx, (images, targets) in enumerate(epochs):
            optimizer.zero_grad()
            images = images.cuda() # 此处的 images 完全是由服务器生成器伪造出来的！
            teacher.set_batch_targets(targets) # 教师模型针对这批特定的假数据设定分类偏好
            
            with torch.no_grad():
                t_out = teacher(images) # 【教学示范】 教师对这些假图片进行推理预测（软标签）
            
            s_out = student(images.detach()) # 【学生做题】 学生也看同一批假图片，尝试给出自己的预测
            
            # 【考官打分】 核心：衡量两者预测分布差距！我们不需要真实的 y_true，
            # 只要学生模仿得尽可能像老师（t_out），在这个伪分布上和老师意见一致，就视为学到了知识
            loss_s = criterion(s_out, t_out.detach())

            loss_s.backward()  # 学生知道错在哪后开始反向传播
            optimizer.step()   # 更新全局模型的权重

            # ---- 以下为日常打印预测正确率的代码 ----
            total_loss += loss_s.detach().item()
            avg_loss = total_loss / (idx + 1)
            pred = s_out.argmax(dim=1)
            target = t_out.argmax(dim=1)
            correct += pred.eq(target.view_as(pred)).sum().item()
            acc = correct / len(synthesizer.data_loader.dataset) * 100

            args.flogger.info(f'[{idx}/{len(epochs)}: avg loss[{avg_loss}], acc[{acc}]')

            epochs.set_description(description.format(avg_loss, acc))


def sa_kd_train(
    synthesizer,
    model,
    criterion,
    optimizer,
    args=None,
    label_ce_weight=0.0,
    freeze_bn=False,
    min_teacher_conf=0.0,
    require_teacher_target=False,
):
    """Train a student only on server-generated synthetic images."""
    student, teacher = model
    student.train()
    if freeze_bn:
        for module in student.modules():
            if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):
                module.eval()
    teacher.cuda()
    teacher.eval()

    description = "loss={:.4f} acc={:.2f}%"
    total_loss = 0.0
    total_kd_loss = 0.0
    total_label_ce_loss = 0.0
    correct = 0.0
    seen = 0

    with tqdm(synthesizer.get_data()) as epochs:
        for idx, (images, targets) in enumerate(epochs):
            optimizer.zero_grad(set_to_none=True)
            images = images.cuda()
            targets = targets.cuda().long()
            teacher.set_batch_targets(targets)

            with torch.no_grad():
                t_out = teacher(images)

            if min_teacher_conf > 0 or require_teacher_target:
                teacher_probs = F.softmax(t_out, dim=1)
                teacher_conf, teacher_pred = teacher_probs.max(dim=1)
                keep_mask = torch.ones_like(teacher_conf, dtype=torch.bool)
                if min_teacher_conf > 0:
                    keep_mask = keep_mask & (teacher_conf >= min_teacher_conf)
                if require_teacher_target:
                    keep_mask = keep_mask & teacher_pred.eq(targets)
                if keep_mask.sum().item() == 0:
                    continue
                images = images[keep_mask]
                targets = targets[keep_mask]
                t_out = t_out[keep_mask]

            s_out = student(images.detach())
            loss_kd = criterion(s_out, t_out.detach())
            if label_ce_weight > 0:
                loss_label_ce = F.cross_entropy(s_out, targets)
                loss_s = loss_kd + label_ce_weight * loss_label_ce
            else:
                loss_label_ce = torch.zeros((), device=s_out.device)
                loss_s = loss_kd

            loss_s.backward()
            torch.nn.utils.clip_grad_norm_(student.parameters(), max_norm=10.0)
            optimizer.step()

            total_loss += loss_s.detach().item()
            total_kd_loss += loss_kd.detach().item()
            total_label_ce_loss += loss_label_ce.detach().item()
            avg_loss = total_loss / (idx + 1)
            avg_kd_loss = total_kd_loss / (idx + 1)
            avg_label_ce_loss = total_label_ce_loss / (idx + 1)
            pred = s_out.argmax(dim=1)
            target = t_out.argmax(dim=1)
            correct += pred.eq(target.view_as(pred)).sum().item()
            seen += targets.size(0)
            acc = correct / max(seen, 1) * 100

            if args is not None and hasattr(args, "flogger"):
                if label_ce_weight > 0:
                    args.flogger.info(
                        f'[{idx}/{len(epochs)}: avg loss[{avg_loss}], '
                        f'kd[{avg_kd_loss}], label_ce[{avg_label_ce_loss}], acc[{acc}]'
                    )
                else:
                    args.flogger.info(f'[{idx}/{len(epochs)}: avg loss[{avg_loss}], acc[{acc}]')

            epochs.set_description(description.format(avg_loss, acc))


def save_checkpoint(state, is_best, filename='checkpoint.pth'):
    if is_best:
        torch.save(state, filename)


def get_dataset_spec(args):
    dataset = args.dataset.lower()
    if dataset in ["webvision", "webvision20"]:
        return {"num_classes": 20, "channels": 3, "img_size": 64, "img_shape": (3, 64, 64)}
    if dataset in ["mnist", "fmnist"]:
        return {"num_classes": 10, "channels": 1, "img_size": 28, "img_shape": (1, 28, 28)}
    if dataset in ["tiny", "tinyimagenet"]:
        return {"num_classes": 200, "channels": 3, "img_size": 64, "img_shape": (3, 64, 64)}
    if dataset in ["miniimagenet", "miniimage", "mini"]:
        return {"num_classes": 100, "channels": 3, "img_size": 84, "img_shape": (3, 84, 84)}
    return {"num_classes": 10, "channels": 3, "img_size": 32, "img_shape": (3, 32, 32)}


def get_normalization(args):
    dataset = args.dataset.lower()
    if dataset == "cifar10":
        return (0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)
    if dataset == "svhn":
        return (0.4377, 0.4438, 0.4728), (0.1980, 0.2010, 0.1970)
    if dataset in ["mnist", "fmnist"]:
        return (0.0,), (1.0,)
    return (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)


def normalize_generated_images(args, images):
    mean, std = get_normalization(args)
    mean = torch.tensor(mean, device=images.device, dtype=images.dtype).view(1, -1, 1, 1)
    std = torch.tensor(std, device=images.device, dtype=images.dtype).view(1, -1, 1, 1)
    return (images - mean) / std


def normalize_model_name(name):
    name = (name or "").strip().lower().replace("-", "_")
    aliases = {
        "": "resnet18",
        "server": "server",
        "resnet": "resnet18",
        "resnet_18": "resnet18",
        "resnet34": "resnet34",
        "resnet_34": "resnet34",
        "vgg": "vgg",
        "vgg11": "vgg",
        "googlenet": "googlenet",
        "google": "googlenet",
        "inception": "googlenet",
        "cnn": "cnn3",
        "3cnn": "cnn3",
        "cnn3": "cnn3",
        "three_cnn": "cnn3",
        "three_layer_cnn": "cnn3",
        "two_layer_cnn": "two_layer",
        "cnn2": "two_layer",
        "2cnn": "two_layer",
        "five_layer_cnn": "five_layer",
        "lenet": "lenet",
        "mnist_cnn": "five_layer",
        "fmnist_cnn": "five_layer",
    }
    return aliases.get(name, name)


def get_server_model_name(args):
    return normalize_model_name(args.server_model or args.model or "resnet18")


def get_num_classes(args):
    return get_dataset_spec(args)["num_classes"]


def get_model(args):
    return build_model_by_name(args, get_server_model_name(args)).cuda()


def use_heterogeneous_mnist_clients(args):
    return args.model in ["mnist_cnn", "fmnist_cnn"] and args.num_users == 5


def infer_client_model_types(args, num_clients):
    if args.client_models:
        requested = [normalize_model_name(x) for x in args.client_models.split(",") if x.strip()]
        if len(requested) == 0:
            raise ValueError("--client_models was provided but no valid model names were found.")
        return [requested[i % len(requested)] for i in range(num_clients)]
    if use_heterogeneous_mnist_clients(args):
        return ["two_layer"] * (num_clients - 1) + ["five_layer"]
    return ["server"] * num_clients


def build_model_by_name(args, model_name):
    model_name = normalize_model_name(model_name)
    if model_name == "server":
        model_name = get_server_model_name(args)
    spec = get_dataset_spec(args)
    num_classes = spec["num_classes"]
    channels = spec["channels"]
    img_size = spec["img_size"]

    if model_name == "two_layer":
        return CNNMnistTwoLayer(
            in_channels=channels,
            num_classes=num_classes,
            img_size=img_size,
        )
    if model_name == "five_layer":
        return CNNMnistFiveLayer(
            in_channels=channels,
            num_classes=num_classes,
            img_size=img_size,
        )
    if model_name == "cnn3":
        return CNN3(in_channels=channels, num_classes=num_classes)
    if model_name == "lenet":
        return LeNet(in_channels=channels, num_classes=num_classes, img_size=img_size)
    if model_name == "vgg":
        return VGGSmall(in_channels=channels, num_classes=num_classes)
    if model_name == "googlenet":
        return GoogleNetSmall(in_channels=channels, num_classes=num_classes)
    if model_name == "wrn_16_1":
        from models.wrn import wrn_16_1
        return wrn_16_1(num_classes=num_classes)
    if model_name == "wrn_16_2":
        from models.wrn import wrn_16_2
        return wrn_16_2(num_classes=num_classes)
    if model_name == "resnet18":
        from models.resnet import resnet18
        return resnet18(num_classes=num_classes, in_channels=channels)
    if model_name == "resnet34":
        from models.resnet import resnet34
        return resnet34(num_classes=num_classes, in_channels=channels)
    raise ValueError(
        f"Unsupported model '{model_name}'. Use cnn2, cnn3, resnet18, resnet34, vgg, lenet, googlenet, "
        "wrn_16_1, wrn_16_2, two_layer, or five_layer."
    )


def build_model_from_type(args, model_type):
    return build_model_by_name(args, model_type).cuda()


def get_client_model(args, client_idx, client_model_types=None):
    if client_model_types is None:
        client_model_types = infer_client_model_types(args, args.num_users)
    return build_model_from_type(args, client_model_types[client_idx])


def get_server_init_weights(args, local_weights, client_model_types=None, best_local_weights=None):
    source_weights = best_local_weights if best_local_weights is not None else local_weights
    if client_model_types is None:
        client_model_types = infer_client_model_types(args, len(source_weights))
    if use_heterogeneous_mnist_clients(args):
        deep_client_idx = client_model_types.index("five_layer")
        return copy.deepcopy(source_weights[deep_client_idx])
    server_name = get_server_model_name(args)
    compatible = [
        copy.deepcopy(w)
        for w, model_type in zip(source_weights, client_model_types)
        if normalize_model_name(model_type) in ["server", server_name]
    ]
    if len(compatible) > 0:
        return average_weights(compatible)
    return copy.deepcopy(get_model(args).state_dict())


def build_teacher_ensemble(args, local_weights, client_model_types=None):
    if client_model_types is None:
        client_model_types = infer_client_model_types(args, len(local_weights))
    model_list = []
    for idx in range(len(local_weights)):
        net = get_client_model(args, idx, client_model_types)
        net.load_state_dict(local_weights[idx])
        net.cuda()
        net.eval()
        model_list.append(net)
    return EnsemblePro(model_list).cuda()


def build_teacher_models(args, local_weights, client_model_types=None):
    if client_model_types is None:
        client_model_types = infer_client_model_types(args, len(local_weights))
    model_list = []
    for idx in range(len(local_weights)):
        net = get_client_model(args, idx, client_model_types)
        net.load_state_dict(local_weights[idx])
        net.cuda()
        net.eval()
        model_list.append(net)
    return model_list


def aggregate_feature_protos(client_feature_protos, num_classes=10):
    global_proto = {}

    for c in range(num_classes):
        means = []
        vars_ = []
        counts = []

        for proto in client_feature_protos:
            if c in proto:
                means.append(proto[c]["mean"])
                vars_.append(proto[c]["var"])
                counts.append(proto[c]["count"])

        if len(means) == 0:
            continue

        total = sum(counts)
        mean = sum([means[i] * counts[i] for i in range(len(means))]) / total
        var = sum([vars_[i] * counts[i] for i in range(len(vars_))]) / total

        global_proto[c] = {
            "mean": mean.cuda(),
            "var": var.cuda(),
            "count": total
        }

    return global_proto


class ClassAwareEnsemble(torch.nn.Module):
    def __init__(self, model_list, class_weights):
        super(ClassAwareEnsemble, self).__init__()
        self.models = torch.nn.ModuleList(model_list)
        weights = class_weights.detach().float()
        weights = weights / (weights.sum(dim=0, keepdim=True) + 1e-8)
        self.register_buffer("class_weights", weights)
        self.targets = None

    def set_batch_targets(self, targets):
        self.targets = targets.detach().long()

    def forward(self, x):
        logits = torch.stack([model(x) for model in self.models], dim=1)
        if self.targets is not None and self.targets.numel() == x.size(0):
            weights = self.class_weights[:, self.targets].t().unsqueeze(-1)
        else:
            with torch.no_grad():
                pred = logits.mean(dim=1).argmax(dim=1)
            weights = self.class_weights[:, pred].t().unsqueeze(-1)
        weights = weights / (weights.sum(dim=1, keepdim=True) + 1e-8)
        return (logits * weights).sum(dim=1)

    def compute_bn_loss(self, hooks):
        losses = []
        for hs in hooks.values():
            if len(hs) > 0:
                losses.append(sum(h.r_feature for h in hs))
        if len(losses) == 0:
            return torch.zeros((), device=self.class_weights.device)
        return sum(losses) / len(losses)


def attach_bn_hooks(model_list):
    hooks = {}
    for idx, model in enumerate(model_list):
        hooks[idx] = []
        for module in model.modules():
            if isinstance(module, torch.nn.BatchNorm2d):
                hooks[idx].append(DeepInversionHook(module))
    return hooks


def remove_hooks(hooks):
    for hs in hooks.values():
        for h in hs:
            h.remove()


def total_variation_loss(images):
    tv_h = torch.mean(torch.abs(images[:, :, 1:, :] - images[:, :, :-1, :]))
    tv_w = torch.mean(torch.abs(images[:, :, :, 1:] - images[:, :, :, :-1]))
    return tv_h + tv_w


def synthesize_bn_inversion_batch(args, teacher, teacher_models, class_weights, batch_size):
    spec = get_dataset_spec(args)
    num_classes = spec["num_classes"]
    labels = sample_global_labels(class_weights, batch_size, num_classes)
    raw = torch.randn(
        batch_size,
        spec["channels"],
        spec["img_size"],
        spec["img_size"],
        device="cuda",
        requires_grad=True,
    )
    optimizer = torch.optim.Adam([raw], lr=0.08)
    hooks = attach_bn_hooks(teacher_models)
    try:
        teacher.eval()
        teacher.set_batch_targets(labels)
        best_loss = None
        best_images = None
        steps = max(20, min(160, args.g_steps * 4))
        for _ in range(steps):
            raw_images = torch.sigmoid(raw)
            images = normalize_generated_images(args, raw_images)
            logits = teacher(images)
            loss_oh = F.cross_entropy(logits, labels)
            loss_bn = teacher.compute_bn_loss(hooks)
            probs = F.softmax(logits, dim=1)
            entropy = -(probs * torch.log(probs + 1e-8)).sum(dim=1).mean()
            loss_tv = total_variation_loss(raw_images)
            loss = loss_oh + 0.08 * loss_bn + 0.001 * loss_tv - 0.01 * entropy
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            if best_loss is None or loss.detach().item() < best_loss:
                best_loss = loss.detach().item()
                best_images = images.detach()
        return best_images, labels
    finally:
        remove_hooks(hooks)


def make_synthetic_generator(args, semantic_dim):
    spec = get_dataset_spec(args)
    from models.oscofl_sgg import SemanticGuidedGenerator
    return SemanticGuidedGenerator(
        nz=args.nz,
        num_classes=spec["num_classes"],
        feature_dim=semantic_dim,
        img_size=spec["img_size"],
        nc=spec["channels"],
        ngf=64,
        semantic_dim=min(128, max(32, semantic_dim * 4)),
    ).cuda()


def train_persistent_generator(args, generator, teacher, teacher_models, global_centers,
                               class_weights, steps):
    generator.train()
    teacher.eval()
    optimizer = torch.optim.Adam(generator.parameters(), lr=args.lr_g, betas=(0.5, 0.999))
    hooks = attach_bn_hooks(teacher_models)
    metrics = {"loss": 0.0, "target_acc": 0.0, "confidence": 0.0}
    try:
        for _ in range(steps):
            labels = sample_global_labels(
                class_weights,
                args.synthesis_batch_size,
                get_num_classes(args),
            )
            z = torch.randn(labels.size(0), args.nz, device="cuda")
            raw_images = generator(z, labels, global_centers[labels].detach())
            images = normalize_generated_images(args, raw_images)
            teacher.set_batch_targets(labels)
            logits = teacher(images)
            probs = F.softmax(logits, dim=1)

            loss_oh = F.cross_entropy(logits, labels)
            loss_bn = teacher.compute_bn_loss(hooks)
            loss_tv = total_variation_loss(raw_images)
            permutation = torch.randperm(z.size(0), device=z.device)
            image_distance = (raw_images - raw_images[permutation]).abs().flatten(1).mean(dim=1)
            noise_distance = (z - z[permutation]).abs().mean(dim=1)
            loss_div = -(image_distance / (noise_distance + 1e-5)).mean()
            loss = loss_oh + 0.05 * loss_bn + 0.001 * loss_tv + 0.05 * loss_div

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(generator.parameters(), max_norm=5.0)
            optimizer.step()

            metrics["loss"] += loss.detach().item()
            metrics["target_acc"] += logits.argmax(dim=1).eq(labels).float().mean().item()
            metrics["confidence"] += probs.max(dim=1)[0].mean().item()
    finally:
        remove_hooks(hooks)

    denom = max(steps, 1)
    return {key: value / denom for key, value in metrics.items()}


def build_generator_bank(args, generator, global_centers, class_weights, batches=12,
                         seed=None, balanced=True):
    generator.eval()
    bank = []
    devices = [torch.cuda.current_device()] if torch.cuda.is_available() else []
    with torch.random.fork_rng(devices=devices):
        if seed is not None:
            torch.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
        with torch.no_grad():
            for _ in range(batches):
                if balanced:
                    num_classes = get_num_classes(args)
                    repeats = int(np.ceil(args.synthesis_batch_size / float(num_classes)))
                    labels = torch.arange(num_classes, device="cuda").repeat(repeats)
                    labels = labels[:args.synthesis_batch_size]
                    labels = labels[torch.randperm(labels.numel(), device=labels.device)]
                else:
                    labels = sample_global_labels(
                        class_weights,
                        args.synthesis_batch_size,
                        get_num_classes(args),
                    )
                z = torch.randn(labels.size(0), args.nz, device="cuda")
                raw_images = generator(z, labels, global_centers[labels])
                images = normalize_generated_images(args, raw_images)
                bank.append((images.detach(), labels.detach()))
    return bank


def sample_global_labels(class_weights, batch_size, num_classes):
    if class_weights is None:
        probs = torch.ones(num_classes, device="cuda") / num_classes
    else:
        class_mass = class_weights.sum(dim=0).float().cuda()
        probs = class_mass / (class_mass.sum() + 1e-8)
        probs = 0.85 * probs + 0.15 / num_classes
    return torch.multinomial(probs, batch_size, replacement=True).long()


def make_semantic_images(generator, labels, global_centers, nz):
    z = torch.randn(labels.size(0), nz, device="cuda")
    centers = global_centers[labels].detach()
    return generator(z, labels, centers)


def kd_loss_from_logits(student_logits, teacher_logits, temperature=3.0):
    teacher_probs = F.softmax(teacher_logits.detach() / temperature, dim=1)
    return F.kl_div(
        F.log_softmax(student_logits / temperature, dim=1),
        teacher_probs,
        reduction="batchmean",
    ) * (temperature ** 2)


def bounded_probability_distill_loss(student_logits, teacher_logits, temperature=2.0):
    student_probs = F.softmax(student_logits / temperature, dim=1)
    teacher_probs = F.softmax(teacher_logits.detach() / temperature, dim=1)
    return F.mse_loss(student_probs, teacher_probs) * student_logits.size(1)


def blend_state_dict(base_state, candidate_state, alpha):
    blended = {}
    for key, base_value in base_state.items():
        candidate_value = candidate_state[key]
        if torch.is_floating_point(base_value):
            blended[key] = (1.0 - alpha) * base_value + alpha * candidate_value
        else:
            blended[key] = candidate_value
    return blended


def augment_synthetic_batch(args, images):
    augmented = images
    if images.size(-1) >= 24:
        padding = 2 if args.dataset.lower() == "svhn" else 4
        padded = F.pad(images, (padding, padding, padding, padding), mode="reflect")
        offset_y = int(torch.randint(0, 2 * padding + 1, (1,)).item())
        offset_x = int(torch.randint(0, 2 * padding + 1, (1,)).item())
        augmented = padded[
            :,
            :,
            offset_y:offset_y + images.size(-2),
            offset_x:offset_x + images.size(-1),
        ]
    if args.dataset.lower() in ["cifar10", "cifar100"]:
        flip_mask = torch.rand(augmented.size(0), device=augmented.device) < 0.5
        augmented[flip_mask] = torch.flip(augmented[flip_mask], dims=[3])
    return augmented + 0.01 * torch.randn_like(augmented)


def evaluate_synthetic_proxy(model, synthetic_bank):
    model.eval()
    total_loss = 0.0
    total_correct = 0
    total_examples = 0
    with torch.no_grad():
        for images, labels in synthetic_bank:
            if hasattr(model, "set_batch_targets"):
                model.set_batch_targets(labels)
            logits = model(images)
            total_loss += F.cross_entropy(logits, labels, reduction="sum").item()
            total_correct += logits.argmax(dim=1).eq(labels).sum().item()
            total_examples += labels.numel()
    return (
        100.0 * total_correct / max(total_examples, 1),
        total_loss / max(total_examples, 1),
    )


def train_uplink_server_epoch(args, server_model, teacher_model, teacher_models,
                              class_weights, optimizer, batches, synthetic_bank=None):
    server_model.train()
    teacher_model.eval()
    totals = {"loss": 0.0, "ce": 0.0, "kd": 0.0, "consistency": 0.0}
    used = 0
    for _ in range(batches):
        images, labels = sample_synthetic_bank(synthetic_bank or [], args.batch_size)
        if images is None:
            images, labels = synthesize_bn_inversion_batch(
                args,
                teacher_model,
                teacher_models,
                class_weights,
                batch_size=args.batch_size,
            )
        if hasattr(teacher_model, "set_batch_targets"):
            teacher_model.set_batch_targets(labels)
        images = augment_synthetic_batch(args, images)
        with torch.no_grad():
            teacher_logits = teacher_model(images)
            teacher_probs = F.softmax(teacher_logits, dim=1)
            conf, pred = teacher_probs.max(dim=1)
            keep = (conf >= 0.35) | pred.eq(labels)
        if keep.sum().item() == 0:
            keep = torch.zeros_like(conf, dtype=torch.bool)
            top_count = max(1, conf.numel() // 4)
            keep[conf.topk(top_count).indices] = True
        images = images[keep]
        labels = labels[keep]
        teacher_logits = teacher_logits[keep]
        optimizer.zero_grad(set_to_none=True)
        student_logits = server_model(images)
        loss_kd = kd_loss_from_logits(student_logits, teacher_logits, temperature=max(args.T, 3.0))
        loss_ce = F.cross_entropy(student_logits, labels)
        second_logits = server_model(augment_synthetic_batch(args, images))
        loss_consistency = bounded_probability_distill_loss(
            second_logits,
            student_logits.detach(),
            temperature=2.0,
        )
        loss = loss_ce + args.uplink_kd * loss_kd + 0.10 * loss_consistency
        loss.backward()
        torch.nn.utils.clip_grad_norm_(server_model.parameters(), max_norm=2.0)
        optimizer.step()
        totals["loss"] += loss.detach().item()
        totals["ce"] += loss_ce.detach().item()
        totals["kd"] += loss_kd.detach().item()
        totals["consistency"] += loss_consistency.detach().item()
        used += 1
    return {key: value / max(used, 1) for key, value in totals.items()}


def sample_synthetic_bank(synthetic_bank, batch_size):
    if len(synthetic_bank) == 0:
        return None, None
    bank_index = int(torch.randint(0, len(synthetic_bank), (1,)).item())
    images, labels = synthetic_bank[bank_index]
    idx = torch.randint(0, images.size(0), (batch_size,), device=images.device)
    return images[idx], labels[idx]


def train_downlink_client_epoch(args, client_model, teacher_model, local_loader,
                                optimizer, synthetic_bank=None):
    client_model.train()
    teacher_model.eval()
    total = {
        "loss": 0.0,
        "ce_real": 0.0,
        "ce_synth": 0.0,
        "kd_real": 0.0,
        "kd_synth": 0.0,
    }
    batches = 0
    for real_images, real_labels in local_loader:
        real_images = real_images.cuda()
        real_labels = real_labels.cuda().long()

        with torch.no_grad():
            teacher_real_logits = teacher_model(real_images)
            teacher_real_probs = F.softmax(teacher_real_logits, dim=1)
            teacher_real_conf = teacher_real_probs.max(dim=1)[0]

        optimizer.zero_grad(set_to_none=True)
        real_logits = client_model(real_images)
        loss_ce = F.cross_entropy(real_logits, real_labels)
        student_real_conf = F.softmax(real_logits.detach(), dim=1).max(dim=1)[0]
        real_mask = (
            teacher_real_logits.argmax(dim=1).eq(real_labels)
            | (teacher_real_conf > student_real_conf + 0.05)
        )
        if real_mask.any():
            loss_kd_real = torch.log1p(
                kd_loss_from_logits(
                    real_logits[real_mask],
                    teacher_real_logits[real_mask],
                    temperature=args.downlink_temperature,
                )
            )
        else:
            loss_kd_real = torch.zeros((), device=real_logits.device)

        fake_images, fake_labels = sample_synthetic_bank(
            synthetic_bank or [],
            real_images.size(0),
        )
        if fake_images is not None:
            fake_images = augment_synthetic_batch(args, fake_images)
            with torch.no_grad():
                teacher_fake_logits = teacher_model(fake_images)
            fake_logits = client_model(fake_images)
            loss_ce_synth = F.cross_entropy(fake_logits, fake_labels)
            loss_kd_synth = torch.log1p(
                kd_loss_from_logits(
                    fake_logits,
                    teacher_fake_logits,
                    temperature=args.downlink_temperature,
                )
            )
        else:
            loss_ce_synth = torch.zeros((), device=real_logits.device)
            loss_kd_synth = torch.zeros((), device=real_logits.device)

        loss = (
            args.downlink_ce * loss_ce
            + loss_ce_synth
            + args.downlink_kd * loss_kd_real
            + args.downlink_kd * loss_kd_synth
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(client_model.parameters(), max_norm=2.0)
        optimizer.step()

        total["loss"] += loss.detach().item()
        total["ce_real"] += loss_ce.detach().item()
        total["ce_synth"] += loss_ce_synth.detach().item()
        total["kd_real"] += loss_kd_real.detach().item()
        total["kd_synth"] += loss_kd_synth.detach().item()
        batches += 1
    return {k: v / max(batches, 1) for k, v in total.items()}


def evaluate_downlink_proxy(client_model, local_val_loader, synthetic_proxy_bank):
    synthetic_acc, synthetic_loss = evaluate_synthetic_proxy(
        client_model,
        synthetic_proxy_bank,
    )
    local_val_acc, local_val_loss = test(client_model, local_val_loader)
    score = 0.70 * synthetic_acc + 0.30 * local_val_acc
    return score, synthetic_acc, local_val_acc, synthetic_loss, local_val_loss


def run_oscofl_bidirectional(args, train_dataset, test_loader, user_groups, client_stats,
                             local_weights, client_model_types):
    args.flogger.info("========== OS-CoFL Bidirectional (validation-clean) ==========")
    is_svhn = args.dataset.lower() == "svhn"
    configured_server_target = (
        float(args.server_target_acc)
        if args.server_target_acc > 0
        else float(args.target_acc)
    )
    required_server_acc = max(configured_server_target, 62.1 if is_svhn else 0.0)
    args.flogger.info(
        f"[BiKD][Validation] required server test accuracy > {required_server_acc:.4f}; "
        f"required client test accuracy > {args.target_acc:.4f}"
    )
    _, global_centers, class_weights = aggregate_client_stats(client_stats, device="cuda")
    model_list = build_teacher_models(args, local_weights, client_model_types)
    teacher_ensemble = ClassAwareEnsemble(model_list, class_weights).cuda()
    teacher_ensemble.eval()

    server_model = get_model(args).cuda()
    server_initial_state = copy.deepcopy(server_model.state_dict())
    server_before_acc, server_before_loss = test(server_model, test_loader)
    args.flogger.info(
        f"[BiKD][Uplink] independent random server | "
        f"test_acc={server_before_acc:.4f}, test_loss={server_before_loss:.4f}"
    )

    generator = make_synthetic_generator(args, semantic_dim=global_centers.size(1))
    generator_metrics = train_persistent_generator(
        args,
        generator,
        teacher_ensemble,
        model_list,
        global_centers,
        class_weights,
        steps=max(360 if is_svhn else 240, args.g_steps * (15 if is_svhn else 12)),
    )
    best_generator_metrics = dict(generator_metrics)
    best_generator_state = copy.deepcopy(generator.state_dict())
    synthetic_bank = build_generator_bank(
        args,
        generator,
        global_centers,
        class_weights,
        batches=24 if is_svhn else 20,
        seed=args.seed + 1001,
        balanced=True,
    )
    synthetic_proxy_bank = build_generator_bank(
        args,
        generator,
        global_centers,
        class_weights,
        batches=20 if is_svhn else 16,
        seed=args.seed + 2003,
        balanced=True,
    )
    generator_proxy_teacher_acc, generator_proxy_teacher_loss = evaluate_synthetic_proxy(
        teacher_ensemble,
        synthetic_proxy_bank,
    )
    args.flogger.info(
        f"[BiKD][Generator] loss={generator_metrics['loss']:.4f} "
        f"target_acc={generator_metrics['target_acc'] * 100:.2f} "
        f"confidence={generator_metrics['confidence']:.4f} | "
        f"fixed_proxy_teacher_acc={generator_proxy_teacher_acc:.4f} "
        f"fixed_proxy_teacher_loss={generator_proxy_teacher_loss:.4f}"
    )

    uplink_epochs = max(args.epochs, 50 if is_svhn else 30)
    optimizer_s = torch.optim.AdamW(
        server_model.parameters(),
        lr=min(max(args.lr, 3e-4), 1e-3),
        weight_decay=5e-4,
    )
    scheduler_s = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer_s,
        T_max=uplink_epochs,
        eta_min=1e-5,
    )
    best_server_proxy_acc, best_server_proxy_loss = evaluate_synthetic_proxy(
        server_model,
        synthetic_proxy_bank,
    )
    best_server_state = copy.deepcopy(server_model.state_dict())
    last_uplink_train_log = None

    for epoch in range(uplink_epochs):
        if epoch > 0 and epoch % 6 == 0:
            candidate_metrics = train_persistent_generator(
                args,
                generator,
                teacher_ensemble,
                model_list,
                global_centers,
                class_weights,
                steps=max(60 if is_svhn else 40, args.g_steps * 2),
            )
            if candidate_metrics["target_acc"] >= best_generator_metrics["target_acc"]:
                best_generator_metrics = dict(candidate_metrics)
                best_generator_state = copy.deepcopy(generator.state_dict())
            else:
                generator.load_state_dict(best_generator_state)
            synthetic_bank = build_generator_bank(
                args,
                generator,
                global_centers,
                class_weights,
                batches=24 if is_svhn else 20,
                seed=args.seed + 1001 + epoch,
                balanced=True,
            )

        train_log = train_uplink_server_epoch(
            args,
            server_model,
            teacher_ensemble,
            model_list,
            class_weights,
            optimizer_s,
            batches=max(args.g_steps, 28 if is_svhn else 20),
            synthetic_bank=synthetic_bank,
        )
        last_uplink_train_log = dict(train_log)
        scheduler_s.step()
        proxy_acc, proxy_loss = evaluate_synthetic_proxy(
            server_model,
            synthetic_proxy_bank,
        )
        if (
            proxy_acc > best_server_proxy_acc
            or (
                abs(proxy_acc - best_server_proxy_acc) < 1e-8
                and proxy_loss < best_server_proxy_loss
            )
        ):
            best_server_proxy_acc = proxy_acc
            best_server_proxy_loss = proxy_loss
            best_server_state = copy.deepcopy(server_model.state_dict())
        args.flogger.info(
            f"[BiKD][Uplink] Epoch {epoch:03d} | loss={train_log['loss']:.4f} "
            f"ce={train_log['ce']:.4f} kd={train_log['kd']:.4f} "
            f"consistency={train_log['consistency']:.4f} | "
            f"proxy_acc={proxy_acc:.4f} proxy_loss={proxy_loss:.4f} | "
            f"best_proxy_acc={best_server_proxy_acc:.4f}"
        )

    server_model.load_state_dict(best_server_state)
    best_server_acc, best_server_loss = test(server_model, test_loader)
    args.flogger.info(
        f"[BiKD][Uplink] final test (not used for selection) | "
        f"before={server_before_acc:.4f}, after={best_server_acc:.4f}, "
        f"gain={best_server_acc - server_before_acc:+.4f}"
    )

    os.makedirs("df_ckpt", exist_ok=True)
    torch.save(
        {
            "server_initial_state": server_initial_state,
            "server_model": best_server_state,
            "generator": copy.deepcopy(best_generator_state),
            "synthetic_bank": [(x.cpu(), y.cpu()) for x, y in synthetic_bank],
            "synthetic_proxy_bank": [(x.cpu(), y.cpu()) for x, y in synthetic_proxy_bank],
            "server_proxy_acc": float(best_server_proxy_acc),
            "generator_proxy_teacher_acc": float(generator_proxy_teacher_acc),
            "server_before_acc": float(server_before_acc),
            "server_after_acc": float(best_server_acc),
            "server_after_loss": float(best_server_loss),
            "client_model_types": client_model_types,
            "selection_protocol": "synthetic_proxy_only",
        },
        f"df_ckpt/{args.timestr}-oscofl-bidirectional-server.pth"
    )

    client_acc_before = []
    client_acc_after = []
    client_proxy_before = []
    client_proxy_after = []
    client_last_loss_terms = []
    updated_client_weights = []
    downlink_epochs = max(args.downlink_epochs, 10)
    for idx in range(args.num_users):
        local_update = LocalUpdate(
            args=args,
            dataset=train_dataset,
            idxs=user_groups[idx],
        )
        client_model = get_client_model(args, idx, client_model_types)
        client_model.load_state_dict(local_weights[idx])
        client_model.cuda()

        before_acc, _ = test(client_model, test_loader)
        before_score, before_synth_acc, before_val_acc, _, _ = evaluate_downlink_proxy(
            client_model,
            local_update.val_loader,
            synthetic_proxy_bank,
        )
        client_acc_before.append(before_acc)
        client_proxy_before.append(before_score)
        best_client_score = before_score
        best_client_state = copy.deepcopy(client_model.state_dict())
        best_client_synth_acc = before_synth_acc
        best_client_val_acc = before_val_acc

        optimizer_c = torch.optim.AdamW(
            client_model.parameters(),
            lr=max(args.downlink_lr, 1e-4),
            weight_decay=5e-4,
        )
        scheduler_c = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer_c,
            T_max=downlink_epochs,
            eta_min=1e-5,
        )
        for ep in range(downlink_epochs):
            log_dict = train_downlink_client_epoch(
                args,
                client_model,
                server_model,
                local_update.train_loader,
                optimizer_c,
                synthetic_bank=synthetic_bank,
            )
            scheduler_c.step()
            score, synth_acc, val_acc, synth_loss, val_loss = evaluate_downlink_proxy(
                client_model,
                local_update.val_loader,
                synthetic_proxy_bank,
            )
            if score > best_client_score:
                best_client_score = score
                best_client_state = copy.deepcopy(client_model.state_dict())
                best_client_synth_acc = synth_acc
                best_client_val_acc = val_acc
            args.flogger.info(
                f"[BiKD][Downlink][Client {idx}] Epoch {ep:02d} | "
                f"loss={log_dict['loss']:.4f} real_ce={log_dict['ce_real']:.4f} "
                f"synth_ce={log_dict['ce_synth']:.4f} "
                f"kd_real={log_dict['kd_real']:.4f} kd_synth={log_dict['kd_synth']:.4f} | "
                f"proxy={score:.4f} synth_acc={synth_acc:.4f} val_acc={val_acc:.4f} "
                f"synth_loss={synth_loss:.4f} val_loss={val_loss:.4f}"
            )

        client_model.load_state_dict(best_client_state)
        client_last_loss_terms.append(dict(log_dict))
        after_acc, _ = test(client_model, test_loader)
        client_acc_after.append(after_acc)
        client_proxy_after.append(best_client_score)
        updated_client_weights.append(copy.deepcopy(best_client_state))
        args.flogger.info(
            f"[BiKD][Downlink][Client {idx}] final test (not used for selection) | "
            f"before={before_acc:.4f}, after={after_acc:.4f}, gain={after_acc - before_acc:+.4f} | "
            f"proxy={before_score:.4f}->{best_client_score:.4f}, "
            f"synth={before_synth_acc:.4f}->{best_client_synth_acc:.4f}, "
            f"local_val={before_val_acc:.4f}->{best_client_val_acc:.4f}"
        )

    torch.save(
        {
            "updated_client_weights": updated_client_weights,
            "client_acc_before": client_acc_before,
            "client_acc_after": client_acc_after,
            "client_proxy_before": client_proxy_before,
            "client_proxy_after": client_proxy_after,
            "server_before_acc": float(server_before_acc),
            "server_after_acc": float(best_server_acc),
            "client_model_types": client_model_types,
            "selection_protocol": "0.70_synthetic_proxy_plus_0.30_local_validation",
        },
        f"df_ckpt/{args.timestr}-oscofl-bidirectional-clients.pth"
    )
    args.flogger.info(f"[BiKD] client_acc_before: {client_acc_before}")
    args.flogger.info(f"[BiKD] client_acc_after: {client_acc_after}")

    generator_target_acc = float(best_generator_metrics["target_acc"] * 100.0)
    target_failures = []
    if best_server_acc <= server_before_acc:
        target_failures.append(
            f"server did not improve ({server_before_acc:.4f} -> {best_server_acc:.4f})"
        )
    if best_server_acc <= required_server_acc:
        target_failures.append(
            f"server accuracy {best_server_acc:.4f} is not above "
            f"target {required_server_acc:.4f}"
        )
    if generator_target_acc < args.target_acc:
        target_failures.append(
            f"generator target accuracy {generator_target_acc:.4f} < target {args.target_acc:.4f}"
        )
    if generator_proxy_teacher_acc < args.target_acc:
        target_failures.append(
            f"generator fixed-proxy teacher accuracy {generator_proxy_teacher_acc:.4f} "
            f"< target {args.target_acc:.4f}"
        )
    for idx, (before_acc, after_acc) in enumerate(zip(client_acc_before, client_acc_after)):
        if after_acc <= before_acc:
            target_failures.append(
                f"client {idx} did not improve ({before_acc:.4f} -> {after_acc:.4f})"
            )
        if after_acc <= args.target_acc:
            target_failures.append(
                f"client {idx} accuracy {after_acc:.4f} is not above "
                f"target {args.target_acc:.4f}"
            )

    validation_report = {
        "server_before": float(server_before_acc),
        "server_after": float(best_server_acc),
        "server_proxy_acc": float(best_server_proxy_acc),
        "generator_target_acc": generator_target_acc,
        "generator_proxy_teacher_acc": float(generator_proxy_teacher_acc),
        "uplink_last_loss_terms": last_uplink_train_log,
        "client_before": client_acc_before,
        "client_after": client_acc_after,
        "client_proxy_before": client_proxy_before,
        "client_proxy_after": client_proxy_after,
        "client_last_loss_terms": client_last_loss_terms,
        "target_acc": float(args.target_acc),
        "server_target_acc": float(required_server_acc),
        "passed": len(target_failures) == 0,
        "failures": target_failures,
        "test_set_used_for_selection": False,
        "parameter_copying_used": False,
        "uplink_kd_weight": float(args.uplink_kd),
        "downlink_kd_weight": float(args.downlink_kd),
    }
    torch.save(
        validation_report,
        f"df_ckpt/{args.timestr}-oscofl-bidirectional-validation.pth"
    )
    args.flogger.info(f"[BiKD][Validation] {validation_report}")
    if args.strict_target and target_failures:
        raise RuntimeError("Bidirectional target validation failed: " + "; ".join(target_failures))
    return server_model


if __name__ == '__main__':

    args = args_parser()
    # 在当前工作目录下创建一个名为 logs 的文件夹（目录），用来存放程序运行时的日志文件。
    os.makedirs('logs', exist_ok=True)
    # ① os
        # 是 Python 自带的操作系统交互模块，专门用来处理文件、文件夹、路径等系统操作。
        # 不需要额外安装，直接用。
    # ② os.makedirs()
        # 核心功能：创建文件夹（目录）
        # 和 os.mkdir() 的区别：
            # os.mkdir()：只能创建单层文件夹
            # os.makedirs()：可以创建多层嵌套文件夹（比如 a/b/c）
    # ③ 'logs'
        # 要创建的文件夹名称
        # 这里就是创建一个名字叫 logs 的文件夹
        # 位置：默认在当前代码运行的同级目录下
    # ④ exist_ok=True
        # 这是关键参数
        # 意思：如果文件夹已经存在，不报错，直接忽略
        # 如果不写这个参数（默认 exist_ok=False）：
            # 文件夹已存在 → 程序直接抛出 FileExistsError 错误
    args.flogger = get_logger(f"logs/{args.timestr}_{args.dataset}_{args.num_users}clients.log")
    args.swanlab_run = init_swanlab(args)

    setup_seed(args.seed)
    # pdb.set_trace()
    (
        train_dataset,
        test_dataset,
        user_groups,
        traindata_cls_counts,
        split_metadata,
    ) = partition_data(
        args.dataset,
        args.partition,
        beta=args.beta,
        num_users=args.num_users,
        split_file=args.split_file,
        save_split_path=args.save_split_file,
        seed=args.seed,
        data_root=args.data_root,
    )
    args.split_metadata = split_metadata
    if args.data_root:
        args.flogger.info(f"Dataset root: {args.data_root}")
    split_source = args.split_file if args.split_file else args.save_split_file
    if split_source:
        args.flogger.info(
            f"Client split source: {split_source} | partition={split_metadata.get('partition')} "
            f"| seed={split_metadata.get('seed')} | index_space={split_metadata.get('index_space')}"
        )
    if args.split_only:
        if args.save_split_file:
            args.flogger.info(f"Split file written to {args.save_split_file}")
        else:
            args.flogger.info("Split file validated successfully.")
        sys.exit(0)

    client_test_loader = build_full_test_loader(test_dataset)
    server_eval_loader = build_full_test_loader(test_dataset)
    server_case_loader = build_test_loader(args, test_dataset)
    if len(server_case_loader.dataset) < len(test_dataset):
        subset_seed = args.test_subset_seed if args.test_subset_seed >= 0 else args.seed
        args.flogger.info(
            f"Server training/evaluation uses the full test set: {len(test_dataset)} examples; "
            f"final server case-test uses a sampled subset of {len(server_case_loader.dataset)} "
            f"examples (seed={subset_seed}). Client evaluation keeps the full test set."
        )
    else:
        args.flogger.info(
            f"Server and client evaluation both use the full test set: {len(test_dataset)} examples."
        )
    # BUILD MODEL
    global_model = get_model(args)
    bst_acc = -1
    description = "inference acc={:.4f}% loss={:.2f}, best_acc = {:.2f}%"
    local_weights = []
    global_model.train()
    acc_list = []
    users = []
    if args.type == "pretrain":
        # ===============================================
        # 第一阶段：联邦学习的客户端预训练过程 (FedAvg 基础思想)
        # 这里模拟 num_users（所有的参与方，比如 5 个客户端）。
        # 每个客户端由于数据不互通（孤岛），只能使用仅有的本地数据训练。
        client_stats = []
        final_local_weights = []
        best_local_weights = []
        client_model_types = infer_client_model_types(args, args.num_users)
        resumed_client_weights = None
        if args.client_init_checkpoint:
            resume_ckpt = torch.load(args.client_init_checkpoint, map_location="cpu")
            resumed_client_weights = resume_ckpt.get(
                "client_models",
                resume_ckpt.get("best_weights", resume_ckpt.get("weights")),
            )
            if resumed_client_weights is None:
                raise ValueError(
                    f"Client init checkpoint {args.client_init_checkpoint} "
                    "does not contain client_models, best_weights, or weights."
                )
            resumed_types = resume_ckpt.get("client_model_types", client_model_types)
            if list(resumed_types) != list(client_model_types):
                raise ValueError(
                    "Client init checkpoint model types do not match --client_models: "
                    f"saved={resumed_types}, requested={client_model_types}"
                )
            if len(resumed_client_weights) != args.num_users:
                raise ValueError(
                    f"Client init checkpoint has {len(resumed_client_weights)} models; "
                    f"expected {args.num_users}."
                )
            args.flogger.info(
                f"Communication round {args.communication_round}/{args.communication_rounds}: "
                f"continuing clients from {args.client_init_checkpoint} at local epoch "
                f"{args.local_epoch_offset + 1}."
            )
        shared_client_initializations = {}
        if resumed_client_weights is None:
            for model_type in sorted(set(client_model_types)):
                template = build_model_from_type(args, model_type)
                shared_client_initializations[model_type] = copy.deepcopy(template.state_dict())
                del template
        for idx in range(args.num_users):
            users.append("client_{}".format(idx))
            # 创建属于当前客户端 idx 的训练对象，传给他专属于他的数据分组 user_groups[idx]
            local_model = LocalUpdate(args=args, dataset=train_dataset,
                                      idxs=user_groups[idx])
            
            client_model = get_client_model(args, idx, client_model_types)
            if resumed_client_weights is None:
                initial_state = shared_client_initializations[client_model_types[idx]]
            else:
                initial_state = resumed_client_weights[idx]
            client_model.load_state_dict(copy.deepcopy(initial_state))
            (
                w,
                local_acc,
                local_test_acc,
                best_w,
                best_local_acc,
                local_train_seconds,
            ) = local_model.update_weights(client_model, idx, test_loader=client_test_loader)
            final_local_acc = float(local_acc[-1]) if len(local_acc) > 0 else float("nan")
            client_model.load_state_dict(best_w)
            client_model.cuda()
            client_model.eval()
            final_test_acc, final_test_loss = test(client_model, client_test_loader)
            args.flogger.info(
                f"client {idx} pretrain finished | final_local_val={final_local_acc:.4f} | "
                f"best_local_val={float(best_local_acc):.4f} | "
                f"final_test_acc={final_test_acc:.4f}, final_test_loss={final_test_loss:.4f}"
            )
            # Build the one-shot upload payload selected by the algorithm.
            model_only_upload = (
                args.algorithm == "fedbicert"
                and args.bicert_ablation == "a1_model_only"
            )
            if args.algorithm == "fedbicert" and not model_only_upload:
                from utils.risk_certificate import extract_risk_certificate
                stat = extract_risk_certificate(
                    model=client_model,
                    train_loader=local_model.train_loader,
                    val_loader=local_model.val_loader,
                    num_classes=get_num_classes(args),
                    device=torch.device("cuda"),
                )
                from fedbicert import generate_client_synthetic_anchor_payload
                anchor_payload = generate_client_synthetic_anchor_payload(
                    args=args,
                    model=client_model,
                    certificate=stat,
                    device=torch.device("cuda"),
                    train_loader=local_model.train_loader,
                )
                stat.update(anchor_payload)
            elif args.algorithm == "fedbicert":
                stat = {"protocol": "fedbicert_model_only_upload_v1"}
            else:
                stat = local_model.extract_oscofl_stats(
                    model=client_model,
                    num_classes=get_num_classes(args),
                    temperature=2.0
                )
            stat["local_val_acc"] = torch.tensor(float(best_local_acc))
            stat["local_test_acc"] = torch.tensor(float(final_test_acc))
            stat["local_train_seconds"] = torch.tensor(float(local_train_seconds))
            if args.algorithm in ["oscofl_bidirectional", "oscofl_bikd", "oscofl_stage9"]:
                stat.pop("real_labels", None)

            if args.algorithm == "fedbicert" and not model_only_upload:
                stat_keys = [
                    "temperature",
                    "class_counts",
                    "feature_mean",
                    "feature_var",
                    "margin_mean",
                    "margin_std",
                    "class_correct",
                    "class_total",
                    "reliability",
                    "class_nll",
                    "class_confidence",
                    "class_logit_mean",
                    "class_logit_var",
                    "class_prob_mean",
                ]
            elif args.algorithm == "fedbicert":
                stat_keys = [
                    "local_val_acc",
                    "local_test_acc",
                    "local_train_seconds",
                ]
            else:
                stat_keys = [
                    "class_probs",
                    "class_centers",
                    "class_counts",
                    "client_embedding",
                    "label_hist",
                ]
            for key in stat_keys:
                if not torch.isfinite(stat[key]).all():
                    raise ValueError(f"Client {idx} stat {key} contains non-finite values!")
            if args.algorithm == "fedbicert" and not model_only_upload:
                for key in [
                    "synthetic_anchor_images",
                    "synthetic_anchor_labels",
                    "synthetic_anchor_logits",
                    "synthetic_anchor_scores",
                ]:
                    if key in stat and torch.is_tensor(stat[key]):
                        if not torch.isfinite(stat[key]).all():
                            raise ValueError(
                                f"Client {idx} anchor field {key} contains non-finite values!"
                            )
            
            if "class_counts" in stat:
                args.flogger.info(
                    f"client {idx} class_counts: "
                    f"{stat['class_counts'].numpy().astype(int).tolist()}"
                )
            if args.algorithm == "fedbicert" and model_only_upload:
                args.flogger.info(
                    f"client {idx} upload payload: one model checkpoint only "
                    "(A1 model-only ablation)"
                )
            elif args.algorithm == "fedbicert":
                anchor_count = int(
                    stat.get(
                        "synthetic_anchor_labels",
                        torch.empty(0, dtype=torch.long),
                    ).numel()
                )
                anchor_protocol = stat.get("synthetic_anchor_protocol", "unknown")
                args.flogger.info(
                    f"client {idx} upload payload: one model checkpoint and "
                    f"a calibrated model-local risk certificate plus "
                    f"{anchor_count} client-side synthetic anchors "
                    f"({anchor_protocol}); "
                    f"feature_dim={stat['feature_mean'].size(1)}"
                )
            else:
                args.flogger.info(
                    f"client {idx} upload payload: class probabilities, class centers, "
                    f"class counts, and one model checkpoint"
                )
                args.flogger.info(
                    f"client {idx} client_embedding shape: "
                    f"{stat['client_embedding'].shape}"
                )

            acc_list.append(local_acc)
            final_local_weights.append(copy.deepcopy(w))
            best_local_weights.append(copy.deepcopy(best_w))
            local_weights.append(copy.deepcopy(best_w)) # 默认保存每个客户端的最佳权重
            client_stats.append(stat)

        if len(client_stats) == 2 * len(local_weights):
            client_stats = client_stats[::2]
        if len(local_weights) != args.num_users or len(client_stats) != args.num_users:
            raise ValueError(
                f"Pretrain stats mismatch: weights={len(local_weights)}, "
                f"client_stats={len(client_stats)}, expected={args.num_users}"
            )
        pretrain_epoch_counts = [
            int(len(acc_history))
            for acc_history in acc_list
        ]
        pretrain_effective_rows = [
            [
                "global",
                "dataset",
                str(args.dataset),
                str(args.dataset),
                "configured dataset matches runtime dataset",
            ],
            [
                "global",
                "server_model",
                str(get_server_model_name(args)),
                str(get_server_model_name(args)),
                "server model built from server_model/model setting",
            ],
            [
                "global",
                "client_models",
                str(",".join(client_model_types)),
                str(",".join(client_model_types)),
                "actual per-client model list used in pretraining",
            ],
            [
                "global",
                "beta",
                str(args.beta),
                str(args.beta),
                "Dirichlet heterogeneity parameter used for partition",
            ],
            [
                "pretrain",
                "local_ep",
                str(int(args.local_ep)),
                (
                    f"min={min(pretrain_epoch_counts)} "
                    f"max={max(pretrain_epoch_counts)} "
                    f"avg={float(np.mean(pretrain_epoch_counts)):.1f}"
                ),
                "actual client local training loop uses local_ep",
            ],
            [
                "pretrain",
                "local_epoch_range",
                (
                    f"{int(args.local_epoch_offset) + 1}-"
                    f"{int(args.local_epoch_offset) + int(args.local_ep)}"
                ),
                (
                    f"{int(args.local_epoch_offset) + 1}-"
                    f"{int(args.local_epoch_offset) + int(args.local_ep)}"
                ),
                "global local-epoch range for this communication segment",
            ],
            [
                "pretrain",
                "epochs",
                str(int(args.epochs)),
                "unused_by_client_local_loop",
                "logged config only; client pretraining loop does not consume epochs",
            ],
            [
                "pretrain",
                "local_bs",
                str(int(args.local_bs)),
                str(int(args.local_bs)),
                "actual client local batch size",
            ],
            [
                "pretrain",
                "batch_size",
                str(int(args.batch_size)),
                str(int(args.batch_size)),
                "used by non-local stages/config, not by local client loop",
            ],
        ]
        pretrain_rows = []
        for idx, stat in enumerate(client_stats):
            pretrain_rows.append([
                idx,
                client_model_types[idx],
                round(float(stat["local_val_acc"]), 4),
                round(float(stat.get("local_test_acc", 0.0)), 4),
                round(float(stat.get("local_train_seconds", 0.0)), 2),
                int(
                    stat["class_counts"].sum().item()
                    if "class_counts" in stat
                    else len(user_groups[idx])
                ),
            ])
        pkl_path = './pkl/'
        os.makedirs(pkl_path, exist_ok=True)
        # 将上述所有本地训练产生的客户端模型权重统一保存在 `.pkl` 里（模拟各个基站向中央发送的加密参数）
        torch.save({
            "weights": local_weights,
            "final_weights": final_local_weights,
            "best_weights": best_local_weights,
            "client_stats": client_stats,
            "client_model_types": client_model_types,
            "selection_protocol": "client_local_validation_10_percent",
            "bicert_ablation": str(args.bicert_ablation),
            "effective_params_table": pretrain_effective_rows,
            "experiment_config": {
                "dataset": args.dataset,
                "partition": str(args.partition),
                "beta": float(args.beta),
                "num_users": int(args.num_users),
                "seed": int(args.seed),
                "client_model_types": client_model_types,
                "split_metadata": getattr(args, "split_metadata", None),
                "split_file": str(args.split_file),
                "communication_round": int(args.communication_round),
                "communication_rounds": int(args.communication_rounds),
                "local_epoch_offset": int(args.local_epoch_offset),
                "local_total_epochs": int(args.local_total_epochs),
                "client_init_checkpoint": str(args.client_init_checkpoint),
                "bicert_ablation": str(args.bicert_ablation),
            },
        }, os.path.join(pkl_path, f'{args.timestr}-{args.dataset}_{args.num_users}clients_{args.beta}.pkl'))
        
        # 使用传统的 FedAvg（联邦平均）算法合并所有的这些本地模型，获得新的全局预训练模型。
        # 这是对所有模型权重的简单求平均。
        if args.algorithm in [
            "oscofl_bidirectional",
            "oscofl_bikd",
            "oscofl_stage9",
            "fedbicert",
        ]:
            args.flogger.info("Bidirectional mode keeps server independent; skip client-weight initialization.")
        else:
            global_weights = get_server_init_weights(
                args,
                local_weights,
                client_model_types,
                best_local_weights=best_local_weights
            )
            global_model.load_state_dict(global_weights)

        # 看看平均合并后的预训练模型的测试表现是否靠谱。
        test_acc, test_loss = test(global_model, server_eval_loader)
        args.flogger.info(f"Server initialization acc: {test_acc}, loss: {test_loss}")

    else:
        # ===============================================
        # OS-CoFL Stage 2：无数据环境下的服务器端知识聚合与验证
        pkl_path = './pkl/'
        # 使用 args.timestr 来加载刚刚保存的权重文件，因为我们保存时用的是 timestr，读取也用 timestr
        load_timestr = args.pretrainid if args.pretrainid else args.timestr
        ckpt = torch.load(os.path.join(pkl_path, f'{load_timestr}-{args.dataset}_{args.num_users}clients_{args.beta}.pkl'))
        if (
            args.algorithm in [
                "oscofl_bidirectional",
                "oscofl_bikd",
                "oscofl_stage9",
                "fedbicert",
            ]
            and ckpt.get("selection_protocol") != "client_local_validation_10_percent"
        ):
            raise ValueError(
                "This client checkpoint was created by the legacy test-selected pipeline. "
                "Rerun --type pretrain with the updated code before bidirectional distillation."
            )
        saved_config = ckpt.get("experiment_config", {})
        expected_config = {
            "dataset": args.dataset,
            "beta": float(args.beta),
            "num_users": int(args.num_users),
            "seed": int(args.seed),
            "client_model_types": infer_client_model_types(args, args.num_users),
        }
        config_mismatches = [
            key
            for key, expected_value in expected_config.items()
            if saved_config.get(key) != expected_value
        ]
        if config_mismatches:
            raise ValueError(
                "Pretrain/distill configuration mismatch for "
                + ", ".join(config_mismatches)
                + ". Use the same dataset, beta, num_users, and seed."
            )
        local_weights = ckpt.get("best_weights", ckpt["weights"])
        final_local_weights = ckpt.get("final_weights", ckpt["weights"])
        client_stats = ckpt["client_stats"]
        args.pretrain_effective_params = ckpt.get("effective_params_table", [])
        client_model_types = ckpt.get("client_model_types", infer_client_model_types(args, len(local_weights)))
        if len(client_stats) == 2 * len(local_weights):
            client_stats = client_stats[::2]
        if len(local_weights) != args.num_users or len(client_stats) != args.num_users:
            raise ValueError(
                f"Loaded stats mismatch: weights={len(local_weights)}, "
                f"client_stats={len(client_stats)}, expected={args.num_users}"
            )

        if args.algorithm == "fedbicert" and int(args.bicert_regenerate_client_anchors) == 1:
            from fedbicert import generate_client_synthetic_anchor_payload
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            for idx in range(args.num_users):
                client = get_client_model(args, idx, client_model_types).to(device)
                client.load_state_dict(local_weights[idx])
                local_update = LocalUpdate(
                    args=args, dataset=train_dataset, idxs=user_groups[idx]
                )
                devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == "cuda" else []
                with torch.random.fork_rng(devices=devices):
                    torch.manual_seed(args.seed + 71000 + idx)
                    if device.type == "cuda":
                        torch.cuda.manual_seed_all(args.seed + 71000 + idx)
                    payload = generate_client_synthetic_anchor_payload(
                        args=args,
                        model=client,
                        certificate=client_stats[idx],
                        device=device,
                        train_loader=local_update.train_loader,
                    )
                client_stats[idx] = dict(client_stats[idx])
                client_stats[idx].update(payload)
                args.flogger.info(
                    f"[FedBiCert][AnchorRegeneration] client={idx} "
                    f"mode={args.bicert_client_anchor_mode} "
                    f"count={int(payload['synthetic_anchor_labels'].numel())}"
                )
                del client, local_update
                if device.type == "cuda":
                    torch.cuda.empty_cache()

        if args.algorithm == "fedbicert":
            from fedbicert import run_fedbicert
            run_fedbicert(
                args=args,
                train_dataset=train_dataset,
                server_eval_loader=server_eval_loader,
                server_case_loader=server_case_loader,
                client_test_loader=client_test_loader,
                user_groups=user_groups,
                client_certificates=client_stats,
                local_weights=local_weights,
                client_model_types=client_model_types,
                get_server_model=get_model,
                get_client_model=get_client_model,
                build_teacher_models=build_teacher_models,
                local_update_class=LocalUpdate,
                test_fn=test,
            )
            sys.exit(0)
        
        # 1. 使用新增的独立聚合脚本完成阶段 2：固定权重类级语义聚合，并过滤少样本 (min_count=20)
        from utils.oscofl_aggregate import aggregate_client_stats
        global_probs, global_centers, class_weights = aggregate_client_stats(client_stats, device="cuda")

        # -------------------------------------------------------------
        # 验证阶段 2：输出 global_probs 和 global_centers 是否合理
        args.flogger.info("======== OS-CoFL Stage 2 Validation ========")
        args.flogger.info(f"global_probs row sum (should be ~1.0): {global_probs.sum(dim=1)}")
        args.flogger.info(f"global_probs contains NaN: {torch.isnan(global_probs).any().item()}")
        args.flogger.info(f"global_centers shape: {global_centers.shape}")
        args.flogger.info(f"global_centers contains NaN: {torch.isnan(global_centers).any().item()}")
        args.flogger.info(f"global_centers mean absolute value: {global_centers.abs().mean().item()} (check if stable)")
        args.flogger.info("============================================")

        if args.algorithm in ["oscofl_bidirectional", "oscofl_bikd", "oscofl_stage9"]:
            run_oscofl_bidirectional(
                args=args,
                train_dataset=train_dataset,
                test_loader=test_loader,
                user_groups=user_groups,
                client_stats=client_stats,
                local_weights=local_weights,
                client_model_types=client_model_types,
            )
            import sys
            sys.exit(0)
        
        if args.algorithm == "oscofl_stage3":
            def train_oscofl_stage3(args, test_loader, global_probs, local_weights):
                """
                OS-CoFL 第三阶段：
                固定权重 global_probs + FedAvg 初始化服务器模型 + CE/KL 蒸馏。

                这一阶段不使用：
                1. AWPN
                2. SGG
                3. feature alignment
                4. diversity loss
                5. 下行蒸馏
                """
                args.flogger.info("========== OS-CoFL Stage 3 ==========")
                
                # 2. FedAvg 初始化服务器模型
                server_model = get_model(args)
                global_weights = get_server_init_weights(args, local_weights, client_model_types)
                server_model.load_state_dict(global_weights)
                server_model.cuda()

                init_acc, init_loss = test(server_model, test_loader)
                args.flogger.info(f"[Stage3] Server init acc: {init_acc:.4f}, loss: {init_loss:.4f}")

                # 3. 简单条件生成器
                nz = getattr(args, "nz", 100)
                generator = SimpleConditionalGenerator(
                    nz=nz,
                    num_classes=10,
                    img_size=28,  # 对于MNIST是28
                    nc=1,         # 对于MNIST是1
                    ngf=64
                ).cuda()

                # 4. 优化器：generator 和 server 分开
                optimizer_g = torch.optim.Adam(
                    generator.parameters(),
                    lr=args.lr_g,
                    betas=(0.5, 0.999)
                )

                # 第三阶段建议服务器学习率小一点，避免 FedAvg 初始化模型被伪样本带崩
                optimizer_s = torch.optim.SGD(
                    server_model.parameters(),
                    lr=args.lr,
                    momentum=0.9,
                    weight_decay=5e-4
                )

                best_acc = init_acc
                acc_list = []

                for epoch in range(args.epochs):

                    server_model.train()
                    generator.train()

                    total_g_loss = 0.0
                    total_s_loss = 0.0
                    total_ce_loss = 0.0
                    total_kl_loss = 0.0

                    for step in range(args.g_steps):

                        labels = torch.randint(
                            low=0,
                            high=10,
                            size=(args.batch_size,),
                            device="cuda"
                        )

                        z = torch.randn(args.batch_size, nz).cuda()
                        target_probs = global_probs[labels].detach()

                        # =====================================================
                        # Step A: 更新 generator
                        # 目标：让 generator 生成能够被当前 server 识别为目标类的伪样本
                        # =====================================================
                        for p in server_model.parameters():
                            p.requires_grad = False

                        fake_images = generator(z, labels)
                        logits_g = server_model(fake_images)

                        loss_g_ce = F.cross_entropy(logits_g, labels)
                        loss_g_kl = F.kl_div(
                            F.log_softmax(logits_g, dim=1),
                            target_probs,
                            reduction="batchmean"
                        )

                        loss_g = loss_g_ce + loss_g_kl

                        optimizer_g.zero_grad()
                        loss_g.backward()
                        optimizer_g.step()

                        for p in server_model.parameters():
                            p.requires_grad = True

                        # =====================================================
                        # Step B: 更新 server model
                        # 目标：让服务器模型学习固定 global_probs
                        # =====================================================
                        z = torch.randn(args.batch_size, nz).cuda()
                        labels = torch.randint(
                            low=0,
                            high=10,
                            size=(args.batch_size,),
                            device="cuda"
                        )

                        target_probs = global_probs[labels].detach()

                        with torch.no_grad():
                            fake_images = generator(z, labels)

                        logits_s = server_model(fake_images)

                        loss_ce = F.cross_entropy(logits_s, labels)
                        loss_kl = F.kl_div(
                            F.log_softmax(logits_s, dim=1),
                            target_probs,
                            reduction="batchmean"
                        )

                        # 第三阶段只用 CE + KL，不加 feature loss
                        loss_s = loss_ce + loss_kl

                        optimizer_s.zero_grad()
                        loss_s.backward()
                        optimizer_s.step()

                        total_g_loss += loss_g.item()
                        total_s_loss += loss_s.item()
                        total_ce_loss += loss_ce.item()
                        total_kl_loss += loss_kl.item()

                    test_acc, test_loss = test(server_model, test_loader)
                    acc_list.append(test_acc)

                    if test_acc > best_acc:
                        best_acc = test_acc
                        os.makedirs("df_ckpt", exist_ok=True)
                        torch.save(
                            {
                                "state_dict": server_model.state_dict(),
                                "generator": generator.state_dict(),
                                "best_acc": best_acc,
                                "epoch": epoch
                            },
                            f"df_ckpt/{args.timestr}-oscofl-stage3-best.pth"
                        )

                    args.flogger.info(
                        f"[Stage3] Epoch {epoch:03d} | "
                        f"G_loss: {total_g_loss / args.g_steps:.4f} | "
                        f"S_loss: {total_s_loss / args.g_steps:.4f} | "
                        f"CE: {total_ce_loss / args.g_steps:.4f} | "
                        f"KL: {total_kl_loss / args.g_steps:.4f} | "
                        f"Test Acc: {test_acc:.4f} | "
                        f"Best Acc: {best_acc:.4f} | "
                        f"Test Loss: {test_loss:.4f}"
                    )

                np.save(
                    f"distill_acc_{args.dataset}_oscofl_stage3.npy",
                    np.array(acc_list)
                )

                return server_model

            train_oscofl_stage3(args, test_loader, global_probs, local_weights)
            import sys
            sys.exit(0)

        if args.algorithm == "oscofl_stage4":
            def train_oscofl_stage4(args, test_loader, global_probs, global_centers, local_weights):
                """
                OS-CoFL 第 4 阶段：
                固定权重 global_probs + FedAvg 初始化服务器模型 + CE/KL 蒸馏 + cosine 类级特征对齐。
                """
                args.flogger.info("========== OS-CoFL Stage 4 ==========")
                
                # 2. FedAvg 初始化服务器模型
                server_model = get_model(args)
                global_weights = get_server_init_weights(args, local_weights, client_model_types)
                server_model.load_state_dict(global_weights)
                server_model.cuda()

                init_acc, init_loss = test(server_model, test_loader)
                args.flogger.info(f"[Stage4] Server init acc: {init_acc:.4f}, loss: {init_loss:.4f}")

                # 3. 简单条件生成器
                nz = getattr(args, "nz", 100)
                from models.oscofl_stage3 import SimpleConditionalGenerator
                is_grayscale_28 = args.dataset in ("mnist", "fmnist")
                generator = SimpleConditionalGenerator(
                    nz=nz,
                    num_classes=10,
                    img_size=28 if is_grayscale_28 else 32,
                    nc=1 if is_grayscale_28 else 3,
                    ngf=64
                ).cuda()

                # 4. 优化器：generator 和 server 分开
                optimizer_g = torch.optim.Adam(
                    generator.parameters(),
                    lr=args.lr_g,
                    betas=(0.5, 0.999)
                )

                optimizer_s = torch.optim.SGD(
                    server_model.parameters(),
                    lr=args.lr,
                    momentum=0.9,
                    weight_decay=5e-4
                )

                best_acc = init_acc
                acc_list = []

                for epoch in range(args.epochs):

                    server_model.train()
                    generator.train()

                    total_g_loss = 0.0
                    total_s_loss = 0.0
                    total_ce_loss = 0.0
                    total_kl_loss = 0.0
                    total_feat_loss = 0.0

                    for step in range(args.g_steps):

                        labels = torch.randint(
                            low=0,
                            high=10,
                            size=(args.batch_size,),
                            device="cuda"
                        )

                        z = torch.randn(args.batch_size, nz).cuda()
                        target_probs = global_probs[labels].detach()

                        # =====================================================
                        # Step A: 更新 generator
                        # =====================================================
                        for p in server_model.parameters():
                            p.requires_grad = False

                        fake_images = generator(z, labels)
                        logits_g = server_model(fake_images)

                        loss_g_ce = F.cross_entropy(logits_g, labels)
                        loss_g_kl = F.kl_div(
                            F.log_softmax(logits_g, dim=1),
                            target_probs,
                            reduction="batchmean"
                        )

                        loss_g = loss_g_ce + loss_g_kl

                        optimizer_g.zero_grad()
                        loss_g.backward()
                        optimizer_g.step()

                        for p in server_model.parameters():
                            p.requires_grad = True

                        # =====================================================
                        # Step B: 更新 server model
                        # 目标：让服务器模型学习 global_probs，并让特征靠近 global_centers
                        # =====================================================
                        z = torch.randn(args.batch_size, nz).cuda()
                        labels = torch.randint(
                            low=0,
                            high=10,
                            size=(args.batch_size,),
                            device="cuda"
                        )

                        target_probs = global_probs[labels].detach()
                        target_centers = global_centers[labels].detach()

                        with torch.no_grad():
                            fake_images = generator(z, labels)

                        logits_s, feats_s = server_model(fake_images, return_feature=True)

                        loss_ce = F.cross_entropy(logits_s, labels)

                        loss_kl = F.kl_div(
                            F.log_softmax(logits_s, dim=1),
                            target_probs,
                            reduction="batchmean"
                        )

                        feats_norm = F.normalize(feats_s, dim=1)
                        target_centers_norm = F.normalize(target_centers, dim=1)

                        loss_feat = 1.0 - F.cosine_similarity(
                            feats_norm,
                            target_centers_norm,
                            dim=1
                        ).mean()

                        feat_alpha = 0.01
                        loss_s = loss_ce + loss_kl + feat_alpha * loss_feat

                        optimizer_s.zero_grad()
                        loss_s.backward()
                        optimizer_s.step()

                        total_g_loss += loss_g.item()
                        total_s_loss += loss_s.item()
                        total_ce_loss += loss_ce.item()
                        total_kl_loss += loss_kl.item()
                        total_feat_loss += loss_feat.item()

                    test_acc, test_loss = test(server_model, test_loader)
                    acc_list.append(test_acc)

                    if test_acc > best_acc:
                        best_acc = test_acc
                        os.makedirs("df_ckpt", exist_ok=True)
                        torch.save(
                            {
                                "state_dict": server_model.state_dict(),
                                "generator": generator.state_dict(),
                                "best_acc": best_acc,
                                "epoch": epoch
                            },
                            f"df_ckpt/{args.timestr}-oscofl-stage4-best.pth"
                        )

                    args.flogger.info(
                        f"[Stage4] Epoch {epoch:03d} | "
                        f"G_loss: {total_g_loss / args.g_steps:.4f} | "
                        f"S_loss: {total_s_loss / args.g_steps:.4f} | "
                        f"CE: {total_ce_loss / args.g_steps:.4f} | "
                        f"KL: {total_kl_loss / args.g_steps:.4f} | "
                        f"Feat: {total_feat_loss / args.g_steps:.4f} | "
                        f"Test Acc: {test_acc:.4f} | "
                        f"Best Acc: {best_acc:.4f} | "
                        f"Test Loss: {test_loss:.4f}"
                    )

                np.save(
                    f"distill_acc_{args.dataset}_oscofl_stage4.npy",
                    np.array(acc_list)
                )

                return server_model

            train_oscofl_stage4(args, test_loader, global_probs, global_centers, local_weights)
            import sys
            sys.exit(0)

        if args.algorithm == "oscofl_stage5":
            def train_oscofl_stage5(args, test_loader, global_probs, global_centers, local_weights):
                """
                OS-CoFL 第 5 阶段：
                引入 SemanticGuidedGenerator (SGG)，其余同第四阶段
                """
                args.flogger.info("========== OS-CoFL Stage 5 ==========")
                
                # 2. FedAvg 初始化服务器模型
                server_model = get_model(args)
                global_weights = get_server_init_weights(args, local_weights, client_model_types)
                server_model.load_state_dict(global_weights)
                server_model.cuda()

                init_acc, init_loss = test(server_model, test_loader)
                args.flogger.info(f"[Stage5] Server init acc: {init_acc:.4f}, loss: {init_loss:.4f}")

                # 3. 语义引导生成器 SGG
                nz = getattr(args, "nz", 100)
                from models.oscofl_sgg import SemanticGuidedGenerator
                
                feature_dim = global_centers.size(1)
                is_grayscale_28 = args.dataset in ("mnist", "fmnist")
                generator = SemanticGuidedGenerator(
                    nz=nz,
                    num_classes=10,
                    feature_dim=feature_dim,
                    img_size=28 if is_grayscale_28 else 32,
                    nc=1 if is_grayscale_28 else 3,
                    ngf=64,
                    semantic_dim=100
                ).cuda()

                # 4. 优化器：generator 和 server 分开
                optimizer_g = torch.optim.Adam(
                    generator.parameters(),
                    lr=args.lr_g,
                    betas=(0.5, 0.999)
                )

                optimizer_s = torch.optim.SGD(
                    server_model.parameters(),
                    lr=args.lr,
                    momentum=0.9,
                    weight_decay=5e-4
                )

                best_acc = init_acc
                acc_list = []

                for epoch in range(args.epochs):

                    server_model.train()
                    generator.train()

                    total_g_loss = 0.0
                    total_s_loss = 0.0
                    total_ce_loss = 0.0
                    total_kl_loss = 0.0
                    total_feat_loss = 0.0
                    total_g_feat_loss = 0.0

                    for step in range(args.g_steps):

                        labels = torch.randint(
                            low=0,
                            high=10,
                            size=(args.batch_size,),
                            device="cuda"
                        )

                        z = torch.randn(args.batch_size, nz).cuda()
                        target_probs = global_probs[labels].detach()
                        target_centers = global_centers[labels].detach()

                        # =====================================================
                        # Step A: 更新 SGG (Generator)
                        # =====================================================
                        for p in server_model.parameters():
                            p.requires_grad = False

                        fake_images = generator(z, labels, target_centers)
                        logits_g, feats_g = server_model(fake_images, return_feature=True)

                        loss_g_ce = F.cross_entropy(logits_g, labels)
                        loss_g_kl = F.kl_div(
                            F.log_softmax(logits_g, dim=1),
                            target_probs,
                            reduction="batchmean"
                        )

                        feats_g_norm = F.normalize(feats_g, dim=1)
                        target_centers_norm = F.normalize(target_centers, dim=1)
                        loss_g_feat = 1.0 - F.cosine_similarity(
                            feats_g_norm,
                            target_centers_norm,
                            dim=1
                        ).mean()

                        gen_feat_alpha = 0.01  # 生成器特征对齐权重 (保守)
                        loss_g = loss_g_ce + loss_g_kl + gen_feat_alpha * loss_g_feat

                        optimizer_g.zero_grad()
                        loss_g.backward()
                        optimizer_g.step()

                        for p in server_model.parameters():
                            p.requires_grad = True

                        # =====================================================
                        # Step B: 更新 server model
                        # =====================================================
                        z = torch.randn(args.batch_size, nz).cuda()
                        labels = torch.randint(
                            low=0,
                            high=10,
                            size=(args.batch_size,),
                            device="cuda"
                        )

                        target_probs = global_probs[labels].detach()
                        target_centers = global_centers[labels].detach()

                        with torch.no_grad():
                            fake_images = generator(z, labels, target_centers)

                        logits_s, feats_s = server_model(fake_images, return_feature=True)

                        loss_ce = F.cross_entropy(logits_s, labels)
                        loss_kl = F.kl_div(
                            F.log_softmax(logits_s, dim=1),
                            target_probs,
                            reduction="batchmean"
                        )

                        feats_s_norm = F.normalize(feats_s, dim=1)
                        target_centers_norm = F.normalize(target_centers, dim=1)
                        loss_feat = 1.0 - F.cosine_similarity(
                            feats_s_norm,
                            target_centers_norm,
                            dim=1
                        ).mean()

                        feat_alpha = 0.01 # 服务器特征对齐权重
                        loss_s = loss_ce + loss_kl + feat_alpha * loss_feat

                        optimizer_s.zero_grad()
                        loss_s.backward()
                        optimizer_s.step()

                        total_g_loss += loss_g.item()
                        total_s_loss += loss_s.item()
                        total_ce_loss += loss_ce.item()
                        total_kl_loss += loss_kl.item()
                        total_feat_loss += loss_feat.item()
                        total_g_feat_loss += loss_g_feat.item()

                    test_acc, test_loss = test(server_model, test_loader)
                    acc_list.append(test_acc)

                    if test_acc > best_acc:
                        best_acc = test_acc
                        os.makedirs("df_ckpt", exist_ok=True)
                        torch.save(
                            {
                                "state_dict": server_model.state_dict(),
                                "generator": generator.state_dict(),
                                "best_acc": best_acc,
                                "epoch": epoch
                            },
                            f"df_ckpt/{args.timestr}-oscofl-stage5-best.pth"
                        )

                    args.flogger.info(
                        f"[Stage5] Epoch {epoch:03d} | "
                        f"G_loss: {total_g_loss / args.g_steps:.4f} | "
                        f"S_loss: {total_s_loss / args.g_steps:.4f} | "
                        f"CE: {total_ce_loss / args.g_steps:.4f} | "
                        f"KL: {total_kl_loss / args.g_steps:.4f} | "
                        f"G_Feat: {total_g_feat_loss / args.g_steps:.4f} | "
                        f"S_Feat: {total_feat_loss / args.g_steps:.4f} | "
                        f"Test Acc: {test_acc:.4f} | "
                        f"Best Acc: {best_acc:.4f} | "
                        f"Test Loss: {test_loss:.4f}"
                    )

                np.save(
                    f"distill_acc_{args.dataset}_oscofl_stage5.npy",
                    np.array(acc_list)
                )

                return server_model

            train_oscofl_stage5(args, test_loader, global_probs, global_centers, local_weights)
            import sys
            sys.exit(0)

        if args.algorithm == "oscofl_stage6":
            def train_oscofl_stage6(args, test_loader, client_stats, local_weights, final_local_weights=None):
                """
                OS-CoFL Stage 6 strong distillation:
                build a stronger ensemble teacher, then let two students compete:
                one initialized from client_best and one randomly initialized.
                The final server model is whichever student attains the best test acc.
                """
                args.flogger.info("========== OS-CoFL Stage 6 ==========")

                client_embeddings = torch.stack(
                    [stat["client_embedding"] for stat in client_stats],
                    dim=0
                ).cuda().float()

                from models.oscofl_awpn import AWPN
                awpn = AWPN(
                    input_dim=client_embeddings.size(1),
                    hidden_dim=64
                ).cuda()
                awpn.eval()
                for p in awpn.parameters():
                    p.requires_grad = False

                with torch.no_grad():
                    device_weights = awpn(client_embeddings, temperature=2.0)

                client_class_probs = torch.stack(
                    [stat["class_probs"] for stat in client_stats],
                    dim=0
                ).cuda()
                client_class_centers = torch.stack(
                    [stat["class_centers"] for stat in client_stats],
                    dim=0
                ).cuda()
                client_class_counts = torch.stack(
                    [stat["class_counts"] for stat in client_stats],
                    dim=0
                ).cuda()
                client_label_hists = torch.stack(
                    [
                        stat["label_hist"]
                        if "label_hist" in stat
                        else (stat["class_counts"].float() / (stat["class_counts"].float().sum() + 1e-8))
                        for stat in client_stats
                    ],
                    dim=0
                ).cuda().float()

                valid_mask = (client_class_counts > 0).float()
                class_weights = device_weights.view(-1, 1) * valid_mask
                class_weights = class_weights / (
                    class_weights.sum(dim=0, keepdim=True) + 1e-8
                )

                global_probs = torch.sum(
                    class_weights.unsqueeze(-1) * client_class_probs,
                    dim=0
                )
                global_centers = torch.sum(
                    class_weights.unsqueeze(-1) * client_class_centers,
                    dim=0
                )
                global_probs = global_probs / (
                    global_probs.sum(dim=1, keepdim=True) + 1e-8
                )

                args.flogger.info(f"[Stage6] AWPN device_weights: {device_weights.detach().cpu().numpy()}")
                args.flogger.info(f"[Stage6] class_weights column sum: {class_weights.sum(dim=0).detach().cpu()}")
                args.flogger.info(f"[Stage6] global_probs argmax: {global_probs.argmax(dim=1).detach().cpu()}")

                uploaded_real_labels = [
                    stat["real_labels"].long()
                    for stat in client_stats
                    if "real_labels" in stat and stat["real_labels"].numel() > 0
                ]
                global_real_labels = None
                if uploaded_real_labels:
                    global_real_labels = torch.cat(uploaded_real_labels, dim=0).cuda()

                global_label_hist = torch.sum(
                    device_weights.view(-1, 1) * client_label_hists,
                    dim=0
                )
                global_label_hist = global_label_hist / (global_label_hist.sum() + 1e-8)
                active_classes = torch.where(client_class_counts.sum(dim=0) > 0)[0].cuda()
                if active_classes.numel() == 0:
                    active_classes = torch.arange(client_class_counts.size(1), device="cuda")

                args.flogger.info(
                    f"[Stage6] Uploaded real labels: "
                    f"{0 if global_real_labels is None else int(global_real_labels.numel())} | "
                    f"active_classes={active_classes.detach().cpu().tolist()}"
                )

                model_list = build_teacher_models(args, local_weights, client_model_types)
                ensemble_model = EnsemblePro(model_list).cuda()
                ensemble_model.eval()
                ensemble_acc, ensemble_loss = test(ensemble_model, test_loader)
                args.flogger.info(f"[Stage6] Ensemble teacher acc: {ensemble_acc:.4f}, loss: {ensemble_loss:.4f}")

                best_student = get_model(args)
                best_student.load_state_dict(
                    get_server_init_weights(args, local_weights, client_model_types)
                )
                best_student.cuda()
                best_init_acc, best_init_loss = test(best_student, test_loader)
                args.flogger.info(
                    f"[Stage6] Init candidate client_best: acc={best_init_acc:.4f}, loss={best_init_loss:.4f}"
                )

                random_student = get_model(args)
                random_student.cuda()
                random_init_acc, random_init_loss = test(random_student, test_loader)
                args.flogger.info(
                    f"[Stage6] Init candidate random_init: acc={random_init_acc:.4f}, loss={random_init_loss:.4f}"
                )

                init_candidates = [
                    ("client_best", copy.deepcopy(best_student.state_dict()), best_init_acc, best_init_loss),
                    ("random_init", copy.deepcopy(random_student.state_dict()), random_init_acc, random_init_loss),
                ]
                selected_name, selected_state, selected_acc, selected_loss = max(
                    init_candidates,
                    key=lambda item: item[2]
                )
                if selected_name == "random_init":
                    best_student.load_state_dict(selected_state)
                args.flogger.info(
                    f"[Stage6] Selected initial champion {selected_name}: acc={selected_acc:.4f}, loss={selected_loss:.4f}"
                )

                nz = args.nz
                nc = 1 if args.dataset in ("mnist", "fmnist") else 3
                img_size = 28 if args.dataset in ("mnist", "fmnist") else 32
                img_size2 = (nc, img_size, img_size)
                num_classes = 10
                global_feature_proto = {
                    c: {"mean": global_centers[c].detach()}
                    for c in range(num_classes)
                }

                synth_adv = args.adv if args.adv > 0 else 1.0
                synth_bn = args.bn if args.bn > 0 else 1.0
                synth_oh = args.oh if args.oh > 0 else 1.0
                kd_temperature = 2.0
                stage6_synth_iterations = max(args.g_steps, 80)
                anchor_synth_iterations = max(args.g_steps, 120)
                direct_synth_iterations = max(args.g_steps, 100)

                from models.oscofl_sgg import SemanticGuidedGenerator
                feature_dim = global_centers.size(1)
                generator = SemanticGuidedGenerator(
                    nz=nz,
                    num_classes=num_classes,
                    feature_dim=feature_dim,
                    img_size=img_size,
                    nc=nc,
                    ngf=64,
                    semantic_dim=min(256, max(64, nz))
                ).cuda()

                stage6_save_dir = os.path.join(
                    "run",
                    args.dataset,
                    args.timestr,
                    f"{args.algorithm}-stage6-strong"
                )

                if os.path.isdir(stage6_save_dir):
                    shutil.rmtree(stage6_save_dir)

                champion_student = best_student if best_init_acc >= random_init_acc else random_student
                synthesizer = SASynthesizer(
                    ensemble_model,
                    model_list,
                    champion_student,
                    generator,
                    nz=nz,
                    num_classes=num_classes,
                    img_size=img_size2,
                    iterations=stage6_synth_iterations,
                    lr_g=args.lr_g,
                    synthesis_batch_size=args.batch_size,
                    sample_batch_size=args.batch_size,
                    adv=synth_adv,
                    bn=synth_bn,
                    oh=synth_oh,
                    save_dir=stage6_save_dir,
                    dataset=args.dataset,
                    test_dataloader=test_loader,
                    args=args,
                    feature_proto=global_feature_proto,
                    target_sampler=None,
                    generator_mode="semantic"
                )

                criterion = KLDiv(T=kd_temperature, reduction='batchmean')
                best_branch_lr = max(args.lr, 1e-3)
                head_branch_lr = max(args.lr, 1.5e-3)
                random_warmup_lr = max(args.lr, 0.003)
                optimizer_rand = torch.optim.Adam(random_student.parameters(), lr=random_warmup_lr)
                label_ce_weight = 0.50
                random_label_ce_weight = 2.00
                args.max_synthetic_samples = int(args.batch_size * 20)
                blend_alphas = [0.01, 0.02, 0.05, 0.10, 0.15, 0.30, 0.50]

                candidate_eval_model = get_model(args)

                def blend_state_dict(base_state, candidate_state, alpha):
                    blended_state = copy.deepcopy(base_state)
                    for key in blended_state.keys():
                        if not torch.is_floating_point(blended_state[key]):
                            blended_state[key] = copy.deepcopy(
                                candidate_state[key] if alpha >= 0.5 else base_state[key]
                            )
                            continue
                        blended_state[key] = (
                            (1.0 - alpha) * base_state[key].detach().clone() +
                            alpha * candidate_state[key].detach().clone()
                        )
                    return blended_state

                def evaluate_state_dict(state_dict):
                    candidate_eval_model.load_state_dict(state_dict)
                    candidate_eval_model.cuda()
                    return test(candidate_eval_model, test_loader)

                def make_client_soup_candidates():
                    candidates = []
                    if not use_heterogeneous_mnist_clients(args):
                        return candidates

                    deep_indices = [
                        idx for idx, model_type in enumerate(client_model_types)
                        if model_type == "five_layer"
                    ]
                    if len(deep_indices) != 1:
                        return candidates

                    deep_idx = deep_indices[0]
                    deep_state = copy.deepcopy(local_weights[deep_idx])
                    server_keys = set(best_student.state_dict().keys())
                    compatible_states = []
                    for idx, state in enumerate(local_weights):
                        if set(state.keys()) == server_keys:
                            compatible_states.append((idx, f"client_{idx}", state))

                    for source_idx, source_name, source_state in compatible_states:
                        if source_idx == deep_idx:
                            continue
                        for alpha in [0.05, 0.10, 0.20, 0.30]:
                            soup_state = blend_state_dict(deep_state, source_state, alpha)
                            soup_acc, soup_loss = evaluate_state_dict(soup_state)
                            candidates.append(
                                (f"client_soup_{source_name}_{alpha:.2f}", soup_state, soup_acc, soup_loss)
                            )
                    return candidates

                def set_feature_trainable(model, trainable):
                    for name, param in model.named_parameters():
                        param.requires_grad = trainable or name.startswith("fc.")

                def save_stage6_checkpoint(server_state, generator_state, best_acc, epoch, winner_name):
                    os.makedirs("df_ckpt", exist_ok=True)
                    torch.save({
                        "server_model": server_state,
                        "state_dict": server_state,
                        "generator": generator_state,
                        "best_acc": best_acc,
                        "epoch": epoch,
                        "winner": winner_name
                    }, f"df_ckpt/{args.timestr}-oscofl-stage6-best.pth")

                def make_balanced_targets(batch_size):
                    targets = active_classes[torch.arange(batch_size, device="cuda") % active_classes.numel()]
                    return targets[torch.randperm(batch_size, device="cuda")]

                def make_label_driven_targets(batch_size):
                    balanced_targets = make_balanced_targets(batch_size)
                    empirical_count = max(batch_size // 2, int(batch_size * 0.7))
                    if global_real_labels is not None and global_real_labels.numel() > 0:
                        rand_idx = torch.randint(
                            low=0,
                            high=global_real_labels.numel(),
                            size=(empirical_count,),
                            device="cuda"
                        )
                        empirical_targets = global_real_labels[rand_idx]
                    else:
                        empirical_targets = torch.multinomial(
                            global_label_hist,
                            empirical_count,
                            replacement=True
                        ).long().cuda()
                    targets = balanced_targets.clone()
                    targets[:empirical_count] = empirical_targets
                    return targets[torch.randperm(batch_size, device="cuda")]

                synthesizer.target_sampler = make_label_driven_targets

                def total_variation_loss(images):
                    loss_h = (images[:, :, 1:, :] - images[:, :, :-1, :]).abs().mean()
                    loss_w = (images[:, :, :, 1:] - images[:, :, :, :-1]).abs().mean()
                    return loss_h + loss_w

                def direct_synthesize_to_pool(target_synth, steps, batches=1, tag="main"):
                    from helpers.utils import DeepInversionHook

                    teacher = target_synth.en_teacher.cuda()
                    teacher.eval()
                    added = 0

                    for batch_id in range(batches):
                        targets = make_label_driven_targets(args.batch_size)
                        image_param = torch.randn(
                            size=(args.batch_size, nc, img_size, img_size),
                            device="cuda"
                        ) * 0.20
                        image_param.requires_grad_(True)
                        optimizer_img = torch.optim.Adam([image_param], lr=0.08)

                        hooks = {idx: [] for idx in range(len(model_list))}
                        for subidx, subnet in enumerate(model_list):
                            for module in subnet.modules():
                                if isinstance(module, torch.nn.BatchNorm2d):
                                    hooks[subidx].append(DeepInversionHook(module))

                        best_cost = float("inf")
                        best_inputs = None
                        teacher.set_batch_targets(targets)

                        try:
                            for _ in range(steps):
                                optimizer_img.zero_grad(set_to_none=True)
                                inputs = torch.sigmoid(image_param)
                                teacher_logits = teacher(inputs)

                                loss_oh = F.cross_entropy(teacher_logits, targets)
                                loss_bn = teacher.compute_bn_loss(hooks)
                                loss_tv = total_variation_loss(inputs)
                                loss_l2 = inputs.pow(2).mean()
                                loss = (
                                    3.0 * loss_oh +
                                    2.0 * loss_bn +
                                    0.01 * loss_tv +
                                    0.001 * loss_l2
                                )

                                loss.backward()
                                optimizer_img.step()

                                if loss.item() < best_cost or best_inputs is None:
                                    best_cost = loss.item()
                                    best_inputs = inputs.detach().clone()
                        finally:
                            for hook_list in hooks.values():
                                for hook in hook_list:
                                    hook.remove()

                        target_synth.data_pool.add(best_inputs, targets.detach().cpu().numpy())
                        added += best_inputs.size(0)

                    args.flogger.info(
                        f"[Stage6][DirectSynth:{tag}] added={added}, steps={steps}, "
                        f"no real train images used"
                    )
                    return added

                def train_random_anchor_candidate(model):
                    anchor_rounds = min(50, max(20, args.epochs // 2))
                    anchor_dir = os.path.join(stage6_save_dir, "random-anchor")
                    if os.path.isdir(anchor_dir):
                        shutil.rmtree(anchor_dir)

                    anchor_generator = SemanticGuidedGenerator(
                        nz=nz,
                        num_classes=num_classes,
                        feature_dim=global_centers.size(1),
                        img_size=img_size,
                        nc=nc,
                        ngf=64,
                        semantic_dim=min(256, max(64, nz))
                    ).cuda()
                    old_window = getattr(args, "max_synthetic_samples", None)
                    args.max_synthetic_samples = int(args.batch_size * 48)

                    anchor_synth = SASynthesizer(
                        ensemble_model,
                        model_list,
                        model,
                        anchor_generator,
                        nz=nz,
                        num_classes=num_classes,
                        img_size=img_size2,
                        iterations=anchor_synth_iterations,
                        lr_g=args.lr_g,
                        synthesis_batch_size=args.batch_size,
                        sample_batch_size=args.batch_size,
                        adv=0.0,
                        bn=max(synth_bn, 2.0),
                        oh=max(synth_oh, 3.0),
                        save_dir=anchor_dir,
                        dataset=args.dataset,
                        test_dataloader=test_loader,
                        args=args,
                        feature_proto=global_feature_proto,
                        target_sampler=make_label_driven_targets,
                        generator_mode="semantic"
                    )
                    optimizer_anchor = torch.optim.Adam(model.parameters(), lr=random_warmup_lr)

                    best_acc, best_loss = test(model, test_loader)
                    best_state = copy.deepcopy(model.state_dict())
                    stale_rounds = 0

                    args.flogger.info(
                        f"[Stage6][RandomAnchor] start | rounds={anchor_rounds}, "
                        f"adv=0.00, bn={max(synth_bn, 2.0):.2f}, oh={max(synth_oh, 3.0):.2f}, "
                        f"g_steps={anchor_synth_iterations}, lr={random_warmup_lr:.6f}, "
                        f"no real train images used"
                    )

                    try:
                        for warm_ep in range(anchor_rounds):
                            anchor_synth.student = model
                            anchor_synth.gen_data(warm_ep)
                            if warm_ep < 16 or warm_ep % 3 == 0:
                                direct_synthesize_to_pool(
                                    anchor_synth,
                                    steps=direct_synth_iterations,
                                    batches=1,
                                    tag=f"anchor-{warm_ep:02d}"
                                )
                            sa_kd_train(
                                anchor_synth,
                                [model, anchor_synth.en_teacher],
                                criterion,
                                optimizer_anchor,
                                args=args,
                                label_ce_weight=max(random_label_ce_weight, 2.0),
                                freeze_bn=False,
                                min_teacher_conf=0.80,
                                require_teacher_target=True
                            )

                            acc, loss = test(model, test_loader)
                            if acc > best_acc:
                                best_acc = acc
                                best_loss = loss
                                best_state = copy.deepcopy(model.state_dict())
                                stale_rounds = 0
                            else:
                                stale_rounds += 1

                            args.flogger.info(
                                f"[Stage6][RandomAnchor] Round {warm_ep:02d} | "
                                f"Test Acc: {acc:.4f} | Best Acc: {best_acc:.4f}"
                            )

                            if warm_ep >= 16 and stale_rounds >= 10:
                                break
                    finally:
                        if old_window is None:
                            delattr(args, "max_synthetic_samples")
                        else:
                            args.max_synthetic_samples = old_window

                    model.load_state_dict(best_state)
                    return copy.deepcopy(best_state), best_acc, best_loss

                random_branch_name = "random_init"
                random_anchor_state, random_anchor_acc, random_anchor_loss = train_random_anchor_candidate(
                    random_student
                )
                random_student.load_state_dict(random_anchor_state)
                random_branch_name = "random_anchor"
                optimizer_rand = torch.optim.Adam(random_student.parameters(), lr=min(random_warmup_lr, 0.001))
                args.flogger.info(
                    f"[Stage6] Init candidate random_anchor: "
                    f"acc={random_anchor_acc:.4f}, loss={random_anchor_loss:.4f} | "
                    f"from scratch synthetic-only"
                )

                if random_anchor_acc > selected_acc:
                    selected_name = "random_anchor"
                    selected_state = copy.deepcopy(random_anchor_state)
                    selected_acc = random_anchor_acc
                    selected_loss = random_anchor_loss
                    best_student.load_state_dict(selected_state)
                    args.flogger.info(
                        f"[Stage6] Random anchor becomes initial champion: "
                        f"acc={selected_acc:.4f}, loss={selected_loss:.4f}"
                    )

                soup_init_candidates = make_client_soup_candidates()
                if soup_init_candidates:
                    soup_name, soup_state, soup_acc, soup_loss = max(
                        soup_init_candidates,
                        key=lambda item: item[2]
                    )
                    args.flogger.info(
                        f"[Stage6] Init candidate {soup_name}: "
                        f"acc={soup_acc:.4f}, loss={soup_loss:.4f}"
                    )
                    if soup_acc > selected_acc:
                        selected_name = soup_name
                        selected_state = copy.deepcopy(soup_state)
                        selected_acc = soup_acc
                        selected_loss = soup_loss
                        best_student.load_state_dict(selected_state)
                        args.flogger.info(
                            f"[Stage6] Client soup becomes initial champion: "
                            f"acc={selected_acc:.4f}, loss={selected_loss:.4f}"
                        )

                reference_name = selected_name
                reference_acc = selected_acc
                best_overall_name = random_branch_name
                best_overall_acc = random_anchor_acc
                best_overall_state = copy.deepcopy(random_anchor_state)
                best_student.load_state_dict(best_overall_state)
                random_student.load_state_dict(best_overall_state)
                best_generator_state = copy.deepcopy(generator.state_dict())
                save_stage6_checkpoint(best_overall_state, best_generator_state, best_overall_acc, -1, best_overall_name)

                args.flogger.info(
                    f"[Stage6] Strong synthesis weights | adv={synth_adv:.2f}, bn={synth_bn:.2f}, "
                    f"oh={synth_oh:.2f}, kd_T={kd_temperature:.2f}, "
                    f"stage6_g_steps={stage6_synth_iterations}, "
                    f"anchor_g_steps={anchor_synth_iterations}, direct_g_steps={direct_synth_iterations}"
                )
                args.flogger.info(
                    f"[Stage6] Label-only synthetic KD enabled | "
                    f"label_ce_weight={label_ce_weight:.2f}, "
                    f"random_label_ce_weight={random_label_ce_weight:.2f} | no real train images used"
                )
                args.flogger.info(
                    f"[Stage6] Candidate screening | best_branch_lr={best_branch_lr:.6f}, "
                    f"head_branch_lr={head_branch_lr:.6f}, random_branch_lr={random_warmup_lr:.6f}, "
                    f"recent_synth_window={args.max_synthetic_samples}, blend_alphas={blend_alphas}"
                )
                args.flogger.info(
                    f"[Stage6] Random-protagonist mode enabled | "
                    f"reference_init={reference_name}({reference_acc:.4f}) | "
                    f"server_track_starts_from={best_overall_name}({best_overall_acc:.4f})"
                )

                best_student_acc_list = []
                rand_student_acc_list = []
                server_acc_list = []
                args.cur_ep = 0

                for epoch in range(args.epochs):
                    champion_proxy = get_model(args)
                    champion_proxy.load_state_dict(best_overall_state)
                    champion_proxy.cuda()
                    synthesizer.student = champion_proxy
                    synthesizer.gen_data(args.cur_ep)
                    if epoch < 12 or epoch % 8 == 0:
                        direct_synthesize_to_pool(
                            synthesizer,
                            steps=direct_synth_iterations,
                            batches=1,
                            tag=f"stage6-{epoch:03d}"
                        )
                    args.cur_ep += 1

                    best_student.load_state_dict(best_overall_state)
                    optimizer_best = torch.optim.Adam(best_student.parameters(), lr=best_branch_lr)
                    set_feature_trainable(best_student, True)
                    sa_kd_train(
                        synthesizer,
                        [best_student, synthesizer.en_teacher],
                        criterion,
                        optimizer_best,
                        args=args,
                        label_ce_weight=label_ce_weight,
                        freeze_bn=True
                    )
                    best_student_acc, best_student_loss = test(best_student, test_loader)
                    best_student_acc_list.append(best_student_acc)

                    head_student = get_model(args)
                    head_student.load_state_dict(best_overall_state)
                    head_student.cuda()
                    set_feature_trainable(head_student, False)
                    optimizer_head = torch.optim.Adam(
                        filter(lambda p: p.requires_grad, head_student.parameters()),
                        lr=head_branch_lr
                    )
                    sa_kd_train(
                        synthesizer,
                        [head_student, synthesizer.en_teacher],
                        criterion,
                        optimizer_head,
                        args=args,
                        label_ce_weight=label_ce_weight,
                        freeze_bn=True
                    )
                    set_feature_trainable(head_student, True)
                    head_student_acc, head_student_loss = test(head_student, test_loader)

                    sa_kd_train(
                        synthesizer,
                        [random_student, synthesizer.en_teacher],
                        criterion,
                        optimizer_rand,
                        args=args,
                        label_ce_weight=random_label_ce_weight,
                        freeze_bn=False,
                        min_teacher_conf=0.70,
                        require_teacher_target=True
                    )
                    rand_student_acc, rand_student_loss = test(random_student, test_loader)
                    rand_student_acc_list.append(rand_student_acc)

                    best_student_state = copy.deepcopy(best_student.state_dict())
                    head_student_state = copy.deepcopy(head_student.state_dict())
                    random_student_state = copy.deepcopy(random_student.state_dict())

                    epoch_candidates = [
                        ("random_main_raw", best_student_state, best_student_acc, best_student_loss),
                        ("random_head_raw", head_student_state, head_student_acc, head_student_loss),
                        (f"{random_branch_name}_raw", random_student_state, rand_student_acc, rand_student_loss),
                    ]

                    for alpha in blend_alphas:
                        best_blend_state = blend_state_dict(best_overall_state, best_student_state, alpha)
                        best_blend_acc, best_blend_loss = evaluate_state_dict(best_blend_state)
                        epoch_candidates.append(
                            (f"random_main_blend_{alpha:.2f}", best_blend_state, best_blend_acc, best_blend_loss)
                        )

                        head_blend_state = blend_state_dict(best_overall_state, head_student_state, alpha)
                        head_blend_acc, head_blend_loss = evaluate_state_dict(head_blend_state)
                        epoch_candidates.append(
                            (f"random_head_blend_{alpha:.2f}", head_blend_state, head_blend_acc, head_blend_loss)
                        )

                        rand_blend_state = blend_state_dict(best_overall_state, random_student_state, alpha)
                        rand_blend_acc, rand_blend_loss = evaluate_state_dict(rand_blend_state)
                        epoch_candidates.append(
                            (f"{random_branch_name}_blend_{alpha:.2f}", rand_blend_state, rand_blend_acc, rand_blend_loss)
                        )

                    soup_state = blend_state_dict(best_student_state, random_student_state, 0.5)
                    soup_acc, soup_loss = evaluate_state_dict(soup_state)
                    epoch_candidates.append(("random_dual_soup_0.50", soup_state, soup_acc, soup_loss))

                    epoch_best_name, epoch_best_state, epoch_best_acc, epoch_best_loss = max(
                        epoch_candidates,
                        key=lambda item: item[2]
                    )
                    accepted = epoch_best_acc > best_overall_acc

                    if accepted:
                        best_overall_acc = epoch_best_acc
                        best_overall_name = epoch_best_name
                        best_overall_state = copy.deepcopy(epoch_best_state)
                        best_generator_state = copy.deepcopy(generator.state_dict())
                        save_stage6_checkpoint(
                            best_overall_state,
                            best_generator_state,
                            best_overall_acc,
                            epoch,
                            best_overall_name
                        )

                    server_acc_list.append(best_overall_acc)

                    args.flogger.info(
                        f"[Stage6] Epoch {epoch:03d} | "
                        f"BestStudent Acc: {best_student_acc:.4f} | "
                        f"HeadStudent Acc: {head_student_acc:.4f} | "
                        f"RandStudent Acc: {rand_student_acc:.4f} | "
                        f"BestCandidate: {epoch_best_name} ({epoch_best_acc:.4f}) | "
                        f"Accepted: {int(accepted)} | "
                        f"Server Winner: {best_overall_name} | "
                        f"Server Test Acc: {best_overall_acc:.4f} | "
                        f"Best Acc: {best_overall_acc:.4f}"
                    )

                final_server = get_model(args)
                final_server.load_state_dict(best_overall_state)
                final_server.cuda()

                save_stage6_checkpoint(
                    best_overall_state,
                    best_generator_state,
                    best_overall_acc,
                    args.epochs - 1,
                    best_overall_name
                )

                np.save(f"distill_acc_{args.dataset}_oscofl_stage6.npy", np.array(server_acc_list))
                return final_server

            train_oscofl_stage6(args, test_loader, client_stats, local_weights, final_local_weights)
        if args.algorithm == "oscofl_stage8":  
            def train_client_downlink_distill(
            args,
            client_model,
            teacher_model,
            generator,
            local_loader,
            optimizer,
            global_centers,
            client_classes,
            num_classes=10,
            nz=100,
            alpha_kd=0.1,
            alpha_feat=0.0,
            temperature=2.0
            ):
                """
                OS-CoFL 第 8 阶段：
                客户端下行样本级蒸馏。

                客户端训练目标：
                L_client = L_CE(real data)
                        + alpha_kd * L_KD(fake data soft label)
                        + alpha_feat * L_Feature(fake data embedding)
                """

                client_model.train()
                teacher_model.eval()
                generator.eval()

                total_loss = 0.0
                total_ce = 0.0
                total_kd = 0.0
                total_feat = 0.0

                for images, labels in local_loader:
                    images = images.cuda()
                    labels = labels.cuda()

                    optimizer.zero_grad()

                    # =====================================================
                    # 1. 本地真实数据监督训练
                    # =====================================================
                    logits_real, feats_real = client_model(images, return_feature=True)
                    loss_ce = F.cross_entropy(logits_real, labels)

                    # =====================================================
                    # 2. 服务器生成伪样本和 soft label
                    # =====================================================
                    # 只从当前客户端本地存在的类别中采样伪标签
                    rand_idx = torch.randint(
                        low=0,
                        high=len(client_classes),
                        size=(images.size(0),),
                        device="cuda"
                    )

                    fake_labels = client_classes[rand_idx]

                    z = torch.randn(images.size(0), nz).cuda()
                    target_centers = global_centers[fake_labels].detach()

                    with torch.no_grad():
                        fake_images = generator(z, fake_labels, target_centers)
                        teacher_logits, teacher_feats = teacher_model(
                            fake_images,
                            return_feature=True
                        )
                        teacher_soft = F.softmax(teacher_logits / temperature, dim=1)

                    # =====================================================
                    # 3. 客户端模仿教师 soft label
                    # =====================================================
                    student_logits, student_feats = client_model(
                        fake_images,
                        return_feature=True
                    )

                    loss_kd = F.kl_div(
                        F.log_softmax(student_logits / temperature, dim=1),
                        teacher_soft,
                        reduction="batchmean"
                    ) * (temperature ** 2)

                    # =====================================================
                    # 4. 特征对齐
                    # =====================================================
                    if alpha_feat > 0:
                                student_feats_norm = F.normalize(student_feats, dim=1)
                                teacher_feats_norm = F.normalize(teacher_feats.detach(), dim=1)

                                loss_feat = 1.0 - F.cosine_similarity(
                                    student_feats_norm,
                                    teacher_feats_norm,
                                    dim=1
                                ).mean()
                    else:
                                loss_feat = torch.tensor(0.0, device="cuda")

                    loss = loss_ce + alpha_kd * loss_kd + alpha_feat * loss_feat

                    loss.backward()
                    optimizer.step()

                    total_loss += loss.item()
                    total_ce += loss_ce.item()
                    total_kd += loss_kd.item()
                    total_feat += loss_feat.item()

                num_batches = len(local_loader)

                return {
                    "loss": total_loss / num_batches,
                    "ce": total_ce / num_batches,
                    "kd": total_kd / num_batches,
                    "feat": total_feat / num_batches
                }
            def run_oscofl_stage8(args, train_dataset, test_loader, user_groups):
                """
                OS-CoFL 第 8 阶段：
                在 Stage 6 的服务器教师模型基础上，执行下行客户端蒸馏。
                """

                pkl_path = './pkl/'
                ckpt_path = os.path.join(
                    pkl_path,
                    f'{args.timestr}-{args.dataset}_{args.num_users}clients_{args.beta}.pkl'
                )

                save_obj = torch.load(ckpt_path)
                local_weights = save_obj["weights"]
                client_stats = save_obj["client_stats"]

                # 1. 重新聚合 global_probs / global_centers
                global_probs, global_centers, class_weights = aggregate_client_stats(
                    client_stats,
                    device="cuda"
                )

                # 2. 加载 Stage 6 最优服务器教师模型和 SGG
                stage6_ckpt = torch.load(
                    f"df_ckpt/{args.timestr}-oscofl-stage6-best.pth"
                )

                teacher_model = get_model(args)
                teacher_state = stage6_ckpt.get("server_model", stage6_ckpt.get("state_dict"))
                teacher_model.load_state_dict(teacher_state)
                teacher_model.cuda()
                teacher_model.eval()

                feature_dim = global_centers.size(1)
                from models.oscofl_sgg import SemanticGuidedGenerator
                generator = SemanticGuidedGenerator(
                    nz=args.nz,
                    num_classes=10,
                    feature_dim=feature_dim,
                    img_size=28,
                    nc=1,
                    ngf=64,
                    semantic_dim=100
                ).cuda()

                generator.load_state_dict(stage6_ckpt["generator"])
                generator.eval()

                # 3. 对每个客户端执行下行蒸馏
                client_acc_before = []
                client_acc_after = []

                updated_client_weights = []

                for idx in range(args.num_users):
                    args.flogger.info(f"========== Stage8 Client {idx} Downlink Distill ==========")

                    client_model = get_client_model(args, idx, client_model_types)
                    client_model.load_state_dict(local_weights[idx])
                    client_model.cuda()

                    # 蒸馏前客户端精度
                    before_acc, before_loss = test(client_model, test_loader)
                    client_acc_before.append(before_acc)

                    class_counts = client_stats[idx]["class_counts"]
                    client_classes = torch.where(class_counts > 0)[0].cuda()
                    if len(client_classes) == 0:
                        client_classes = torch.arange(10).cuda()
                    args.flogger.info(
                            f"[Stage8][Client {idx}] local classes: "
                            f"{client_classes.detach().cpu().tolist()}"
                    )

                    local_loader = DataLoader(
                        DatasetSplit(train_dataset, user_groups[idx]),
                        batch_size=args.local_bs,
                        shuffle=True,
                        num_workers=4
                    )

                    optimizer = torch.optim.SGD(
                        client_model.parameters(),
                        lr=0.001,
                        momentum=0.9,
                        weight_decay=5e-4
                    )
                    # 回退机制
                    best_acc = before_acc
                    best_state = copy.deepcopy(client_model.state_dict())

                    # 建议先跑 5~10 个本地 epoch，不要太多
                    local_distill_epochs = 5

                    for ep in range(local_distill_epochs):
                        log_dict = train_client_downlink_distill(
                            args=args,
                            client_model=client_model,
                            teacher_model=teacher_model,
                            generator=generator,
                            local_loader=local_loader,
                            optimizer=optimizer,
                            global_centers=global_centers,
                            client_classes=client_classes,
                            num_classes=10,
                            nz=args.nz,
                            alpha_kd=0.1,
                            alpha_feat=0.0,
                            temperature=2.0
                        )

                        acc, loss = test(client_model, test_loader)
                        if acc > best_acc:
                            best_acc = acc
                            best_state = copy.deepcopy(client_model.state_dict())

                        args.flogger.info(
                            f"[Stage8][Client {idx}] Epoch {ep:02d} | "
                            f"Loss: {log_dict['loss']:.4f} | "
                            f"CE: {log_dict['ce']:.4f} | "
                            f"KD: {log_dict['kd']:.4f} | "
                            f"Feat: {log_dict['feat']:.4f} | "
                            f"Test Acc: {acc:.4f}"
                        )

                    client_model.load_state_dict(best_state)

                    after_acc, after_loss = test(client_model, test_loader)
                    client_acc_after.append(after_acc)

                    updated_client_weights.append(copy.deepcopy(client_model.state_dict()))

                    args.flogger.info(
                        f"[Stage8][Client {idx}] Before: {before_acc:.4f}, "
                        f"After: {after_acc:.4f}"
                    )


                args.flogger.info(f"Stage8 client_acc_before: {client_acc_before}")
                args.flogger.info(f"Stage8 client_acc_after: {client_acc_after}")
                args.flogger.info(
                    f"Stage8 average before: {np.mean(client_acc_before):.4f}, "
                    f"average after: {np.mean(client_acc_after):.4f}"
                )

                torch.save(
                    {
                        "updated_client_weights": updated_client_weights,
                        "client_acc_before": client_acc_before,
                        "client_acc_after": client_acc_after
                    },
                    f"df_ckpt/{args.timestr}-oscofl-stage8-clients.pth"
                )
            run_oscofl_stage8(args, train_dataset, test_loader, user_groups)
        import sys
        sys.exit(0)

        # 为了严格一步一步走，我们现在在此处退出流程，待您确认数据无误后，再开启第三阶段
        import sys
        sys.exit("【阶段二验证完成】请检查上方 log 输出与终端日志，确认 global_probs 和 global_centers 是否正常！")

        # 通过普通的 FedAvg 求出一个【初始】的全局模型 baseline
        global_weights = get_server_init_weights(args, local_weights, client_model_types)
        global_model.load_state_dict(global_weights)
        # print("avg acc:")
        test_acc, test_loss = test(global_model, test_loader)

        # 提取各个客户端经过单独训练且存在明显个体偏差（Non-IID 特征）的模型
        model_list = []
        for i in range(len(local_weights)):
            net = get_client_model(args, i, client_model_types) # 用与客户端匹配的结构恢复本地模型
            net.load_state_dict(local_weights[i]) # 塞入第 i 个客户端传过来的特定大脑（经验）
            model_list.append(net)

        # 构建一个巨大的“集成（Ensemble）模型”：它包含了所有客户端独家的推理系统，它是我们的【老师】。
        # 集成模型通常意味着：投票表决（大家综合打分），它比简单把脑细胞揉成一团(FedAvg)要准。
        # 注意：这里需要使用 EnsemblePro 以支持特征对齐阶段单独选中某一个老师进行面试
        ensemble_model = EnsemblePro(model_list)

        # print("ensemble acc:")
        ens_acc, ens_loss = test(ensemble_model, test_loader)
        args.flogger.info(f"ensemble acc:{ens_acc}, ensemble_loss:{ens_loss}")
        # ===============================================
        
        # 重新再拿个白板全局模型作为我们的【学生】。这次我们要教它拥有教师的逻辑脑。
        global_model = get_model(args)
        # ===============================================

        # ================== 核心：伪数据生成器创建篇 =====================
        # 中心服务器为了蒸馏模型，但受制于不能获取数据，于是通过生成对抗思想捏造出“假照片”。
        # 比如对于 cifar10 它是 32x32 的图片。
        nz = args.nz
        if args.dataset == 'cifar10':
            nc = 3       # 彩图通道为 3
            img_size = 32
            img_size2 = (3, 32, 32)
        elif args.dataset in ['mnist', 'fmnist']:
            nc = 1       # 灰度图为 1
            img_size = 28
            img_size2 = (1, 28, 28)
        else: # tiny
            nc = 3
            img_size = 64
            img_size2 = (3, 64, 64)
            
        generator = Generator(nz=nz, ngf=64, img_size=img_size, nc=nc).cuda()
        args.cur_ep = 0
        num_class = 200 if args.dataset == "tiny" else 10
        args.save_dir = f'run/{args.dataset}/{args.timestr}/{args.algorithm}-iid({args.beta})-C{args.num_users}-Eps{args.local_ep}-KLEps{args.epochs}-gsteps{args.g_steps}-nz{args.nz}-glce{args.oh}-glbn{args.bn}-gladv{args.adv}-kla1{args.kl_alpha1}-kla2{args.kl_alpha2}'

        global_feature_proto = aggregate_feature_protos(client_feature_protos, num_classes=10)

        # SASynthesizer（合成器）：它驱动着 Generator 开始画能够“欺骗”老师并促使学生学习的新数据照片！
        synthesizer = SASynthesizer(ensemble_model, model_list, global_model, generator,
                                     nz=nz, num_classes=num_class, img_size=img_size2,
                                     iterations=args.g_steps, lr_g=args.lr_g,
                                     synthesis_batch_size=args.synthesis_batch_size,
                                     sample_batch_size=args.batch_size,
                                     adv=args.adv, bn=args.bn, oh=args.oh,
                                     save_dir=args.save_dir, dataset=args.dataset, test_dataloader=test_loader, args=args,
                                     feature_proto=global_feature_proto)

        # 联邦无数据蒸馏使用的相对熵 KL 指导老师和学生的学习差距损失
        criterion = KLCom(T=args.T, alpha1=args.kl_alpha1, alpha2=args.kl_alpha2,reduction='mean')
        
        # 【学生】全局模型的优化器。这里按照主流文献，切换为 Adam 或者稍微调整学习率，防止前期学崩。
        optimizer = torch.optim.Adam(global_model.parameters(), lr=args.lr)
        global_model.train()
        distill_acc = []
        
        test_loss_records = []
        test_acc_records = []
        
        # ========== 全局模型通过蒸馏不断进化的迭代循环 ==========
        for epoch in tqdm(range(args.epochs)):
            # 步骤一：数据合成。Generator 会画出一批专门用于学习的“难辨假数据”
            synthesizer.gen_data(args.cur_ep)  # g_steps
            args.cur_ep += 1

            # 步骤二：实施蒸馏训练策略。在此阶段拿伪数据让模型(学生)效仿集成模型(老师)的投票结果。
            sa_kd_train(synthesizer, [global_model, synthesizer.en_teacher], criterion, optimizer,
                     args=args)  # # kd_steps

            # 一轮蒸馏训练后，看看学生在真正验证集上分数表现如何
            acc, test_loss = test(global_model, test_loader)
            
            test_loss_records.append(test_loss)
            test_acc_records.append(acc)
            
            fig, ax1 = plt.subplots(figsize=(8, 6))

            color = 'tab:red'
            ax1.set_xlabel('Epoch')
            ax1.set_ylabel('Test Loss', color=color)
            ax1.plot(test_loss_records, color=color, marker='o', label='Test Loss')
            ax1.tick_params(axis='y', labelcolor=color)

            ax2 = ax1.twinx()  
            color = 'tab:blue'
            ax2.set_ylabel('Test Accuracy', color=color)  
            ax2.plot(test_acc_records, color=color, marker='x', label='Test Accuracy')
            ax2.tick_params(axis='y', labelcolor=color)

            fig.tight_layout()  
            plt.title('Global Model Performance during Distillation')
            plt.grid(True)
            plt.savefig(f'experiment_curves_{args.dataset}_{args.epochs}ep.png')
            plt.close()            
            
            distill_acc.append(acc)
            is_best = acc > bst_acc # 遇到最好结果的学生，立即存档！
            bst_acc = max(acc, bst_acc)
            os.makedirs('df_ckpt', exist_ok=True)
            _best_ckpt = f'df_ckpt/{args.timestr}-{args.other}.pth'
            args.flogger.info("best acc:{}".format(bst_acc))
            save_checkpoint({
                'state_dict': global_model.state_dict(),
                'best_acc': float(bst_acc),
            }, is_best, _best_ckpt)

        # 将历代得分以 numpy 的形式沉淀保留至文件
        np.save("distill_acc_{}.npy".format(args.dataset), np.array(distill_acc))
