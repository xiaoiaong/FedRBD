import copy
from abc import ABC, abstractclassmethod
from typing import Dict

import pylab as p
import torch
import torch.nn as nn
import torch.nn.functional as F
# import ipdb
from kornia import augmentation
from torchvision import transforms
from tqdm import tqdm
import torchvision.utils as vutils
from helpers.utils import ImagePool, ImagePoolPro, DeepInversionHook, average_weights, kldiv, test, test_pro
import numpy as np
from sklearn.cluster import KMeans
from collections import Counter
import os

upsample = torch.nn.Upsample(mode='nearest', scale_factor=7)


class MultiTransform:
    """Create two crops of the same image"""

    def __init__(self, transform):
        self.transform = transform

    def __call__(self, x):
        return [t(x) for t in self.transform]

    def __repr__(self):
        return str(self.transform)

class Ensemble_A(torch.nn.Module):
    def __init__(self, model_list):
        super(Ensemble_A, self).__init__()
        self.models = model_list

    def forward(self, x):
        logits_total = 0
        for i in range(len(self.models)):
            logits = self.models[i](x)
            logits_total += logits
        logits_e = logits_total / len(self.models)

        return logits_e

class Ensemble_E(torch.nn.Module):
    """
    联邦强化版的教师(Ensemble Teacher)
    它不仅简单地把多个客户端模型（专家）打包，更核心的是拥有动态分配投票权重的能力。
    这是极其重要的：在非独立同分布（Non-IID）场景中，比如客户端1只见过猫，它预测狗时瞎猜，没资格当老师；
    而客户端2见过几百张狗，它预测狗就是权威。
    因此 Ensemble_E 在输出（P_b）时，会自动根据当前造出来的图片属于哪个类别，给具有发言权的客户端赋予更高的重要性（self.V）。
    model_list：所有客户端老师模型列表
    label_logit_weights：面试得到的专长权重（核心！）
    model_logit_weights：额外权重（暂时不用管）
    """
    def __init__(self, model_list, label_logit_weights, model_logit_weights):
        super(Ensemble_E, self).__init__()
        self.models = model_list # 所有客户端传上来的私有模型集合
        self.label_logit_weights = label_logit_weights
        self.model_logit_weights = model_logit_weights

    def set_batch_targets(self, targets):
        """设定这批新图片想要伪造出的目标标签，并根据这一批目标，计算针对这一批的【投票权重矩阵 V】"""
        self.targets = targets
        # 创建一个空的权重表 V
        # 最终维度：(batch_size, 老师数量)
        V = np.empty((0, len(self.models)))
        # 把面试得到的专长权重表转成 numpy 数组
        # U = 所有老师对所有类别的擅长分数
        U = np.array(self.label_logit_weights)
        # 循环每一张图
        # 一张图一张图分配老师权重
        for s in range(len(targets)):
            # 拿到当前这张图的目标类别
            # 比如：这张图是猫 = 3
            target_class = targets[s].item() if isinstance(targets[s], torch.Tensor) else targets[s]
            # 判断：权重表格式对不对
            # 确保能取出 U[:, target_class]
            if len(U.shape) == 2 and U.shape[0] == len(self.models) and U.shape[1] > target_class:
                # 取出 所有老师 在 当前类别 上的专长分数
                # 加到权重表 V 里
                v_row = U[:, target_class]
            else:
                v_row = U[target_class]
                
            # 归一化权重以防极大值导致溢出或 NaN
            v_row = v_row / (np.sum(v_row) + 1e-8)
            V = np.vstack((V, v_row))
        self.V = V # 这个 V 的维度意味着：当前批次中的哪个类别，更应该倾向于听信哪一位老师（客户端专家）

    def compute_bn_loss(self, hooks):
        """
        数据恢复的精髓技术之一：通过匹配所有客户端模型中 BatchNorm 层的统计量（均值与方差），
        来确保造出来的图片特征在底层物理意义上，真实逼近客户端们原来见过的真图像！
        因为模型训练时 BN 层记录了私有原始数据的统计知识，这被当作了一种合法的隐私信息利用。
        """
        m_bn_loss = []
        for idx, hs in hooks.items():
            loss_bn = sum([h.r_feature for h in hs])
            m_bn_loss.append(loss_bn)

        return sum(m_bn_loss)/len(m_bn_loss)


    def forward(self, x):
        P = []
        for k in range(len(self.models)):
            logits = self.models[k](x) # 每个客户端分别对图片打分
            P.append(logits) # each is [batch_size, num_classes]

        # Stack into [batch_size, num_clients, num_classes]
        P_stack = torch.stack(P, dim=1) 
        
        # V_tensor 就是核心的偏袒参数矩阵
        if (not hasattr(self, "V")) or self.V is None or len(self.V) != P_stack.size(0):
            return torch.mean(P_stack, dim=1)

        # V has shape [batch_size, num_clients]. We want to weight each client's logits.
        # Add a dimension to V to match P_stack: [batch_size, num_clients, 1]
        V_tensor = torch.tensor(self.V, device=x.device, dtype=torch.float32).unsqueeze(-1)
        
        # Weighted sum across clients (dim=1)
        # 将所有的客户端输出按权重合并成老师的最终答案
        P_b = torch.sum(P_stack * V_tensor, dim=1)

        return P_b

def reset_model(model):
    for m in model.modules():
        if isinstance(m, (nn.ConvTranspose2d, nn.Linear, nn.Conv2d)):
            nn.init.normal_(m.weight, 0.0, 0.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        if isinstance(m, (nn.BatchNorm2d)):
            nn.init.normal_(m.weight, 1.0, 0.02)
            nn.init.constant_(m.bias, 0)


class SASynthesizer():
    def __init__(self, teacher, model_list, student, generator, nz, num_classes, img_size,
                 iterations, lr_g,
                 synthesis_batch_size, sample_batch_size,
                 adv, bn, oh, save_dir, dataset, test_dataloader, args, feature_proto=None,
                 target_sampler=None, generator_mode="plain"):
        super(SASynthesizer, self).__init__()
        self.feature_proto = feature_proto
        self.proto_weight = 0.1
        self.target_sampler = target_sampler
        self.generator_mode = generator_mode
        self.student = student # 学生
        self.img_size = img_size
        self.iterations = iterations # 生成图片时，要优化多少轮
        self.lr_g = lr_g # 生成器的学习率
        self.nz = nz # 噪声向量长度，生成器用噪声生成图片
        self.adv = adv # 对抗损失权重
        self.bn = bn # BN损失权重
        self.oh = oh # 独热编码损失权重
        self.num_classes = num_classes # 分类总数，比如 10 类
        self.synthesis_batch_size = synthesis_batch_size # 一次生成多少张假图
        self.sample_batch_size = sample_batch_size # 给学生训练时，一次拿多少张假图
        self.save_dir = save_dir # 生成的假图存在哪里
        self.data_pool = ImagePoolPro(root=self.save_dir) # 图片池，用来存生成好的假图
        self.data_iter = None # 数据迭代器，暂时为空
        self.teacher = teacher # 老师
        self.dataset = dataset # 数据集名称，如 CIFAR10
        self.test_dataloader = test_dataloader # 测试集，用来最后测试学生模型

        self.generator = generator.cuda().train() # 生成器
        self.generator_list = [copy.deepcopy(self.generator) for i in range(len(model_list))] # 给每个客户端老师都复制一个生成器
        self.strong_class_list = [[] for i in range(len(model_list))]    # 记录每个客户端老师最擅长哪一类图片
        self.model_list = model_list # 所有联邦客户端老师都在这里
        self.label_logit_weights = [[1 for _ in range(self.num_classes)] for _ in range(len(model_list))] # 记录每个客户端老师最擅长哪一类图片
        self.model_logit_weights = [[1 for _ in range(self.num_classes)] for _ in range(len(model_list))] # 记录每个客户端老师整体的发言权重（不分类别的平均水平），这个在后续的集成老师里会用到

        self.args = args

        self.sythesis_acc_num = 0  # 记录生成的假图被正确识别的数量

        os.makedirs('./lw', exist_ok=True) # 创建文件夹，存权重
        timestr_name = self.args.timestr if self.args.timestr else 'default_run'
        self.logit_weight_file = os.path.join('./lw', timestr_name) # 权重文件保存路径

        # MultiTransform：输入一张图，输出两种不同裁剪方式的图（全局裁剪和局部裁剪），让生成的假图更丰富多样，更像真图。
        self.aug = MultiTransform([ # 数据增强：全局裁剪，局部裁剪，让假图更丰富。
            # global view
            transforms.Compose([
                augmentation.RandomCrop(size=[self.img_size[-2], self.img_size[-1]], padding=4),# 随机裁剪，并输出原来图片的大小，给图片的上下左右都增加四个像素
                augmentation.RandomHorizontalFlip(), # 随机左右旋转
            ]),
            # local view
            transforms.Compose([
                # 从原图里随机抠一小块（最小可以只抠 25%）然后强行放大回原图尺寸
                # → 这就变成了局部特写、细节图
                augmentation.RandomResizedCrop(size=[self.img_size[-2], self.img_size[-1]], scale=[0.25, 1.0]),
                augmentation.RandomHorizontalFlip(),
            ]),
        ])



        self.transform = transforms.Compose( # 普通数据增强：裁剪、翻转、转张量
            [
                transforms.RandomCrop(self.img_size[-1], padding=4), # 自适应大小，取代硬编码32
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
            ])

        self.access_teacher_models() # 开始面试所有老师
        
        # 把所有老师集成为一个超级老师
        self.en_teacher = Ensemble_E(self.model_list, self.label_logit_weights, self.model_logit_weights)

    def sample_targets(self):
        if self.target_sampler is not None:
            return self.target_sampler(self.synthesis_batch_size)
        targets = torch.arange(self.synthesis_batch_size) % self.num_classes
        targets = targets[torch.randperm(self.synthesis_batch_size)]
        return targets.cuda()

    def forward_generator(self, generator, z, targets):
        if self.generator_mode == "semantic":
            target_centers = []
            proto_template = None
            if self.feature_proto:
                proto_template = next(iter(self.feature_proto.values()))["mean"]
            for y in targets:
                label_id = int(y.item())
                if self.feature_proto and label_id in self.feature_proto:
                    target_centers.append(self.feature_proto[label_id]["mean"])
                elif proto_template is not None:
                    target_centers.append(torch.zeros_like(proto_template))
                else:
                    raise ValueError("Semantic generator requires class prototypes.")
            target_centers = torch.stack(target_centers).cuda()
            return generator(z, targets, target_centers)
        return generator(z)

    def access_teacher_models(self):

        # 如果【权重分数文件】不存在 → 就进入面试
        # 如果文件已经存在 → 直接跳过，不面试！
        if not os.path.exists(self.logit_weight_file):
            for id in range(len(self.generator_list)): # 有多少个客户端，就循环多少次，挨个面试每一个老师！
                self.teacher.select_client(id) # 切换到当前要面试的客户端老师 告诉系统：我现在要面试第 id 号老师！
                # 调用面试函数，把【当前老师】和【客户端编号】传进去，开始面试！
                self.interview(self.teacher.models[id], id)
            with open(self.logit_weight_file, 'w') as file:
                for row in self.label_logit_weights:
                    file.write(' '.join(map(str, row)) + '\n')
        else:
            loaded_weights = []
            with open(self.logit_weight_file, 'r') as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue
                    loaded_weights.append([float(x) for x in line.split()])
            if len(loaded_weights) == len(self.label_logit_weights):
                self.label_logit_weights = loaded_weights

    # 这是一个公开方法，外面的代码可以直接调用
    # cur_ep：告诉你现在是第几轮训练（比如联邦学习第 5 轮）
    # 作用：告诉合成器：现在开始生成假数据！
    def gen_data(self, cur_ep):
        self.synthesize(self.en_teacher, cur_ep)


    def get_data(self):
        # 1. 从图片池里拿到所有生成好的假图
        datasets = self.data_pool.get_dataset(transform=self.transform)  # 获取程序运行到现在所有的图片
        max_synthetic_samples = getattr(self.args, "max_synthetic_samples", None)
        if max_synthetic_samples is not None and len(datasets) > max_synthetic_samples:
            start = len(datasets) - max_synthetic_samples
            datasets = torch.utils.data.Subset(datasets, range(start, len(datasets)))
        # 2. 把图片打包成 PyTorch 标准数据加载器
        self.data_loader = torch.utils.data.DataLoader(
            datasets, 
            batch_size=self.sample_batch_size, 
            shuffle=True,
            num_workers=4, # 4个线程加速读取
            pin_memory=True, # GPU 加速用
            )
        return self.data_loader

    def eval_test(self, model, test_data):
        model.eval()
        test_loss = 0
        correct = 0
        predictions = []  # List to store prediction labels


        test_data = test_data.cuda()
        output = model(test_data)

        # pred = torch.max(output, 1)[1]

        probabilities = F.softmax(output, dim=-1)

        predicted_labels = torch.argmax(probabilities, dim=-1).tolist()

        # Append prediction labels to the list
        predictions.extend(predicted_labels)  # Convert to CPU and to a NumPy array

        return predictions

    def interview(self, net, userid):
        """
        面试(Interview)：就像招聘员工了解他的专长。
        在一个异构联邦网络中，有的人手里的猫图多，有的人只有狗。如何知道哪个客户端最配当哪类知识的老师？
        在这里，服务端利用 Generator 进行反复生成( iterations 次)，记录每个客户端模型(net)对于每种常见图像（如 0-9共十类）
        交叉熵和梯度的“反应”。
        如果净对这种生成类有强烈、准确的反应（即 loss 下降平稳或较小），就说明该用户曾经真正拥有大量这类数据。
        最终得到一组能衡量每一位客户端对特定类的发言权权重 (label_var_degree)。
        这部分生成的“初级图片”只是作为面试题，用来量化老师权重的，不算到后面的大蒸馏里。
        """
        net.eval()

        label_batch_loss = {u: [] for u in range(self.num_classes)} # 记录每类标签的交叉熵
        label_var_degree = []   # 存储每类标签的权值 (用来存最终每一类的专长分数)

        with tqdm(range(self.num_classes)) as tl:
            for label in tl:
                best_cost = 1e6 # 初始一个超级大的数 用来记录当前类别考试中最小的 loss
                best_inputs = None # 保存当前类别生成的最好的一张图
                z = torch.randn(size=(self.synthesis_batch_size, self.nz)).cuda()  # 这里在生成随机噪声
                targets = torch.randint(low=label, high=label+1, size=(self.synthesis_batch_size,)) # 全是当前label
                targets = targets.sort()[0] # 把标签排个序（不影响功能，只是整齐）
                targets = targets.cuda() # 把标签放到 GPU
                reset_model(self.generator_list[userid]) # 把这个客户端对应的生成器重置，保证每一类考试都是全新开始
                # 同时优化“生成器的参数”以及最核心的“潜在空间向量 z ”（它也需要被微调，这叫模型反演技术 Model Inversion）
                optimizer = torch.optim.Adam([{'params': self.generator_list[userid].parameters()}, {'params': [z]}], self.lr_g,
                                             betas=[0.5, 0.999])
                hooks = [] # 空列表，用来放 BN 钩子，让假图更像真图用的

                # 遍历老师模型
                # 给所有 BN 层装钩子
                # 钩子作用：偷老师的图像分布，让假图更真实
                for m in net.modules():
                    if isinstance(m, nn.BatchNorm2d):
                        hooks.append(DeepInversionHook(m))
                        # print(f'm: {m}')

                # 内层循环：每一类题要反复优化迭代很多次，比如迭代 500 次，把题目越出越好
                with tqdm(range(self.iterations)) as t:
                    for it in t:
                        optimizer.zero_grad()
                        # 生成器把噪声 z → 生成假图，这就是面试题
                        inputs = self.forward_generator(self.generator_list[userid], z, targets)  # bs,nz
                        # 对假图做数据增强（裁剪、翻转），让题目更真实
                        global_view, _ = self.aug(inputs)  # crop and normalize
                        # 老师看假图，输出预测结果
                        t_out = net(global_view)

                        # 计算交叉熵损失，loss 越小 → 老师做得越准
                        loss_oh = F.cross_entropy(t_out, targets)  # ce_loss
                        
                        # 让学生模型也看一眼图（这里只是辅助用）
                        s_out = self.student(global_view)
                        # 看学生和老师答案是否不一样，面试阶段没实际使用，可以忽略
                        mask = (s_out.max(1)[1] != t_out.max(1)[1]).float()

                        loss = self.oh * loss_oh
                        # 如果当前 loss 更小，更新最小 loss，保存当前最好的图
                        if best_cost > loss.item() or best_inputs is None:
                            best_cost = loss.item()
                            best_inputs = inputs.data
                        # 把这一步的 loss 记录到对应类别的列表里，后面要靠它算专长分数
                        label_batch_loss[label].append(loss.item())

                        loss.backward() # 反向传播，计算梯度
                        optimizer.step() # 更新生成器和 z，让下一张图出得更好
                        # 打印日志，显示当前第几类、第几轮、loss 多少
                        t.set_description('[interview]=>label:{}, iters:{}, loss:{}, ce:{}'.format(label, it, loss.item(), loss_oh))
                    # vutils.save_image(best_inputs.clone(), '1.png', normalize=True, scale_each=True, nrow=10)

                # 波动分数 = (最大loss - 最小loss) / 最小loss
                min_loss = min(label_batch_loss[label])
                if min_loss < 1e-8:
                    min_loss = 1e-8
                var_degree = (max(label_batch_loss[label])-min_loss)/min_loss
                # 把当前类别的专长分数存起来
                label_var_degree.append(var_degree)
        # 把这个客户端所有类别的最终专长权重存进总表
        # 后面给超级老师投票用
        # 格式：[客户端id][类别] = 专长分数
        self.label_logit_weights[userid] = label_var_degree


    def synthesize(self, net, cur_ep): # net = 集成好的超级老师（所有客户端老师合体）cur_ep = 当前是联邦学习第几轮训练
        """
        开始真正的“炼制丹药(假数据)”阶段 (Data Synthesis)。
        这是整个 Data-Free KD（无数据网络蒸馏）的核心函数所在：利用生成对抗生成高质量、能教坏学生的“好试题”。
        
        参数: net -> 这个是集成后的大教师（Ensemble_E）
        """
        net.cuda() # 把超级老师放到 GPU
        net.eval() # 设为 评估模式（老师只负责判题，不学习、不更新）
        # 记录最好的一批假图（loss 最小的那批）
        best_cost = 1e6
        best_inputs = None
        # 1. 随机生成一组充满魔性(需要被求解)的噪声空间 z
        z = torch.randn(size=(self.synthesis_batch_size, self.nz)).cuda()  #
        z.requires_grad = True # 这里是重点：除了优化网络本身的骨架(CNN权重)，也对输入这组图片的“潜变量”实行优化。
        
        # 2. 也是随机分配目标类别（我希望能生造一批包含这几种标签的假图）
        targets = self.sample_targets()

        reset_model(self.generator) # 初始化生成器
        # 优化两个东西：
        # 1. 生成器网络
        # 2. 噪声 z
        # 目标：让生成器 + z 一起造出完美假图
        # 下面的betas是什么？ 
        # betas是Adam优化器的超参数，控制动量和二阶矩估计的衰减率。具体来说：
        # ① beta1 = 0.5
            # 控制梯度的滑动平均
            # 理解成：记住过去 50% 的梯度方向
        # ② beta2 = 0.999
            # 控制梯度平方的滑动平均
            # 理解成：记住过去 99.9% 的梯度大小
        optimizer = torch.optim.Adam([{'params': self.generator.parameters()}, {'params': [z]}], self.lr_g,
                                     betas=[0.5, 0.999])
        #############################################
        dim_in = 500 if "cifar100" == self.dataset else 50

        # hooks = {
        #    0: [],  # 给第0个模型用的钩子
        #    1: [],  # 给第1个模型用的钩子
        #    2: [],  # 给第2个模型用的钩子
        #    3: []   # 给第3个模型用的钩子
        #}
        hooks = {idx:[] for idx in range(len(net.models))}
        # DeepInversion 技术的核心钩子，套住所有客户端的那些BatchNorm统统不能跑掉
        # 偷老师的 BatchNorm 统计信息，让假图拥有真实图片的纹理、亮度、分布特征
        # → 假图看起来和真图一模一样
        for subidx, subnet in enumerate(net.models):
            for m in subnet.modules():
                if isinstance(m, nn.BatchNorm2d):
                    hooks[subidx].append(DeepInversionHook(m))

        # 为这次集成老师生成它的投票比重 V（由 interview 计算好备用的）
        # 这批图的标签我定好了，你按这个判！
        net.set_batch_targets(targets)

        with tqdm(range(self.iterations)) as t: # 循环几百次，一点点优化假图
            for it in t:
                optimizer.zero_grad()
                
                # 开始产生幻像假图
                inputs = self.forward_generator(self.generator, z, targets)  # z（噪声）→ 生成器 → 假图片  这就是造图过程
                global_view = inputs
                
                # 拿假图给老师看 超级老师给假图打分 输出每个类别的概率
                t_out = net(global_view)

                # 【损失 1：让物理特征相近】(DeepInversion)
                # 这个叫做批归一化损失，是让假图片具备跟客户端真实照片一模一样的局部均值与方差
                loss_bn = net.compute_bn_loss(hooks)
                
                # 强迫生成器把图画成【老师一眼就能认出是某一类】的样子
                # 让假图足够清晰、足够标准，老师看了自然会坚定打分
                loss_oh = F.cross_entropy(t_out, targets)

                # 【损失 3：刻意难为学生】对立损失 (Adversarial distillation loss)
                # 这个算是高级点玩法：我尽量搞一些学生看了发懵、但老师门儿清的照片（或者学生和老师观点根本不一样的地方）。
                # 这样拿出的试卷才最有区分度！最能让基础薄弱的学生在“错的最远”的题上得到知识冲击。
                s_out = self.student(global_view)
                mask = (s_out.max(1)[1] != t_out.max(1)[1]).float() # 寻找学生和老师分歧大的照片
                
                # kldiv 计算两个分布差异，前面加这个负号代表我是要在此时努力去【拉大】学生与老师的分歧（这叫对抗生成）。
                # 这个损失仅作用于生成器（Generator）而不是学生模型自身，这会让生成器往“更刁钻（Adversarial）能迷惑学生”的方向生成图片！
                loss_adv = -(kldiv(s_out, t_out, reduction='none').sum(
                    1) * mask).mean()  # decision adversarial distillation

                loss_proto = 0.0
                if hasattr(self, 'feature_proto') and self.feature_proto is not None:
                    _, s_feat = self.student(global_view, return_feature=True)

                    proto_targets = []
                    for y in targets:
                        y = int(y.item())
                        if y in self.feature_proto:
                            proto_targets.append(self.feature_proto[y]["mean"])
                        else:
                            proto_targets.append(torch.zeros_like(s_feat[0]))

                    proto_targets = torch.stack(proto_targets).cuda()
                    loss_proto = F.mse_loss(s_feat, proto_targets)

                # 这是总合的目标损失函数。整个优化过程是为了让假图：
                # 1. 具有真实特征 (BN)
                # 2. 让老师一眼认出这就是目标类 (OH)
                # 3. 故意找学生的茬，让学生此时看不懂 (ADV 对抗)
                loss = self.bn * loss_bn + self.oh * loss_oh + self.adv * loss_adv + (getattr(self, 'proto_weight', 0.0) * loss_proto if isinstance(loss_proto, torch.Tensor) else 0.0)

                # 取这些迭代中最小 Loss 的生成图留作“试卷”
                if best_cost > loss.item() or best_inputs is None:
                    best_cost = loss.item()
                    best_inputs = inputs.data

                # 开始更新“生成网络权重参数”以及“潜变量 Z 参数”以不断产出好的刁钻试卷。
                # 反向传播，更新生成器和 z
                loss.backward()
                optimizer.step()
                # optimizer_mlp.step()
                t.set_description('iters:{}, loss:{}, ce:{}, bn:{}， adv:{}'.format(it, loss.item(), loss_oh, loss_bn, loss_adv))
            # 保存图片 把最好的一批假图存成 1.png，你可以直接看到长啥样
            vutils.save_image(best_inputs.clone(), '1.png', normalize=True, scale_each=True, nrow=10)

        # 及时清理掉本轮添加的 Hooks，防止每轮重复添加导致内存泄漏和计算冗余
        for hs in hooks.values():
            for h in hs:
                h.remove()

        # 本次循环的刁钻试卷制作完毕，打印并将其沉淀入假图片资源池(data_pool)。
        # 日后 fed-main.py 的 `sa_kd_train`() 会把它一摞一摞调取出来，对可怜的“学渣(学生)”进疯狂培训。
        self.data_pool.add(best_inputs, targets.cpu().numpy())
