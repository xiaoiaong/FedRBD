import os
import logging
import hashlib
import numpy as np
import torch
import torchvision.transforms as transforms
from torchvision import datasets, transforms
import random
from PIL import Image


def resolve_data_root(data_root=""):
    root = (data_root or "").strip()
    if not root:
        root = "./dataset"
    return root


class WebVision20(torch.utils.data.Dataset):
    """Canonical Google-only WebVision subset for labels 0--19."""

    EXPECTED_SIZES = {"train": 24864, "val": 1000}
    EXPECTED_TRAIN_LABEL_SHA1 = "69a11d8e28b34d9d949056fc6be0b16d43faad57"
    EXPECTED_TRAIN_PATH_SHA1 = "fd6ac615002bac3b70219c8a64b4164784428b51"

    def __init__(self, root, split, transform):
        split = str(split).lower()
        if split not in self.EXPECTED_SIZES:
            raise ValueError("WebVision20 split must be 'train' or 'val'.")
        self.root = os.path.abspath(os.path.expanduser(root))
        self.split = split
        self.transform = transform
        filelist = os.path.join(
            self.root,
            "info",
            "train_filelist_all.txt" if split == "train" else "val_filelist.txt",
        )
        if not os.path.isfile(filelist):
            raise FileNotFoundError(f"WebVision filelist missing: {filelist}")
        image_root = (
            self.root
            if split == "train"
            else os.path.join(self.root, "val_images_256")
        )
        self.samples = []
        self.relative_paths = []
        with open(filelist, "r", encoding="utf-8-sig") as handle:
            for line_no, line in enumerate(handle, 1):
                parts = line.strip().split()
                if not parts:
                    continue
                if len(parts) != 2:
                    raise ValueError(f"Invalid WebVision filelist entry at {filelist}:{line_no}")
                relative_path, label_text = parts
                label = int(label_text)
                if 0 <= label < 20:
                    normalized_path = relative_path.replace("\\", "/")
                    if split == "train" and not normalized_path.startswith("google/"):
                        raise ValueError(
                            "WebVision20 training entry is not a Google image at "
                            f"{filelist}:{line_no}: {relative_path}"
                        )
                    self.relative_paths.append(normalized_path)
                    self.samples.append((os.path.join(image_root, relative_path), label))
        self.targets = [label for _, label in self.samples]
        expected_size = self.EXPECTED_SIZES[split]
        if len(self.samples) != expected_size:
            raise ValueError(
                f"WebVision20 {split} must contain {expected_size} samples; "
                f"found {len(self.samples)}."
            )
        if set(self.targets) != set(range(20)):
            raise ValueError(
                f"WebVision20 {split} must contain exactly labels 0..19."
            )
        if len(set(self.relative_paths)) != len(self.relative_paths):
            raise ValueError(
                f"WebVision20 {split} file list contains duplicate paths."
            )
        missing_paths = [path for path, _ in self.samples if not os.path.isfile(path)]
        if missing_paths:
            raise FileNotFoundError(
                f"WebVision20 {split} has {len(missing_paths)} missing images; "
                f"first: {missing_paths[0]}"
            )
        self.label_sha1 = hashlib.sha1(
            np.asarray(self.targets, dtype=np.int64).tobytes()
        ).hexdigest()
        self.path_sha1 = hashlib.sha1(
            "\n".join(self.relative_paths).encode("utf-8")
        ).hexdigest()
        if split == "train":
            if self.label_sha1 != self.EXPECTED_TRAIN_LABEL_SHA1:
                raise ValueError(
                    "WebVision20 training-label order mismatch: "
                    f"expected={self.EXPECTED_TRAIN_LABEL_SHA1} "
                    f"current={self.label_sha1}"
                )
            if self.path_sha1 != self.EXPECTED_TRAIN_PATH_SHA1:
                raise ValueError(
                    "WebVision20 training-path order mismatch: "
                    f"expected={self.EXPECTED_TRAIN_PATH_SHA1} "
                    f"current={self.path_sha1}"
                )
            print(
                "WebVision20 canonical train order: "
                f"samples={len(self.samples)} label_sha1={self.label_sha1} "
                f"path_sha1={self.path_sha1}",
                flush=True,
            )

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        path, label = self.samples[index]
        with Image.open(path) as image:
            image = image.convert("RGB")
            if self.transform is not None:
                image = self.transform(image)
        return image, label




def load_data(dataset, data_root=""):
    # 定义一个变量，告诉程序：我们的数据集（真实图片）存放在当前目录下的 dataset 文件夹里
    data_dir = resolve_data_root(data_root)
    if dataset == "mnist":
        train_dataset = datasets.MNIST(data_dir, train=True,download=True,
                                       transform=transforms.Compose(
                                           [transforms.ToTensor()]))
        test_dataset = datasets.MNIST(data_dir, train=False,download=True,
                                      transform=transforms.Compose([
                                          transforms.ToTensor(),
                                      ]))
    elif dataset == "fmnist":
        train_dataset = datasets.FashionMNIST(data_dir, train=True,download=True,
                                              transform=transforms.Compose(
                                                  [transforms.ToTensor()]))

        test_dataset = datasets.FashionMNIST(data_dir, train=False,
                                             transform=transforms.Compose([
                                                 transforms.ToTensor(),
                                             ]))
    elif dataset == "cifar10":
        cifar_mean = (0.4914, 0.4822, 0.4465)
        cifar_std = (0.2470, 0.2435, 0.2616)
        train_dataset = datasets.CIFAR10(data_dir, train=True, download=True,
                                         transform=transforms.Compose([
                                             transforms.RandomCrop(32, padding=4),
                                             transforms.RandomHorizontalFlip(),
                                             transforms.ToTensor(),
                                             transforms.Normalize(cifar_mean, cifar_std),
                                         ]))
        test_dataset = datasets.CIFAR10(data_dir, train=False, download=True,
                                        transform=transforms.Compose([
                                            transforms.ToTensor(),
                                            transforms.Normalize(cifar_mean, cifar_std),
                                        ]))
    elif dataset == "svhn":
        svhn_mean = (0.4377, 0.4438, 0.4728)
        svhn_std = (0.1980, 0.2010, 0.1970)
        train_dataset = datasets.SVHN(data_dir, split="train", download=True,
                                      transform=transforms.Compose([
                                          transforms.RandomCrop(32, padding=4),
                                          transforms.ToTensor(),
                                          transforms.Normalize(svhn_mean, svhn_std),
                                      ]))
        test_dataset = datasets.SVHN(data_dir, split="test", download=True,
                                     transform=transforms.Compose([
                                         transforms.ToTensor(),
                                         transforms.Normalize(svhn_mean, svhn_std),
                                     ]))
    elif dataset in ["webvision", "webvision20"]:
        webvision_root = data_dir
        if not os.path.isfile(os.path.join(webvision_root, "info", "train_filelist_all.txt")):
            webvision_root = os.path.join(data_dir, "webvision")
        mean = (0.485, 0.456, 0.406)
        std = (0.229, 0.224, 0.225)
        train_dataset = WebVision20(
            webvision_root,
            "train",
            transforms.Compose([
                transforms.RandomResizedCrop(64, scale=(0.6, 1.0)),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(mean, std),
            ]),
        )
        test_dataset = WebVision20(
            webvision_root,
            "val",
            transforms.Compose([
                transforms.Resize(72),
                transforms.CenterCrop(64),
                transforms.ToTensor(),
                transforms.Normalize(mean, std),
            ]),
        )
    elif dataset in ["miniimagenet", "miniimage", "mini"]:
        mini_root = os.path.join(data_dir, "miniimagenet")
        candidate_pairs = [
            (os.path.join(mini_root, "train"), os.path.join(mini_root, "test")),
            (os.path.join(mini_root, "train"), os.path.join(mini_root, "val")),
            (os.path.join(data_dir, "miniImageNet", "train"), os.path.join(data_dir, "miniImageNet", "test")),
            (os.path.join(data_dir, "miniImageNet", "train"), os.path.join(data_dir, "miniImageNet", "val")),
        ]
        train_root, test_root = None, None
        for cand_train, cand_test in candidate_pairs:
            if os.path.isdir(cand_train) and os.path.isdir(cand_test):
                train_root, test_root = cand_train, cand_test
                break
        if train_root is None:
            raise FileNotFoundError(
                "miniImageNet expects ImageFolder data under "
                "./dataset/miniimagenet/{train,test|val} or ./dataset/miniImageNet/{train,test|val}."
            )
        train_dataset = datasets.ImageFolder(
            train_root,
            transforms.Compose([
                transforms.RandomResizedCrop(84, scale=(0.6, 1.0)),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
            ])
        )
        test_dataset = datasets.ImageFolder(
            test_root,
            transforms.Compose([
                transforms.Resize(92),
                transforms.CenterCrop(84),
                transforms.ToTensor(),
            ])
        )
    elif dataset == "tiny":
        data_transforms = {
            # 训练集用
            'train': transforms.Compose([
                # 把图片随机旋转 ±20 度，让模型从不同角度看图片，更不容易死记硬背，泛化能力更强
                transforms.RandomRotation(20),
                # 把图片随机水平翻转，50% 的概率，这样模型就能学会识别左右翻转的图片
                transforms.RandomHorizontalFlip(0.5),
                # 转换为张量
                transforms.ToTensor(),
            ]),
            # 验证集用
            'val': transforms.Compose([
                # 转换为张量
                transforms.ToTensor(),
            ]),
            # 测试集用
            'test': transforms.Compose([
                # 测试集数据转换为张量
                transforms.ToTensor(),
            ])
        }
        # 1. 定义数据集的**根文件夹路径**
        data_dir = os.path.join(data_dir, "tiny-imagenet-200")
        # 2. 核心：一次性加载 训练集/验证集/测试集（字典推导式）
        # datasets.ImageFolder(路径, 预处理) 会自动根据路径下的子文件夹名称来识别类别标签，并且把图片和标签打包成一个数据集对象
        image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x), data_transforms[x])
                          for x in ['train', 'val', 'test']}
        # 3. 把训练集和验证集单独取出来，方便后面用
        train_dataset = image_datasets['train']
        test_dataset = image_datasets['val']
    else:
        raise NotImplementedError

    import numpy as np
    
    # 判断数据是不是 PyTorch 张量（Tensor），如果是的话就调用 .numpy() 方法转换成 NumPy 数组；如果不是（可能已经是 NumPy 数组了），就直接用 np.array() 包装一下确保它是 NumPy 数组
    # train_dataset.data：所有训练图片（PyTorch 张量）
    # .numpy()：把张量 → 转成 NumPy 数组
    # train_dataset.targets：图片对应的标签（0-9 这类数字）
    if hasattr(train_dataset, "labels"):
        X_train = np.arange(len(train_dataset))
        y_train = np.array(train_dataset.labels)
        X_test = np.arange(len(test_dataset))
        y_test = np.array(test_dataset.labels)
    elif hasattr(train_dataset, "samples"):
        X_train = np.arange(len(train_dataset))
        y_train = np.array([sample[1] for sample in train_dataset.samples])
        X_test = np.arange(len(test_dataset))
        y_test = np.array([sample[1] for sample in test_dataset.samples])
    elif hasattr(train_dataset.data, 'numpy'):
        X_train = train_dataset.data.numpy()
        y_train = train_dataset.targets.numpy()
        X_test = test_dataset.data.numpy()
        y_test = test_dataset.targets.numpy()
    else:
        X_train = np.array(train_dataset.data)
        y_train = np.array(train_dataset.targets)
        X_test = np.array(test_dataset.data)
        y_test = np.array(test_dataset.targets)

    # X_train：训练图片（numpy 数组）y_train：训练标签 
    # X_test：测试图片 y_test：测试标签 
    # train_dataset：原始训练数据集 test_dataset：原始测试数据集
    return X_train, y_train, X_test, y_test, train_dataset, test_dataset




# y_train：所有训练数据的标签
# net_dataidx_map：客户端 —— 数据索引 的对应字典
def record_net_data_stats(y_train, net_dataidx_map):
    # 用来存：每个客户端 → 每个类别有多少张图
    # 最终格式：{客户端0: {类别0:5张, 类别1:3张...}, 客户端1: {...}}
    net_cls_counts = {}

    # net_i：客户端编号（0、1、2、3...）
    # dataidx：这个客户端拥有的所有数据索引列表
    # 作用：一个一个客户端统计
    for net_i, dataidx in net_dataidx_map.items():
        # y_train[dataidx] 
        # 根据索引，拿出这个客户端的所有标签 
        # 比如得到：[0, 0, 1, 2, 2, 2] 
        # np.unique(..., return_counts=True) 
        # 统计标签里不重复的类别 + 每个类别多少个 
        # 上面例子会返回：
        # unq = [0, 1, 2] （不重复的类别）
        # unq_cnt = [2, 1, 3] （对应数量）
        unq, unq_cnt = np.unique(y_train[dataidx], return_counts=True)
        # 把上面的数组 → 转成好看的字典
        # 例子：{0:2, 1:1, 2:3}
        tmp = {unq[i]: unq_cnt[i] for i in range(len(unq))}
        # 把这个客户端的统计结果存进总字典
        # 存完后总字典大概长这样：
        # {
        #  0: {0:2, 1:1, 2:3},
        #  1: {1:5, 3:2},
        #  2: {0:4, 2:1}
        # }
        net_cls_counts[net_i] = tmp

    print('Data statistics: %s' % str(net_cls_counts))

    return net_cls_counts


def load_distil_dataset(dataset, data_root=""):
    X_train, y_train, X_test, y_test, train_dataset, test_dataset = load_data(
        dataset,
        data_root=data_root,
    )
    # 因为别的代码只想要 train_dataset，不想要其他 5 个东西！
    return train_dataset


def partition_two_class_data(y_train, num_users, classes_per_user=2):
    labels = np.unique(y_train)
    num_classes = labels.shape[0]
    if num_classes == 0:
        raise ValueError("Cannot build a two-class partition with zero classes.")
    if classes_per_user <= 0:
        raise ValueError("classes_per_user must be positive.")

    slot_count = num_users * classes_per_user
    repeats = int(np.ceil(slot_count / num_classes))
    class_slots = np.tile(labels, repeats)[:slot_count]
    assignments = class_slots.reshape(num_users, classes_per_user)

    net_dataidx_map = {i: [] for i in range(num_users)}
    class_to_users = {int(class_id): [] for class_id in labels.tolist()}
    for user_id in range(num_users):
        for class_id in assignments[user_id]:
            class_to_users[int(class_id)].append(user_id)

    for class_id in labels.tolist():
        class_indices = np.where(y_train == class_id)[0]
        np.random.shuffle(class_indices)
        owners = class_to_users[int(class_id)]
        if not owners:
            continue
        shards = np.array_split(class_indices, len(owners))
        for owner, shard in zip(owners, shards):
            net_dataidx_map[owner].extend(shard.tolist())

    for user_id in range(num_users):
        user_indices = np.asarray(net_dataidx_map[user_id], dtype=np.int64)
        np.random.shuffle(user_indices)
        net_dataidx_map[user_id] = user_indices

    return net_dataidx_map


def build_split_metadata(dataset, partition, num_users, seed, y_train, net_dataidx_map):
    y_train = np.asarray(y_train, dtype=np.int64)
    normalized_groups = {}
    client_classes = {}
    for user_id, indices in net_dataidx_map.items():
        user_key = int(user_id)
        user_indices = np.asarray(indices, dtype=np.int64)
        normalized_groups[user_key] = user_indices
        client_classes[user_key] = sorted(
            int(label) for label in np.unique(y_train[user_indices]).tolist()
        )

    return {
        "version": 1,
        "dataset": str(dataset),
        "partition": str(partition),
        "num_users": int(num_users),
        "seed": None if seed is None else int(seed),
        "train_size": int(y_train.shape[0]),
        "num_classes": int(np.unique(y_train).shape[0]),
        "train_label_digest": hashlib.sha1(y_train.tobytes()).hexdigest(),
        "client_classes": client_classes,
        "user_groups": {
            int(user_id): indices.tolist()
            for user_id, indices in normalized_groups.items()
        },
        "index_space": "train_dataset_order",
    }


def save_split_file(path, metadata):
    if not path:
        return
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    torch.save(metadata, path)


def load_split_file(path, dataset, num_users, y_train, expected_seed=None,
                    expected_partition=None, train_path_digest=None):
    payload = torch.load(path, map_location="cpu")
    if "user_groups" not in payload:
        raise ValueError(f"Split file '{path}' does not contain 'user_groups'.")

    y_train = np.asarray(y_train, dtype=np.int64)
    file_dataset = payload.get("dataset")
    normalized_dataset = (
        "webvision20" if dataset in ["webvision", "webvision20"] else dataset
    )
    normalized_file_dataset = (
        "webvision20"
        if file_dataset in ["webvision", "webvision20"]
        else file_dataset
    )
    if normalized_file_dataset not in [None, normalized_dataset]:
        raise ValueError(
            f"Split file dataset mismatch: file={file_dataset} current={dataset}"
        )
    if int(payload.get("num_users", num_users)) != int(num_users):
        raise ValueError(
            f"Split file num_users mismatch: file={payload.get('num_users')} current={num_users}"
        )
    if int(payload.get("train_size", y_train.shape[0])) != int(y_train.shape[0]):
        raise ValueError(
            f"Split file train_size mismatch: file={payload.get('train_size')} current={y_train.shape[0]}"
        )
    if expected_seed is not None and payload.get("seed") is not None:
        if int(payload["seed"]) != int(expected_seed):
            raise ValueError(
                f"Split file seed mismatch: file={payload['seed']} current={expected_seed}"
            )
    if expected_partition and payload.get("partition") is not None:
        file_partition = str(payload["partition"]).lower().replace("-", "_")
        requested_partition = str(expected_partition).lower().replace("-", "_")
        if file_partition != requested_partition:
            raise ValueError(
                "Split file partition mismatch: "
                f"file={payload['partition']} current={expected_partition}"
            )
    expected_digest = hashlib.sha1(y_train.tobytes()).hexdigest()
    file_digest = payload.get("train_label_digest")
    if file_digest not in [None, expected_digest]:
        raise ValueError(
            "Split file train_label_digest mismatch. The underlying training-set order "
            "does not appear to match this repository's dataset ordering."
        )
    file_path_digest = payload.get("train_path_digest")
    if (
        train_path_digest is not None
        and file_path_digest not in [None, train_path_digest]
    ):
        raise ValueError(
            "Split file train_path_digest mismatch. The underlying training-set "
            "path order does not match the saved split."
        )

    raw_groups = payload["user_groups"]
    net_dataidx_map = {}
    seen = set()
    for user_id in range(num_users):
        if user_id in raw_groups:
            indices = raw_groups[user_id]
        elif str(user_id) in raw_groups:
            indices = raw_groups[str(user_id)]
        else:
            raise ValueError(f"Split file is missing user_groups[{user_id}].")
        user_indices = np.asarray(indices, dtype=np.int64)
        if user_indices.ndim != 1:
            raise ValueError(f"user_groups[{user_id}] must be a 1D index list.")
        if user_indices.size == 0:
            raise ValueError(f"user_groups[{user_id}] is empty.")
        if user_indices.min() < 0 or user_indices.max() >= y_train.shape[0]:
            raise ValueError(
                f"user_groups[{user_id}] contains indices outside [0, {y_train.shape[0]})"
            )
        overlap = seen.intersection(user_indices.tolist())
        if overlap:
            raise ValueError(
                f"Split file has overlapping client indices; first overlap example: {next(iter(overlap))}"
            )
        seen.update(user_indices.tolist())
        net_dataidx_map[user_id] = user_indices

    expected_indices = set(range(y_train.shape[0]))
    if seen != expected_indices:
        missing = expected_indices.difference(seen)
        extra = seen.difference(expected_indices)
        raise ValueError(
            "Split file must cover the complete training set exactly once; "
            f"missing={len(missing)} extra={len(extra)}."
        )

    train_data_cls_counts = record_net_data_stats(y_train, net_dataidx_map)
    return net_dataidx_map, train_data_cls_counts, payload

def partition_data(
    dataset,
    partition,
    beta=0.4,
    num_users=5,
    split_file="",
    save_split_path="",
    seed=None,
    data_root="",
):
    """
    联邦学习核心数据划分模块
    :param dataset: 字符串名称，要使用的数据集（如 'cifar10', 'mnist'），决定了基础数据是什么
    :param partition: 划分方式字符串，'iid' 代表独立同分布的均匀划分，'dirichlet' 代表狄利克雷分布（非独立同分布 Non-IID 平分数据的极端性）
    :param beta: 狄利克雷分布参数，alpha/beta 越小，Non-IID 程度越高（数据倾斜越严重）；越大越接近 IID
        beta 越大（比如 100）→ 分的越均匀
        beta 越小（比如 0.1）→ 分的越不均匀（有的多有的少）
    :param num_users: 客户端节点的总数量（即总共有多少个参与方）
    :return: 
    """
    original_partition = partition or ""
    partition = (partition or "").strip().lower()
    partition_aliases = {
        "2c": "two_class",
        "2class": "two_class",
        "two_class": "two_class",
        "two-class": "two_class",
        "two_class_per_client": "two_class",
    }
    partition = partition_aliases.get(partition, partition)

    n_parties = num_users
    # 加载数据集中的原始数据和标签
    X_train, y_train, X_test, y_test, train_dataset, test_dataset = load_data(
        dataset,
        data_root=data_root,
    )
    data_size = y_train.shape[0] # 获取训练集的数据总量

    net_dataidx_map = {} # 用于存储每个客户端（net）拥有哪些数据索引的字典
    
    if split_file:
        train_path_digest = getattr(train_dataset, "path_sha1", None)
        net_dataidx_map, train_data_cls_counts, split_metadata = load_split_file(
            split_file,
            dataset=dataset,
            num_users=n_parties,
            y_train=y_train,
            expected_seed=seed,
            expected_partition=partition,
            train_path_digest=train_path_digest,
        )
        return train_dataset, test_dataset, net_dataidx_map, train_data_cls_counts, split_metadata

    if partition == "iid":
        # ========== IID（独立同分布）数据划分逻辑 ==========
        # 将所有数据的索引打乱，然后均匀平分给每个客户端，每个客户端不仅数据量一样，标签分布也趋向一致
        idxs = np.random.permutation(data_size) 
        batch_idxs = np.array_split(idxs, n_parties) # 平均分割这些索引
        net_dataidx_map = {i: batch_idxs[i] for i in range(n_parties)} # 给编号 0~n_parties-1 的客户端分配打乱后的对应的切片索引

    elif partition == "dirichlet":
        # ========== Dirichlet（非独立同分布）数据划分逻辑 ==========
        # 每个客户端拥有的类别比例是倾斜的。例如：客户端1可能多部分是猫，少部分是狗；客户端2可能是相反。
        min_size = 0 # 追踪所有客户端中最少的数据量，用来防止某些客户端一个样本都分不到
        min_require_size = 10 # 强制要求每个客户端至少要有 10 个样本，避免出现有客户端没样本而报错的情况
        label = np.unique(y_test).shape[0] # 找到有多少种类别标签（例如 CIFAR-10 结果是 10）
        net_dataidx_map = {}

        while min_size < min_require_size:
            idx_batch = [[] for _ in range(n_parties)] # 创建每个参与方的数据索引列表
            for k in range(label): # 针对每一个类别标签（0，1，..., 9）单独划分
                idx_k = np.where(y_train == k)[0] # 找出当前类别 k 的所有数据索引
                np.random.shuffle(idx_k)  # 将含有类别 k 的所有数据索引随机打乱
                
                # 基于 Beta 参数生成 dirichlet 分布，该分布对应 n_parties 个比例值
                # random 结果类似: [0.5963643 , 0.03712018, 0.04907753, 0.1115522 , 0.2058858 ]（和为 1）
                proportions = np.random.dirichlet(np.repeat(beta, n_parties))
                
                # 过滤操作：如果某个客户端的数据持有量已经超标了 (当前已有数据量 >= 总数/客户端总数)，则不允许再分配，即给该配比乘 0 强行清零
                proportions = np.array(  
                    [p * (len(idx_j) < data_size / n_parties) for p, idx_j in zip(proportions, idx_batch)])
                
                # 重新归一化这些比例值，使它们加起来还是 1
                proportions = proportions / proportions.sum()
                
                # 根据得到的比例，计算这批类别 k 的数据应当如何切割，比如从第几个切到第几个
                proportions = (np.cumsum(proportions) * len(idx_k)).astype(int)[:-1]
                
                # 按照上面计算出的切割点(proportions)，将对应类别的数据索引 idx_k 切片，并且加入给对应的 idx_batch
                idx_batch = [idx_j + idx.tolist() for idx_j, idx in zip(idx_batch, np.split(idx_k, proportions))]
                
                min_size = min([len(idx_j) for idx_j in idx_batch]) # 更新客户端中最少的数据量

        # 数据划分完毕，为每个客户端再次打乱由于按类别划分导致的有序结果
        for j in range(n_parties):
            np.random.shuffle(idx_batch[j])
            net_dataidx_map[j] = idx_batch[j]
    elif partition == "two_class":
        net_dataidx_map = partition_two_class_data(
            y_train=y_train,
            num_users=n_parties,
            classes_per_user=2,
        )
    else:
        raise NotImplementedError

    # 打印最终统计各客户端拥有的各个标签分布数量结果
    train_data_cls_counts = record_net_data_stats(y_train, net_dataidx_map)
    split_metadata = build_split_metadata(
        dataset=dataset,
        partition=partition if partition else original_partition,
        num_users=n_parties,
        seed=seed,
        y_train=y_train,
        net_dataidx_map=net_dataidx_map,
    )
    train_path_digest = getattr(train_dataset, "path_sha1", None)
    if train_path_digest is not None:
        split_metadata["train_path_digest"] = train_path_digest
    save_split_file(save_split_path, split_metadata)
    return train_dataset, test_dataset, net_dataidx_map, train_data_cls_counts, split_metadata
    # train_dataset→ 完整的训练数据集（图片、数据本身）
    # test_dataset→ 完整的测试数据集（用来最后打分）
    # net_dataidx_map→ 每个客户端有哪些数据的编号（你前面辛苦分配的结果！）
    # train_data_cls_counts→ 每个客户端各类标签有多少条（刚刚统计好的表）

