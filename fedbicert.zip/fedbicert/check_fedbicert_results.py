import argparse
import os
import sys

import torch


def load_checkpoint(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--timestr", required=True)
    parser.add_argument("--server-target", type=float, default=50.0)
    parser.add_argument("--client-target", type=float, default=50.0)
    parser.add_argument("--strict", type=int, default=1)
    args = parser.parse_args()

    path = os.path.join(
        "df_ckpt",
        f"{args.timestr}-fedbicert-report.pth",
    )
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    report = load_checkpoint(path)
    failures = []

    if report.get("parameter_copying_used", True):
        failures.append("parameter copying was used")
    if report.get("test_set_used_for_selection", True):
        failures.append("the test set was used for model selection")
    communication = report.get("communication", {})
    if communication.get("return_uplink", True):
        failures.append("a second client-to-server upload was used")

    server_before = float(report["server_before"])
    server_after = float(report["server_after"])
    if server_after <= server_before:
        failures.append("server did not improve")
    if server_after <= args.server_target:
        failures.append(
            f"server accuracy {server_after:.4f} <= "
            f"{args.server_target:.4f}"
        )

    for index, (before, after) in enumerate(
        zip(report["client_before"], report["client_after"])
    ):
        if float(after) <= float(before):
            failures.append(
                f"client {index} did not improve "
                f"({before:.4f}->{after:.4f})"
            )
        if float(after) <= args.client_target:
            failures.append(
                f"client {index} accuracy {after:.4f} <= "
                f"{args.client_target:.4f}"
            )

    print("FedBiCert result audit")
    print(
        f"server: {server_before:.4f} -> {server_after:.4f} "
        f"({server_after - server_before:+.4f})"
    )
    for index, (before, after, accepted) in enumerate(
        zip(
            report["client_before"],
            report["client_after"],
            report["client_accepted"],
        )
    ):
        proxy_before = report.get("client_proxy_before", [{}])[index].get(
            "acc",
            0.0,
        ) if index < len(report.get("client_proxy_before", [])) else 0.0
        proxy_after = report.get("client_proxy_after", [{}])[index].get(
            "acc",
            0.0,
        ) if index < len(report.get("client_proxy_after", [])) else 0.0
        print(
            f"client {index}: {before:.4f} -> {after:.4f} "
            f"({after - before:+.4f}), proxy={proxy_before:.2f}->"
            f"{proxy_after:.2f}, accepted={accepted}"
        )
    print(f"protocol failures: {len(failures)}")
    for failure in failures:
        print(f"  - {failure}")

    if failures and args.strict:
        sys.exit(1)


if __name__ == "__main__":
    main()
