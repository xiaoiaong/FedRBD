import torch
import torch.nn as nn


class ResidualGeneratorBlock(nn.Module):
    def __init__(self, channels):
        super(ResidualGeneratorBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
        )

    def forward(self, inputs):
        return torch.nn.functional.leaky_relu(
            inputs + self.block(inputs),
            negative_slope=0.2,
        )


class DualModeQueryGenerator(nn.Module):
    """Conditional generator for coverage and conflict queries."""

    COVERAGE = 0
    CONFLICT = 1

    def __init__(
        self,
        noise_dim,
        num_classes,
        image_size,
        channels,
        width=64,
    ):
        super(DualModeQueryGenerator, self).__init__()
        self.noise_dim = noise_dim
        self.num_classes = num_classes
        self.image_size = image_size
        self.channels = channels
        self.initial_size = image_size // 4
        self.label_embedding = nn.Embedding(num_classes, noise_dim)
        self.mode_embedding = nn.Embedding(2, noise_dim // 2)
        input_dim = noise_dim * 2 + noise_dim // 2
        self.project = nn.Sequential(
            nn.Linear(
                input_dim,
                width * 4 * self.initial_size * self.initial_size,
            ),
            nn.BatchNorm1d(width * 4 * self.initial_size * self.initial_size),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.decoder = nn.Sequential(
            nn.BatchNorm2d(width * 4),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(width * 4, width * 4, 3, padding=1, bias=False),
            nn.BatchNorm2d(width * 4),
            nn.LeakyReLU(0.2, inplace=True),
            ResidualGeneratorBlock(width * 4),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(width * 4, width * 2, 3, padding=1, bias=False),
            nn.BatchNorm2d(width * 2),
            nn.LeakyReLU(0.2, inplace=True),
            ResidualGeneratorBlock(width * 2),
            nn.Conv2d(width * 2, width, 3, padding=1, bias=False),
            nn.BatchNorm2d(width),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(width, channels, 3, padding=1),
            nn.Sigmoid(),
        )

    def forward(self, noise, labels, modes):
        label_code = self.label_embedding(labels)
        mode_code = self.mode_embedding(modes)
        hidden = torch.cat([noise, label_code, mode_code], dim=1)
        hidden = self.project(hidden)
        hidden = hidden.view(
            hidden.size(0),
            -1,
            self.initial_size,
            self.initial_size,
        )
        return self.decoder(hidden)
