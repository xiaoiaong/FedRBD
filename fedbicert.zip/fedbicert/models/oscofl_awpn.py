import torch
import torch.nn as nn
import torch.nn.functional as F


class AWPN(nn.Module):
    """
    Adaptive Weight Prediction Network.
    输入: client_embeddings [K, input_dim]
    输出: device_weights [K]
    """
    def __init__(self, input_dim=15, hidden_dim=64):
        super(AWPN, self).__init__()

        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),

            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.LayerNorm(hidden_dim // 2),
            nn.ReLU(inplace=True),

            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, client_embeddings, temperature=2.0):
        scores = self.net(client_embeddings).squeeze(-1)
        weights = F.softmax(scores / temperature, dim=0)
        return weights