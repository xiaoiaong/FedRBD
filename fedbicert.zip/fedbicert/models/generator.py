import torch
import torch.nn as nn
import torch.nn.functional as F


class Generator(nn.Module):
    """
    数据生成器 (Generator)：在无数据联邦学习(Data-Free FL)中扮演至关重要的角色。
    它的作用是从纯随机噪声 z 中“凭空捏造”出图像，随后配合 Synthesizer 不断优化，
    使这些假图像越来越像当初训练客户端时的真实图像（让假图像刺激教师模型产生高置信度）。
    结构为一个典型的反卷积生成对抗网络（类似 DCGAN）。
    """
    def __init__(self, nz=100, ngf=64, img_size=32, nc=3):
        super(Generator, self).__init__()

        self.init_size = img_size // 4 # 图片初始生成大小，如 32/4 = 8
        self.l1 = nn.Sequential(nn.Linear(nz, ngf * 2 * self.init_size ** 2))

        # 核心卷积块：通过反卷积（使用Upsample+Conv实现）逐步放大特征图，最终生成对应的通道数(nc)和尺寸
        self.conv_blocks = nn.Sequential(
            nn.BatchNorm2d(ngf * 2),
            nn.Upsample(scale_factor=2), # 长宽放大两倍 (8 -> 16)

            nn.Conv2d(ngf * 2, ngf * 2, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(ngf * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Upsample(scale_factor=2), # 再次放大 (16 -> 32)

            nn.Conv2d(ngf * 2, ngf, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(ngf),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ngf, nc, 3, stride=1, padding=1),
            nn.Sigmoid(), # 输出归一化，变成常见的图像像素分布
        )

    def forward(self, z):
        out = self.l1(z)
        out = out.view(out.shape[0], -1, self.init_size, self.init_size)
        img = self.conv_blocks(out)
        return img
