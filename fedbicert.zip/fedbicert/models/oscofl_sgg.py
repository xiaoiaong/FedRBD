import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualConvBlock(nn.Module):
    def __init__(self, channels):
        super(ResidualConvBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(channels),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(channels),
        )

    def forward(self, x):
        return F.leaky_relu(x + self.block(x), negative_slope=0.2, inplace=True)


class SemanticGuidedGenerator(nn.Module):
    """
    OS-CoFL 第 5 阶段：语义引导生成器 SGG

    输入:
        z:              [B, nz]
        labels:         [B]
        class_centers:  [B, feature_dim]

    输出:
        fake_images:    [B, nc, img_size, img_size]
    """

    def __init__(
        self,
        nz=100,
        num_classes=10,
        feature_dim=1568,
        img_size=28,
        nc=1,
        ngf=64,
        semantic_dim=100
    ):
        super(SemanticGuidedGenerator, self).__init__()

        self.nz = nz
        self.num_classes = num_classes
        self.feature_dim = feature_dim
        self.img_size = img_size
        self.nc = nc

        self.label_emb = nn.Embedding(num_classes, nz)

        self.semantic_proj = nn.Sequential(
            nn.Linear(feature_dim, semantic_dim),
            nn.LayerNorm(semantic_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(semantic_dim, nz),
            nn.Tanh()
        )

        self.init_size = img_size // 4

        input_dim = nz + nz + nz

        self.l1 = nn.Sequential(
            nn.Linear(input_dim, ngf * 4 * self.init_size * self.init_size),
            nn.BatchNorm1d(ngf * 4 * self.init_size * self.init_size),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.conv_blocks = nn.Sequential(
            nn.BatchNorm2d(ngf * 4),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(ngf * 4, ngf * 4, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(ngf * 4),
            nn.LeakyReLU(0.2, inplace=True),
            ResidualConvBlock(ngf * 4),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(ngf * 4, ngf * 2, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(ngf * 2),
            nn.LeakyReLU(0.2, inplace=True),
            ResidualConvBlock(ngf * 2),
            nn.Conv2d(ngf * 2, ngf, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(ngf),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ngf, nc, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()
        )

    def forward(self, z, labels, class_centers):
        label_code = self.label_emb(labels)

        # 关键：语义中心先归一化，避免数值尺度过大
        class_centers = F.normalize(class_centers, dim=1)
        semantic_code = self.semantic_proj(class_centers)

        h = torch.cat([z, label_code, semantic_code], dim=1)

        out = self.l1(h)
        out = out.view(out.size(0), -1, self.init_size, self.init_size)

        fake_images = self.conv_blocks(out)
        return fake_images
