import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def normalized_entropy(probabilities):
    classes = probabilities.size(1)
    entropy = -(
        probabilities.clamp_min(1e-8)
        * probabilities.clamp_min(1e-8).log()
    ).sum(dim=1)
    return entropy / math.log(max(classes, 2))


def jensen_shannon_divergence(client_probabilities):
    mixture = client_probabilities.mean(dim=1).clamp_min(1e-8)
    log_mixture = mixture.log().unsqueeze(1)
    client_log = client_probabilities.clamp_min(1e-8).log()
    return (
        client_probabilities
        * (client_log - log_mixture)
    ).sum(dim=2).mean(dim=1)


class CertifiedExpertRouter(nn.Module):
    """Route every query in each client's private feature coordinate system."""

    def __init__(
        self,
        models,
        certificates,
        routing_mode="certified",
        num_classes=None,
        support_temperature=1.0,
        margin_temperature=2.0,
        routing_temperature=0.35,
        minimum_evidence=1e-4,
        ownership_power=1.5,
        minimum_class_count=10,
        support_floor=0.25,
        reliability_floor=0.05,
        query_floor=0.02,
        inference_chunk_size=0,
    ):
        super(CertifiedExpertRouter, self).__init__()
        routing_mode = str(routing_mode).lower()
        if routing_mode not in {
            "certified", "uniform", "confidence",
            "class_only", "class_feature", "class_margin",
        }:
            raise ValueError(
                "routing_mode must be certified, uniform, confidence, "
                "class_only, class_feature, or class_margin"
            )
        certificate_routing = routing_mode in {
            "certified", "class_only", "class_feature", "class_margin"
        }
        if certificate_routing and (certificates is None or len(models) != len(certificates)):
            raise ValueError("Each client model requires one risk certificate.")
        if not certificate_routing and certificates is None:
            certificates = []
        if certificates and len(models) != len(certificates):
            raise ValueError("Each client model requires one risk certificate.")
        self.models = nn.ModuleList(models)
        self.certificates = certificates
        self.routing_mode = routing_mode
        self.support_temperature = support_temperature
        self.margin_temperature = margin_temperature
        self.routing_temperature = routing_temperature
        self.minimum_evidence = minimum_evidence
        self.support_floor = support_floor
        self.reliability_floor = reliability_floor
        self.query_floor = query_floor
        self.inference_chunk_size = max(int(inference_chunk_size), 0)

        if not certificate_routing:
            if certificates:
                num_classes = int(certificates[0]["class_counts"].numel())
            elif num_classes is None:
                # All supported classifiers expose their output width through
                # the final state tensor, but a parameter-free probe would be
                # architecture-specific. Infer it from the last 1-D parameter.
                output_biases = [
                    parameter for parameter in models[0].parameters()
                    if parameter.ndim == 1
                ]
                if not output_biases:
                    raise ValueError("Cannot infer the model output dimension.")
                num_classes = int(output_biases[-1].numel())
            class_prior = torch.full(
                (len(models), num_classes),
                1.0 / max(len(models), 1),
            )
            self.register_buffer("class_prior", class_prior)
            counts = reliability = class_nll = None
        else:
            counts = torch.stack(
                [certificate["class_counts"].float() for certificate in certificates],
                dim=0,
            )
            reliability = torch.stack(
                [certificate["reliability"].float() for certificate in certificates],
                dim=0,
            )
            class_nll = torch.stack(
                [certificate["class_nll"].float() for certificate in certificates],
                dim=0,
            )
        if certificate_routing:
            class_totals = counts.sum(dim=0, keepdim=True).clamp_min(1.0)
            ownership = counts / class_totals
            eligible = counts.ge(float(minimum_class_count))
            # Always retain the largest owner so very rare classes remain routable.
            largest_owner = counts.argmax(dim=0, keepdim=True)
            eligible.scatter_(0, largest_owner, True)
            calibration = torch.exp(
                -class_nll / math.log(max(counts.size(1), 2))
            )
            class_prior = (
                ownership.clamp_min(1e-8).pow(ownership_power)
                * reliability.clamp_min(self.reliability_floor)
                * calibration.clamp_min(0.05)
                * eligible.to(counts.dtype)
            )
            class_prior = class_prior / class_prior.sum(
                dim=0,
                keepdim=True,
            ).clamp_min(1e-8)
            self.register_buffer("class_prior", class_prior)

        for model in self.models:
            model.eval()
            for parameter in model.parameters():
                parameter.requires_grad_(False)

    def train(self, mode=True):
        super(CertifiedExpertRouter, self).train(False)
        for model in self.models:
            model.eval()
        return self

    def _certificate_tensor(self, client_index, key, device, dtype=None):
        tensor = self.certificates[client_index][key].to(device)
        if dtype is not None:
            tensor = tensor.to(dtype=dtype)
        return tensor

    def _forward_impl(self, images, labels=None):
        client_probs = []
        client_support = []
        client_evidence = []
        client_margins = []

        for client_index, model in enumerate(self.models):
            logits, features = model(images, return_feature=True)
            features = F.normalize(features.float(), dim=1)
            if self.certificates:
                temperature = self._certificate_tensor(
                    client_index,
                    "temperature",
                    images.device,
                    logits.dtype,
                ).clamp(0.5, 5.0)
            else:
                temperature = torch.ones((), device=images.device, dtype=logits.dtype)
            calibrated_logits = logits / temperature
            probabilities = F.softmax(calibrated_logits, dim=1)

            if labels is None:
                class_ids = probabilities.argmax(dim=1)
            else:
                class_ids = labels.long()

            if self.routing_mode in {"uniform", "confidence"}:
                certainty = (
                    1.0 - normalized_entropy(probabilities)
                ).clamp_min(self.query_floor)
                client_probs.append(probabilities)
                client_support.append(torch.ones_like(certainty))
                client_evidence.append(certainty)
                client_margins.append(torch.zeros_like(certainty))
                continue

            feature_mean = self._certificate_tensor(
                client_index,
                "feature_mean",
                images.device,
                features.dtype,
            )[class_ids]
            feature_var = self._certificate_tensor(
                client_index,
                "feature_var",
                images.device,
                features.dtype,
            )[class_ids]
            counts = self._certificate_tensor(
                client_index,
                "class_counts",
                images.device,
                features.dtype,
            )[class_ids]
            reliability = self._certificate_tensor(
                client_index,
                "reliability",
                images.device,
                features.dtype,
            )[class_ids]
            class_nll = self._certificate_tensor(
                client_index,
                "class_nll",
                images.device,
                features.dtype,
            )[class_ids]
            class_confidence = self._certificate_tensor(
                client_index,
                "class_confidence",
                images.device,
                features.dtype,
            )[class_ids]
            reference_margin = self._certificate_tensor(
                client_index,
                "margin_mean",
                images.device,
                logits.dtype,
            )[class_ids]
            reference_margin_std = self._certificate_tensor(
                client_index,
                "margin_std",
                images.device,
                logits.dtype,
            )[class_ids].clamp_min(0.25)

            mahalanobis = (
                (features - feature_mean).square()
                / feature_var.clamp_min(1e-4)
            ).mean(dim=1)
            support = torch.rsqrt(
                1.0
                + mahalanobis
                / max(self.support_temperature, 1e-4)
            )
            support = support * counts.gt(0).to(support.dtype)

            target_logits = calibrated_logits.gather(
                1,
                class_ids[:, None],
            ).squeeze(1)
            other_logits = calibrated_logits.clone()
            other_logits.scatter_(1, class_ids[:, None], -float("inf"))
            margins = target_logits - other_logits.max(dim=1).values
            margin_compatibility = torch.exp(
                -(
                    (margins - reference_margin).abs()
                    / (
                        max(self.margin_temperature, 1e-4)
                        * reference_margin_std
                    )
                ).clamp(max=20.0)
            )
            certainty = (
                1.0 - normalized_entropy(probabilities)
            ).clamp_min(self.query_floor)
            calibration = torch.exp(
                -(class_confidence - reliability).abs()
                - class_nll / math.log(max(probabilities.size(1), 2))
            ).clamp_min(0.02)
            class_evidence = (
                reliability.clamp_min(self.reliability_floor)
                * calibration * certainty
            )
            feature_match = support * (
                self.support_floor + (1.0 - self.support_floor) * support
            )
            if self.routing_mode == "class_only":
                evidence = class_evidence
            elif self.routing_mode == "class_feature":
                evidence = class_evidence * feature_match
            elif self.routing_mode == "class_margin":
                evidence = class_evidence * margin_compatibility
            else:
                # Keep the original multiplication order for the full method.
                evidence = (
                    support * reliability.clamp_min(self.reliability_floor)
                    * calibration * certainty * margin_compatibility
                )

            client_probs.append(probabilities)
            client_support.append(support)
            client_evidence.append(evidence)
            client_margins.append(margins)

        probabilities = torch.stack(client_probs, dim=1)
        supports = torch.stack(client_support, dim=1)
        evidence = torch.stack(client_evidence, dim=1)
        margins = torch.stack(client_margins, dim=1)
        class_prior = self.class_prior[:, class_ids].transpose(0, 1)
        if self.routing_mode == "uniform":
            weights = torch.full_like(evidence, 1.0 / evidence.size(1))
            fallback = torch.zeros(images.size(0), dtype=torch.bool, device=images.device)
            top_evidence = evidence.mean(dim=1)
        elif self.routing_mode == "confidence":
            fallback = evidence.sum(dim=1).le(self.minimum_evidence)
            routing_logits = torch.log(evidence.clamp_min(self.minimum_evidence))
            weights = F.softmax(
                routing_logits / max(self.routing_temperature, 1e-4),
                dim=1,
            )
            if fallback.any():
                weights = torch.where(
                    fallback[:, None],
                    torch.full_like(weights, 1.0 / weights.size(1)),
                    weights,
                )
            top_evidence = evidence.topk(min(2, evidence.size(1)), dim=1).values.mean(dim=1)
        else:
            if self.routing_mode == "certified":
                evidence = (
                    evidence * class_prior
                    * (self.support_floor + (1.0 - self.support_floor) * supports)
                )
            else:
                evidence = evidence * class_prior
            fallback = evidence.sum(dim=1).le(self.minimum_evidence)
            routing_logits = torch.log(evidence.clamp_min(self.minimum_evidence))
            weights = F.softmax(
                routing_logits / max(self.routing_temperature, 1e-4),
                dim=1,
            )
            if fallback.any():
                fallback_weights = class_prior + self.minimum_evidence
                fallback_weights = fallback_weights / fallback_weights.sum(
                    dim=1,
                    keepdim=True,
                )
                weights = torch.where(
                    fallback[:, None],
                    fallback_weights,
                    weights,
                )
            top_evidence = evidence.topk(min(2, evidence.size(1)), dim=1).values.mean(dim=1)

        teacher_probabilities = (
            weights.unsqueeze(2) * probabilities
        ).sum(dim=1)
        teacher_probabilities = (
            teacher_probabilities
            / teacher_probabilities.sum(dim=1, keepdim=True).clamp_min(1e-8)
        )
        return {
            "teacher_probabilities": teacher_probabilities,
            "weights": weights,
            "evidence": evidence,
            "support": supports,
            "top_evidence": top_evidence,
            "client_probabilities": probabilities,
            "margins": margins,
            "class_prior": class_prior,
            "disagreement": jensen_shannon_divergence(probabilities),
            "fallback": fallback,
        }

    def forward(self, images, labels=None):
        chunk_size = self.inference_chunk_size
        if chunk_size <= 0 or images.size(0) <= chunk_size:
            return self._forward_impl(images, labels)

        outputs = []
        for start in range(0, images.size(0), chunk_size):
            end = min(start + chunk_size, images.size(0))
            chunk_labels = None if labels is None else labels[start:end]
            outputs.append(self._forward_impl(images[start:end], chunk_labels))

        merged = {}
        for key, value in outputs[0].items():
            if torch.is_tensor(value):
                merged[key] = torch.cat([output[key] for output in outputs], dim=0)
            else:
                merged[key] = [output[key] for output in outputs]
        return merged
