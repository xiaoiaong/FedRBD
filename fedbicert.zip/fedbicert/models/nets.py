#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6

from torch import nn
import torch.nn.functional as F
import torch


class CNNMnistTwoLayer(nn.Module):
    def __init__(self, in_channels=1, num_classes=10, img_size=28):
        super(CNNMnistTwoLayer, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 16, kernel_size=5, padding=2),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, kernel_size=5, padding=2),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        feature_dim = self._infer_feature_dim(in_channels, img_size)
        self.fc = nn.Linear(feature_dim, num_classes)

    def _infer_feature_dim(self, in_channels, img_size):
        with torch.no_grad():
            sample = torch.zeros(1, in_channels, img_size, img_size)
            output = self.features(sample)
        return output.view(1, -1).size(1)

    def forward(self, x, return_feature=False):
        out = self.features(x)
        feat = out.view(out.size(0), -1)
        logits = self.fc(feat)
        if return_feature:
            return logits, feat
        return logits


class CNNMnistFiveLayer(nn.Module):
    def __init__(self, in_channels=1, num_classes=10, img_size=28):
        super(CNNMnistFiveLayer, self).__init__()
        # Keep the final feature size compatible with downstream OS-CoFL
        # statistics and distillation code.
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        feature_dim = self._infer_feature_dim(in_channels, img_size)
        self.fc = nn.Linear(feature_dim, num_classes)

    def _infer_feature_dim(self, in_channels, img_size):
        with torch.no_grad():
            sample = torch.zeros(1, in_channels, img_size, img_size)
            output = self.features(sample)
        return output.view(1, -1).size(1)

    def forward(self, x, return_feature=False):
        out = self.features(x)
        feat = out.view(out.size(0), -1)
        logits = self.fc(feat)
        if return_feature:
            return logits, feat
        return logits


class CNNMnist(CNNMnistFiveLayer):
    pass


class CNN3(nn.Module):
    """Three-block CNN used for fair CIFAR10/SVHN FedHydra comparisons."""

    def __init__(self, in_channels=3, num_classes=10, width=64):
        super(CNN3, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, width, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(width),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(width, width * 2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(width * 2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(width * 2, width * 4, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(width * 4),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Linear(width * 4, num_classes)

    def forward(self, x, return_feature=False, return_features=False):
        out = self.features(x)
        feat = out.flatten(1)
        logits = self.classifier(feat)
        if return_feature or return_features:
            return logits, feat
        return logits


class LeNet(nn.Module):
    def __init__(self, in_channels=3, num_classes=10, img_size=32):
        super(LeNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=5, padding=2),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, kernel_size=5, padding=2),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((4, 4)),
        )
        self.classifier = nn.Sequential(
            nn.Linear(128 * 4 * 4, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(256, num_classes),
        )

    def forward(self, x, return_feature=False, return_features=False):
        out = self.features(x)
        feat = out.view(out.size(0), -1)
        logits = self.classifier(feat)
        if return_feature or return_features:
            return logits, feat
        return logits


class VGGSmall(nn.Module):
    def __init__(self, in_channels=3, num_classes=10, width=64):
        super(VGGSmall, self).__init__()
        cfg = [width, width, "M", width * 2, width * 2, "M",
               width * 4, width * 4, "M", width * 4, width * 4, "M"]
        layers = []
        c_in = in_channels
        for item in cfg:
            if item == "M":
                layers.append(nn.MaxPool2d(2))
            else:
                layers.extend([
                    nn.Conv2d(c_in, item, kernel_size=3, padding=1, bias=False),
                    nn.BatchNorm2d(item),
                    nn.ReLU(inplace=True),
                ])
                c_in = item
        layers.append(nn.AdaptiveAvgPool2d((1, 1)))
        self.features = nn.Sequential(*layers)
        self.classifier = nn.Linear(width * 4, num_classes)

    def forward(self, x, return_feature=False, return_features=False):
        out = self.features(x)
        feat = out.view(out.size(0), -1)
        logits = self.classifier(feat)
        if return_feature or return_features:
            return logits, feat
        return logits


class InceptionLite(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(InceptionLite, self).__init__()
        branch = max(out_channels // 4, 16)
        self.b1 = nn.Sequential(
            nn.Conv2d(in_channels, branch, kernel_size=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
        )
        self.b3 = nn.Sequential(
            nn.Conv2d(in_channels, branch, kernel_size=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
            nn.Conv2d(branch, branch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
        )
        self.b5 = nn.Sequential(
            nn.Conv2d(in_channels, branch, kernel_size=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
            nn.Conv2d(branch, branch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
            nn.Conv2d(branch, branch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
        )
        self.bp = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, stride=1, padding=1),
            nn.Conv2d(in_channels, branch, kernel_size=1, bias=False),
            nn.BatchNorm2d(branch),
            nn.ReLU(inplace=True),
        )
        merged_channels = branch * 4
        self.project = nn.Sequential(
            nn.Conv2d(merged_channels, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        out = torch.cat([self.b1(x), self.b3(x), self.b5(x), self.bp(x)], dim=1)
        return self.project(out)


class GoogleNetSmall(nn.Module):
    def __init__(self, in_channels=3, num_classes=10, width=64):
        super(GoogleNetSmall, self).__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, width, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(width),
            nn.ReLU(inplace=True),
        )
        self.features = nn.Sequential(
            InceptionLite(width, width),
            InceptionLite(width, width * 2),
            nn.MaxPool2d(2),
            InceptionLite(width * 2, width * 2),
            InceptionLite(width * 2, width * 4),
            nn.MaxPool2d(2),
            InceptionLite(width * 4, width * 4),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Linear(width * 4, num_classes)

    def forward(self, x, return_feature=False, return_features=False):
        out = self.stem(x)
        out = self.features(out)
        feat = out.view(out.size(0), -1)
        logits = self.classifier(feat)
        if return_feature or return_features:
            return logits, feat
        return logits







