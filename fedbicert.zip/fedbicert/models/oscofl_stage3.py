import torch
import torch.nn as nn
import torch.nn.functional as F


class SimpleConditionalGenerator(nn.Module):
    """
    第三阶段用的简化条件生成器：
    输入 z + label，输出 MNIST 伪图像。
    这里只用于验证 CE + KL 蒸馏链路是否稳定。
    """
    def __init__(self, nz=100, num_classes=10, img_size=28, nc=1, ngf=64):
        super(SimpleConditionalGenerator, self).__init__()

        self.nz = nz
        self.num_classes = num_classes
        self.img_size = img_size
        self.nc = nc

        self.label_emb = nn.Embedding(num_classes, nz)

        self.init_size = img_size // 4

        self.l1 = nn.Sequential(
            nn.Linear(nz * 2, ngf * 2 * self.init_size * self.init_size)
        )

        self.conv_blocks = nn.Sequential(
            nn.BatchNorm2d(ngf * 2),
            nn.Upsample(scale_factor=2),

            nn.Conv2d(ngf * 2, ngf * 2, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(ngf * 2),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Upsample(scale_factor=2),

            nn.Conv2d(ngf * 2, ngf, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(ngf),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(ngf, nc, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()
        )

    def forward(self, z, labels):
        label_code = self.label_emb(labels)
        x = torch.cat([z, label_code], dim=1)

        out = self.l1(x)
        out = out.view(out.size(0), -1, self.init_size, self.init_size)

        img = self.conv_blocks(out)
        return img
