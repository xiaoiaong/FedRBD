import copy
import math
import os
import time

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset

from models.fedbicert_generator import DualModeQueryGenerator
from models.fedbicert_router import CertifiedExpertRouter
from utils.risk_certificate import validate_risk_certificate


class _DeepInversionHook:
    def __init__(self, module):
        self.handle = module.register_forward_hook(self._hook)

    def _hook(self, module, inputs, output):
        features = inputs[0]
        mean = features.mean(dim=(0, 2, 3))
        variance = features.var(dim=(0, 2, 3), unbiased=False)
        self.r_feature = (
            torch.norm(module.running_var.detach() - variance, p=2)
            + torch.norm(module.running_mean.detach() - mean, p=2)
        )

    def remove(self):
        self.handle.remove()


def _dataset_spec(dataset):
    name = dataset.lower()
    if name in ["webvision", "webvision20"]:
        return 20, 3, 64
    if name in ["mnist", "fmnist"]:
        return 10, 1, 28
    if name in ["miniimagenet", "miniimage", "mini"]:
        return 100, 3, 84
    if name in ["tiny", "tinyimagenet"]:
        return 200, 3, 64
    return 10, 3, 32


def _normalization(dataset, device, dtype):
    name = dataset.lower()
    if name == "cifar10":
        mean = (0.4914, 0.4822, 0.4465)
        std = (0.2470, 0.2435, 0.2616)
    elif name == "svhn":
        mean = (0.4377, 0.4438, 0.4728)
        std = (0.1980, 0.2010, 0.1970)
    elif name in ["mnist", "fmnist"]:
        mean = (0.0,)
        std = (1.0,)
    else:
        mean = (0.485, 0.456, 0.406)
        std = (0.229, 0.224, 0.225)
    mean = torch.tensor(mean, device=device, dtype=dtype).view(1, -1, 1, 1)
    std = torch.tensor(std, device=device, dtype=dtype).view(1, -1, 1, 1)
    return mean, std


def normalize_images(dataset, images):
    mean, std = _normalization(dataset, images.device, images.dtype)
    return (images - mean) / std


def denormalize_images(dataset, images):
    mean, std = _normalization(dataset, images.device, images.dtype)
    return (images * std + mean).clamp(0.0, 1.0)


def _pixel_stat_loss(dataset, raw_images):
    mean, std = _normalization(dataset, raw_images.device, raw_images.dtype)
    target_mean = mean.view(1, -1)
    target_std = std.view(1, -1)
    image_mean = raw_images.mean(dim=(0, 2, 3), keepdim=True).view(1, -1)
    image_std = raw_images.std(dim=(0, 2, 3), keepdim=True).view(1, -1)
    return (
        F.mse_loss(image_mean, target_mean)
        + F.mse_loss(image_std, target_std)
    )


def _total_variation(images):
    horizontal = (images[:, :, 1:, :] - images[:, :, :-1, :]).abs().mean()
    vertical = (images[:, :, :, 1:] - images[:, :, :, :-1]).abs().mean()
    return horizontal + vertical


def _diversity_loss(images, noise):
    permutation = torch.randperm(images.size(0), device=images.device)
    image_distance = (
        images - images[permutation]
    ).abs().flatten(1).mean(dim=1)
    noise_distance = (
        noise - noise[permutation]
    ).abs().mean(dim=1)
    return -(image_distance / noise_distance.clamp_min(1e-4)).mean()


def _balanced_labels(num_classes, batch_size, device):
    repeats = int(math.ceil(batch_size / float(num_classes)))
    labels = torch.arange(num_classes, device=device).repeat(repeats)
    labels = labels[:batch_size]
    return labels[torch.randperm(labels.numel(), device=device)]


def _attach_bn_hooks(models):
    hooks = []
    for model in models:
        model_hooks = []
        for module in model.modules():
            if isinstance(module, torch.nn.BatchNorm2d):
                model_hooks.append(_DeepInversionHook(module))
        hooks.append(model_hooks)
    return hooks


def _bn_loss(hooks, device, client_weights=None):
    model_losses = []
    for model_hooks in hooks:
        active = [
            hook.r_feature
            for hook in model_hooks
            if hasattr(hook, "r_feature")
        ]
        if active:
            model_losses.append(torch.stack(active).mean())
        else:
            model_losses.append(torch.zeros((), device=device))
    if not model_losses:
        return torch.zeros((), device=device)
    model_losses = torch.stack(model_losses)
    if client_weights is None:
        return model_losses.mean()
    weights = client_weights.to(device=device, dtype=model_losses.dtype)
    return (
        model_losses * weights
    ).sum() / weights.sum().clamp_min(1e-8)


def _remove_hooks(hooks):
    for model_hooks in hooks:
        for hook in model_hooks:
            hook.remove()


def _freeze_batchnorm_running_stats(model):
    for module in model.modules():
        if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):
            module.eval()


def train_query_generator(args, generator, router, steps):
    device = next(generator.parameters()).device
    num_classes, _, _ = _dataset_spec(args.dataset)
    generator.train()
    router.eval()
    optimizer = torch.optim.Adam(
        generator.parameters(),
        lr=args.bicert_generator_lr,
        betas=(0.5, 0.999),
    )
    hooks = _attach_bn_hooks(router.models)
    totals = {
        "loss": 0.0,
        "coverage_nll": 0.0,
        "disagreement": 0.0,
        "evidence": 0.0,
        "target_acc": 0.0,
    }

    try:
        for step in range(steps):
            class_id = step % num_classes
            labels = torch.full(
                (args.synthesis_batch_size,),
                class_id,
                device=device,
                dtype=torch.long,
            )
            modes = torch.full_like(
                labels,
                DualModeQueryGenerator.COVERAGE,
            )
            conflict_count = int(
                round(labels.numel() * args.bicert_conflict_ratio)
            )
            if conflict_count > 0:
                conflict_indices = torch.randperm(
                    labels.numel(),
                    device=device,
                )[:conflict_count]
                modes[conflict_indices] = DualModeQueryGenerator.CONFLICT

            noise = torch.randn(labels.size(0), args.nz, device=device)
            raw_images = generator(noise, labels, modes)
            images = normalize_images(args.dataset, raw_images)
            route = router(images, labels)
            teacher = route["teacher_probabilities"]
            augmented_images = _augment(args.dataset, images)
            augmented_route = router(augmented_images, labels)
            augmented_teacher = augmented_route["teacher_probabilities"]
            target_nll = -torch.log(
                teacher.gather(1, labels[:, None]).squeeze(1).clamp_min(1e-8)
            )
            augmented_target_nll = -torch.log(
                augmented_teacher.gather(
                    1,
                    labels[:, None],
                ).squeeze(1).clamp_min(1e-8)
            )

            coverage_mask = modes.eq(DualModeQueryGenerator.COVERAGE)
            conflict_mask = ~coverage_mask
            coverage_loss = (
                target_nll[coverage_mask].mean()
                if coverage_mask.any()
                else torch.zeros((), device=device)
            )
            conflict_label_loss = (
                target_nll[conflict_mask].mean()
                if conflict_mask.any()
                else torch.zeros((), device=device)
            )
            conflict_disagreement = (
                route["disagreement"][conflict_mask].mean()
                if conflict_mask.any()
                else torch.zeros((), device=device)
            )
            evidence_penalty = F.relu(
                args.bicert_min_evidence - route["top_evidence"]
            ).mean()
            class_owner_weights = router.class_prior[:, class_id]
            loss_bn = _bn_loss(
                hooks,
                device,
                client_weights=class_owner_weights,
            )
            augmentation_consistency = F.kl_div(
                augmented_teacher.clamp_min(1e-8).log(),
                teacher.detach(),
                reduction="batchmean",
            )
            target_margin = F.relu(
                args.bicert_generator_min_confidence
                - teacher.gather(1, labels[:, None]).squeeze(1)
            ).mean()
            loss = (
                coverage_loss
                + 0.5 * conflict_label_loss
                + 0.5 * augmented_target_nll.mean()
                + 0.5 * target_margin
                + 0.2 * augmentation_consistency
                - args.bicert_disagreement_weight
                * conflict_disagreement.clamp(max=0.20)
                + args.bicert_support_weight * evidence_penalty
                + args.bicert_bn_weight * loss_bn
                + args.bicert_tv_weight * _total_variation(raw_images)
                + args.bicert_diversity_weight
                * _diversity_loss(raw_images, noise)
            )

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                generator.parameters(),
                args.bicert_grad_clip,
            )
            optimizer.step()

            totals["loss"] += float(loss.detach())
            totals["coverage_nll"] += float(coverage_loss.detach())
            totals["disagreement"] += float(
                route["disagreement"].mean().detach()
            )
            totals["evidence"] += float(
                route["top_evidence"].mean().detach()
            )
            totals["target_acc"] += float(
                teacher.argmax(dim=1).eq(labels).float().mean().detach()
            )
    finally:
        _remove_hooks(hooks)

    return {key: value / max(steps, 1) for key, value in totals.items()}


def _cutout_normalized(images, fraction):
    fraction = float(fraction)
    if fraction <= 0.0:
        return images
    _, _, height, width = images.shape
    cut_height = max(1, int(round(height * min(fraction, 0.8))))
    cut_width = max(1, int(round(width * min(fraction, 0.8))))
    max_y = max(1, height - cut_height + 1)
    max_x = max(1, width - cut_width + 1)
    for index in range(images.size(0)):
        y0 = int(torch.randint(0, max_y, (1,), device=images.device).item())
        x0 = int(torch.randint(0, max_x, (1,), device=images.device).item())
        images[index, :, y0 : y0 + cut_height, x0 : x0 + cut_width] = 0.0
    return images


def _same_class_mosaic(samples, mix_k):
    batch_size, _, channels, height, width = samples.shape
    if mix_k < 4:
        return samples.mean(dim=1)
    mosaic = samples[:, 0].clone()
    half_h = height // 2
    half_w = width // 2
    mosaic[:, :, :half_h, :half_w] = samples[:, 0, :, :half_h, :half_w]
    mosaic[:, :, :half_h, half_w:] = samples[:, 1, :, :half_h, half_w:]
    mosaic[:, :, half_h:, :half_w] = samples[:, 2, :, half_h:, :half_w]
    mosaic[:, :, half_h:, half_w:] = samples[:, 3, :, half_h:, half_w:]
    if mix_k > 4:
        tail = samples[:, 4:].mean(dim=1)
        alpha = torch.rand(batch_size, 1, 1, 1, device=samples.device) * 0.3
        mosaic = (1.0 - alpha) * mosaic + alpha * tail
    return mosaic


def _collect_client_class_pools(train_loader, supported_classes, device):
    supported = {int(class_id) for class_id in supported_classes.tolist()}
    pools = {class_id: [] for class_id in supported}
    for images, labels in train_loader:
        labels = labels.long()
        for class_id in supported:
            mask = labels.eq(class_id)
            if mask.any():
                pools[class_id].append(images[mask].detach().cpu())
    return {
        class_id: torch.cat(parts, dim=0)
        for class_id, parts in pools.items()
        if parts
    }


def _generate_client_mixup_anchor_payload(
    args,
    model,
    certificate,
    train_loader,
    supported_classes,
    per_class,
    device,
):
    if train_loader is None:
        return None

    mode = str(getattr(args, "bicert_client_anchor_mode", "mixup")).lower()
    if mode in ["deepinversion", "di", "noise"]:
        return None

    pools = _collect_client_class_pools(train_loader, supported_classes, device)
    if not pools:
        return None

    temperature = certificate["temperature"].to(device).float().clamp(0.5, 5.0)
    batch_size = max(8, int(getattr(args, "bicert_client_anchor_batch_size", 64)))
    mix_k = max(2, int(getattr(args, "bicert_client_anchor_mix_k", 4)))
    candidate_multiplier = max(
        1,
        int(getattr(args, "bicert_client_anchor_candidate_multiplier", 3)),
    )
    noise_std = max(0.0, float(getattr(args, "bicert_client_anchor_noise_std", 0.03)))
    cutout = max(0.0, float(getattr(args, "bicert_client_anchor_cutout", 0.25)))
    min_count = max(2, int(getattr(args, "bicert_client_anchor_min_count", 10)))

    images_out = []
    labels_out = []
    logits_out = []
    scores_out = []
    model_was_training = model.training
    model.eval()

    with torch.no_grad():
        for class_id in sorted(pools):
            pool = pools[class_id]
            if pool.size(0) < min_count:
                continue

            candidate_images = []
            candidate_logits = []
            candidate_scores = []
            total_candidates = per_class * candidate_multiplier
            made = 0
            while made < total_candidates:
                current = min(batch_size, total_candidates - made)
                indices = torch.randint(
                    0,
                    pool.size(0),
                    (current, mix_k),
                )
                samples = pool[indices].to(device).float()
                if "mosaic" in mode:
                    mixed = _same_class_mosaic(samples, mix_k)
                else:
                    weights = torch.rand(current, mix_k, device=device)
                    weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(
                        1e-8
                    )
                    mixed = (
                        samples
                        * weights.view(current, mix_k, 1, 1, 1)
                    ).sum(dim=1)

                if "hybrid" in mode and mix_k >= 4:
                    mosaic = _same_class_mosaic(samples, mix_k)
                    alpha = torch.rand(current, 1, 1, 1, device=device) * 0.5
                    mixed = (1.0 - alpha) * mixed + alpha * mosaic

                if mixed.size(-1) == mixed.size(-2) and mixed.size(-1) >= 28:
                    flip_mask = torch.rand(current, device=device).lt(0.5)
                    if flip_mask.any():
                        mixed[flip_mask] = mixed[flip_mask].flip(dims=[3])
                if noise_std > 0.0:
                    mixed = mixed + torch.randn_like(mixed) * noise_std
                mixed = _cutout_normalized(mixed, cutout)

                labels = torch.full(
                    (current,),
                    int(class_id),
                    device=device,
                    dtype=torch.long,
                )
                logits = model(mixed) / temperature
                probabilities = F.softmax(logits, dim=1)
                target_prob = probabilities.gather(1, labels[:, None]).squeeze(1)
                candidate_images.append(mixed.detach().cpu())
                candidate_logits.append(logits.detach().cpu())
                candidate_scores.append(target_prob.detach().cpu())
                made += current

            if not candidate_images:
                continue
            class_images = torch.cat(candidate_images, dim=0)
            class_logits = torch.cat(candidate_logits, dim=0)
            class_scores = torch.cat(candidate_scores, dim=0)
            take = min(per_class, class_scores.numel())
            top_indices = class_scores.topk(take).indices
            images_out.append(class_images[top_indices])
            logits_out.append(class_logits[top_indices])
            scores_out.append(class_scores[top_indices])
            labels_out.append(torch.full((take,), int(class_id), dtype=torch.long))

    if model_was_training:
        model.train()

    if not images_out:
        return None

    return {
        "synthetic_anchor_images": torch.cat(images_out, dim=0),
        "synthetic_anchor_labels": torch.cat(labels_out, dim=0),
        "synthetic_anchor_logits": torch.cat(logits_out, dim=0),
        "synthetic_anchor_scores": torch.cat(scores_out, dim=0).float(),
        "synthetic_anchor_protocol": f"client_{mode}_anchor_v1",
    }


def generate_client_synthetic_anchor_payload(
    args,
    model,
    certificate,
    device,
    train_loader=None,
):
    """Generate non-real client anchors for the one-shot upload payload."""
    per_class = int(getattr(args, "bicert_client_anchor_per_class", 0))
    if per_class <= 0:
        return {
            "synthetic_anchor_images": torch.empty(0),
            "synthetic_anchor_labels": torch.empty(0, dtype=torch.long),
            "synthetic_anchor_logits": torch.empty(0),
            "synthetic_anchor_protocol": "disabled",
        }

    num_classes, channels, image_size = _dataset_spec(args.dataset)
    class_counts = certificate["class_counts"].to(device)
    min_count = float(getattr(args, "bicert_client_anchor_min_count", 10))
    supported_classes = class_counts.ge(min_count).nonzero(
        as_tuple=False,
    ).flatten()
    if supported_classes.numel() == 0:
        supported_classes = class_counts.argmax().view(1)

    mixup_payload = _generate_client_mixup_anchor_payload(
        args=args,
        model=model,
        certificate=certificate,
        train_loader=train_loader,
        supported_classes=supported_classes,
        per_class=per_class,
        device=device,
    )
    if mixup_payload is not None:
        return mixup_payload

    model.eval()
    old_requires_grad = [parameter.requires_grad for parameter in model.parameters()]
    for parameter in model.parameters():
        parameter.requires_grad_(False)

    temperature = certificate["temperature"].to(device).float().clamp(0.5, 5.0)
    batch_size = int(getattr(args, "bicert_client_anchor_batch_size", 64))
    batch_size = max(supported_classes.numel(), batch_size)
    steps = max(1, int(getattr(args, "bicert_client_anchor_steps", 120)))
    lr = float(getattr(args, "bicert_client_anchor_lr", 0.08))
    feature_mean = certificate["feature_mean"].to(device).float()
    feature_var = certificate["feature_var"].to(device).float().clamp_min(0.02)
    margin_mean = certificate["margin_mean"].to(device).float()
    margin_std = certificate["margin_std"].to(device).float().clamp_min(0.25)
    logit_mean = certificate.get("class_logit_mean")
    logit_var = certificate.get("class_logit_var")
    prob_mean = certificate.get("class_prob_mean")
    if torch.is_tensor(logit_mean) and torch.is_tensor(logit_var):
        logit_mean = logit_mean.to(device).float()
        logit_var = logit_var.to(device).float().clamp_min(0.05)
    else:
        logit_mean = None
        logit_var = None
    if torch.is_tensor(prob_mean):
        prob_mean = prob_mean.to(device).float()
        prob_mean = prob_mean / prob_mean.sum(
            dim=1,
            keepdim=True,
        ).clamp_min(1e-8)
    else:
        prob_mean = None
    feature_weight = float(
        getattr(args, "bicert_client_anchor_feature_weight", 1.0)
    )
    logit_weight = float(
        getattr(args, "bicert_client_anchor_logit_weight", 0.5)
    )
    margin_weight = float(
        getattr(args, "bicert_client_anchor_margin_weight", 0.2)
    )
    target_total = int(per_class * supported_classes.numel())
    collected = {int(class_id): [] for class_id in supported_classes.tolist()}
    collected_logits = {int(class_id): [] for class_id in supported_classes.tolist()}
    collected_scores = {int(class_id): [] for class_id in supported_classes.tolist()}
    max_rounds = max(1, int(math.ceil(target_total / float(batch_size))) * 3)
    hooks = _attach_bn_hooks([model])

    try:
        for _round in range(max_rounds):
            active_classes = [
                class_id
                for class_id, images in collected.items()
                if len(images) < per_class
            ]
            if not active_classes:
                break
            active = torch.tensor(active_classes, device=device, dtype=torch.long)
            repeats = int(math.ceil(batch_size / float(active.numel())))
            labels = active.repeat(repeats)[:batch_size]
            labels = labels[torch.randperm(labels.numel(), device=device)]
            raw = (
                torch.randn(
                    labels.numel(),
                    channels,
                    image_size,
                    image_size,
                    device=device,
                )
                * 0.25
            ).requires_grad_(True)
            optimizer = torch.optim.Adam([raw], lr=lr, betas=(0.5, 0.999))
            best_raw = raw.detach().clone()
            best_score = torch.full(
                (labels.numel(),),
                -float("inf"),
                device=device,
            )

            for _step in range(steps):
                raw_images = torch.sigmoid(raw)
                images = normalize_images(args.dataset, raw_images)
                logits, features = model(images, return_feature=True)
                features = F.normalize(features.float(), dim=1)
                logits = logits / temperature
                probabilities = F.softmax(logits, dim=1)
                target_prob = probabilities.gather(
                    1,
                    labels[:, None],
                ).squeeze(1)
                target_nll = F.cross_entropy(logits, labels)
                confidence_penalty = F.relu(
                    args.bicert_generator_min_confidence - target_prob
                ).mean()
                entropy = -(
                    probabilities.clamp_min(1e-8)
                    * probabilities.clamp_min(1e-8).log()
                ).sum(dim=1).mean()
                target_feature_mean = feature_mean[labels]
                target_feature_var = feature_var[labels]
                feature_loss = (
                    (features - target_feature_mean).square()
                    / target_feature_var
                ).mean()
                target_logits = logits.gather(1, labels[:, None]).squeeze(1)
                other_logits = logits.clone()
                other_logits.scatter_(1, labels[:, None], -float("inf"))
                margins = target_logits - other_logits.max(dim=1).values
                margin_loss = (
                    (margins - margin_mean[labels]).abs()
                    / margin_std[labels]
                ).clamp(max=10.0).mean()
                if logit_mean is not None:
                    logit_loss = (
                        (logits - logit_mean[labels]).square()
                        / logit_var[labels]
                    ).mean()
                else:
                    logit_loss = torch.zeros((), device=device)
                if prob_mean is not None:
                    prob_loss = F.kl_div(
                        probabilities.clamp_min(1e-8).log(),
                        prob_mean[labels],
                        reduction="batchmean",
                    )
                else:
                    prob_loss = torch.zeros((), device=device)
                loss_bn = _bn_loss(hooks, device)
                anchor_regularization = float(
                    getattr(args, "bicert_client_anchor_regularization_weight", 1.0)
                ) * (
                    args.bicert_bn_weight * loss_bn
                    + args.bicert_tv_weight * _total_variation(raw_images)
                    + 0.02 * _pixel_stat_loss(args.dataset, raw_images)
                )
                loss = (
                    0.5 * target_nll
                    + 0.4 * confidence_penalty
                    + feature_weight * feature_loss
                    + logit_weight * (0.2 * logit_loss + prob_loss)
                    + margin_weight * margin_loss
                    + anchor_regularization
                    - 0.01 * entropy
                )

                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_([raw], args.bicert_grad_clip)
                optimizer.step()

                with torch.no_grad():
                    score = target_prob.detach()
                    better = score.gt(best_score)
                    best_score = torch.where(better, score, best_score)
                    best_raw = torch.where(
                        better.view(-1, 1, 1, 1),
                        raw.detach(),
                        best_raw,
                    )

            with torch.no_grad():
                raw_images = torch.sigmoid(best_raw)
                images = normalize_images(args.dataset, raw_images)
                logits = model(images) / temperature
                probabilities = F.softmax(logits, dim=1)
                target_prob = probabilities.gather(
                    1,
                    labels[:, None],
                ).squeeze(1)
                predictions = probabilities.argmax(dim=1)
                for class_id in active_classes:
                    needed = per_class - len(collected[class_id])
                    if needed <= 0:
                        continue
                    class_mask = labels.eq(class_id)
                    class_indices = class_mask.nonzero(
                        as_tuple=False,
                    ).flatten()
                    if class_indices.numel() == 0:
                        continue
                    valid = class_indices[predictions[class_indices].eq(class_id)]
                    pool = valid if valid.numel() > 0 else class_indices
                    take = min(needed, pool.numel())
                    top = pool[target_prob[pool].topk(take).indices]
                    for index in top.tolist():
                        collected[class_id].append(images[index].detach().cpu())
                        collected_logits[class_id].append(logits[index].detach().cpu())
                        collected_scores[class_id].append(float(target_prob[index]))

    finally:
        _remove_hooks(hooks)
        for parameter, requires_grad in zip(model.parameters(), old_requires_grad):
            parameter.requires_grad_(requires_grad)

    images_out = []
    labels_out = []
    logits_out = []
    scores_out = []
    for class_id in sorted(collected):
        for image, logits, score in zip(
            collected[class_id],
            collected_logits[class_id],
            collected_scores[class_id],
        ):
            images_out.append(image)
            labels_out.append(class_id)
            logits_out.append(logits)
            scores_out.append(score)

    if not images_out:
        return {
            "synthetic_anchor_images": torch.empty(0),
            "synthetic_anchor_labels": torch.empty(0, dtype=torch.long),
            "synthetic_anchor_logits": torch.empty(0),
            "synthetic_anchor_scores": torch.empty(0),
            "synthetic_anchor_protocol": "client_deepinversion_empty",
        }

    return {
        "synthetic_anchor_images": torch.stack(images_out, dim=0),
        "synthetic_anchor_labels": torch.tensor(labels_out, dtype=torch.long),
        "synthetic_anchor_logits": torch.stack(logits_out, dim=0),
        "synthetic_anchor_scores": torch.tensor(scores_out, dtype=torch.float32),
        "synthetic_anchor_protocol": "client_deepinversion_v1",
    }


def _select_balanced_indices(labels, score, batch_size, num_classes, valid=None):
    selected_parts = []
    base_quota = batch_size // num_classes
    remainder = batch_size % num_classes
    for class_id in range(num_classes):
        quota = base_quota + int(class_id < remainder)
        if quota <= 0:
            continue
        class_indices = labels.eq(class_id).nonzero(
            as_tuple=False,
        ).flatten()
        if class_indices.numel() == 0:
            continue
        if valid is not None:
            class_valid = class_indices[valid[class_indices]]
        else:
            class_valid = class_indices
        pool = class_valid if class_valid.numel() > 0 else class_indices
        take = min(quota, pool.numel())
        chosen = pool[score[pool].topk(take).indices]
        selected_parts.append(chosen)
        if take < quota:
            repeat_count = quota - take
            filler = pool[
                torch.randint(
                    0,
                    pool.numel(),
                    (repeat_count,),
                    device=pool.device,
                )
            ]
            selected_parts.append(filler)
    if not selected_parts:
        return score.topk(min(batch_size, score.numel())).indices
    selected = torch.cat(selected_parts, dim=0)
    if selected.numel() < batch_size:
        filler = selected[
            torch.randint(
                0,
                selected.numel(),
                (batch_size - selected.numel(),),
                device=selected.device,
            )
        ]
        selected = torch.cat([selected, filler], dim=0)
    selected = selected[:batch_size]
    return selected[torch.randperm(selected.numel(), device=selected.device)]


def build_query_bank(args, generator, batches, seed, router=None):
    device = next(generator.parameters()).device
    num_classes, _, _ = _dataset_spec(args.dataset)
    generator.eval()
    bank = []
    devices = [device.index] if device.type == "cuda" else []
    with torch.random.fork_rng(devices=devices):
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
        with torch.no_grad():
            for _ in range(batches):
                candidate_size = args.synthesis_batch_size * (
                    3 if router is not None else 1
                )
                labels = _balanced_labels(
                    num_classes,
                    candidate_size,
                    device,
                )
                modes = torch.full_like(
                    labels,
                    DualModeQueryGenerator.COVERAGE,
                )
                conflict_count = int(
                    round(labels.numel() * args.bicert_conflict_ratio)
                )
                if conflict_count > 0:
                    conflict_indices = torch.randperm(
                        labels.numel(),
                        device=device,
                    )[:conflict_count]
                    modes[conflict_indices] = DualModeQueryGenerator.CONFLICT
                noise = torch.randn(labels.size(0), args.nz, device=device)
                raw_images = generator(noise, labels, modes)
                images = normalize_images(
                    args.dataset,
                    raw_images,
                )
                if router is not None:
                    route = router(images, labels)
                    augmented_route = router(
                        _augment(args.dataset, images),
                        labels,
                    )
                    target_prob = route["teacher_probabilities"].gather(
                        1,
                        labels[:, None],
                    ).squeeze(1)
                    augmented_target_prob = (
                        augmented_route["teacher_probabilities"]
                        .gather(1, labels[:, None])
                        .squeeze(1)
                    )
                    score = (
                        target_prob
                        * augmented_target_prob
                        * route["top_evidence"].clamp_min(1e-6)
                    )
                    valid = (
                        route["teacher_probabilities"].argmax(dim=1).eq(labels)
                        & augmented_route["teacher_probabilities"]
                        .argmax(dim=1).eq(labels)
                        & target_prob.ge(
                            args.bicert_generator_min_confidence
                        )
                        & augmented_target_prob.ge(
                            args.bicert_generator_min_confidence
                        )
                    )
                    selected = _select_balanced_indices(
                        labels,
                        score,
                        args.synthesis_batch_size,
                        num_classes,
                        valid=valid,
                    )
                    images = images[selected]
                    labels = labels[selected]
                    modes = modes[selected]
                bank.append(
                    {
                        "images": images.detach(),
                        "labels": labels.detach(),
                        "modes": modes.detach(),
                    }
                )
    return bank


def build_inversion_query_bank(args, router, batches, seed):
    device = next(router.parameters()).device
    num_classes, channels, image_size = _dataset_spec(args.dataset)
    router.eval()
    bank = []
    devices = [device.index] if device.type == "cuda" else []
    with torch.random.fork_rng(devices=devices):
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
        hooks = _attach_bn_hooks(router.models)
        try:
            for _ in range(batches):
                candidate_size = args.synthesis_batch_size * 2
                labels = _balanced_labels(
                    num_classes,
                    candidate_size,
                    device,
                )
                raw = (
                    torch.randn(
                        candidate_size,
                        channels,
                        image_size,
                        image_size,
                        device=device,
                    )
                    * 0.25
                ).requires_grad_(True)
                optimizer = torch.optim.Adam(
                    [raw],
                    lr=args.bicert_inversion_lr,
                    betas=(0.5, 0.999),
                )
                best_raw = None
                best_score = None
                for _step in range(max(args.bicert_inversion_steps, 1)):
                    raw_images = torch.sigmoid(raw)
                    images = normalize_images(args.dataset, raw_images)
                    route = router(images, labels)
                    augmented_route = router(
                        _augment(args.dataset, images),
                        labels,
                    )
                    teacher = route["teacher_probabilities"]
                    augmented_teacher = augmented_route["teacher_probabilities"]
                    target_prob = teacher.gather(
                        1,
                        labels[:, None],
                    ).squeeze(1)
                    augmented_target_prob = augmented_teacher.gather(
                        1,
                        labels[:, None],
                    ).squeeze(1)
                    target_nll = -torch.log(target_prob.clamp_min(1e-8)).mean()
                    augmented_nll = -torch.log(
                        augmented_target_prob.clamp_min(1e-8)
                    ).mean()
                    target_margin = F.relu(
                        args.bicert_generator_min_confidence - target_prob
                    ).mean()
                    evidence_penalty = F.relu(
                        args.bicert_min_evidence - route["top_evidence"]
                    ).mean()
                    owner_weights = router.class_prior[:, labels].mean(dim=1)
                    loss_bn = _bn_loss(
                        hooks,
                        device,
                        client_weights=owner_weights,
                    )
                    consistency = F.kl_div(
                        augmented_teacher.clamp_min(1e-8).log(),
                        teacher.detach(),
                        reduction="batchmean",
                    )
                    loss = (
                        target_nll
                        + 0.7 * augmented_nll
                        + 0.3 * target_margin
                        + 0.2 * consistency
                        + args.bicert_support_weight * evidence_penalty
                        + args.bicert_bn_weight * loss_bn
                        + args.bicert_tv_weight * _total_variation(raw_images)
                        + 0.02 * _pixel_stat_loss(args.dataset, raw_images)
                    )
                    optimizer.zero_grad(set_to_none=True)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_([raw], args.bicert_grad_clip)
                    optimizer.step()

                    with torch.no_grad():
                        score = (
                            target_prob.detach()
                            * augmented_target_prob.detach()
                            * route["top_evidence"].detach().clamp_min(1e-6)
                        )
                        if best_score is None:
                            best_score = score.clone()
                            best_raw = raw.detach().clone()
                        else:
                            better = score.gt(best_score)
                            best_score = torch.where(
                                better,
                                score,
                                best_score,
                            )
                            best_raw = torch.where(
                                better.view(-1, 1, 1, 1),
                                raw.detach(),
                                best_raw,
                            )

                with torch.no_grad():
                    raw_images = torch.sigmoid(best_raw)
                    images = normalize_images(args.dataset, raw_images)
                    route = router(images, labels)
                    augmented_route = router(_augment(args.dataset, images), labels)
                    target_prob = route["teacher_probabilities"].gather(
                        1,
                        labels[:, None],
                    ).squeeze(1)
                    augmented_target_prob = (
                        augmented_route["teacher_probabilities"]
                        .gather(1, labels[:, None])
                        .squeeze(1)
                    )
                    score = (
                        target_prob
                        * augmented_target_prob
                        * route["top_evidence"].clamp_min(1e-6)
                    )
                    valid = (
                        route["teacher_probabilities"].argmax(dim=1).eq(labels)
                        & augmented_route["teacher_probabilities"]
                        .argmax(dim=1).eq(labels)
                        & target_prob.ge(args.bicert_generator_min_confidence)
                        & augmented_target_prob.ge(
                            args.bicert_generator_min_confidence
                        )
                    )
                    selected = _select_balanced_indices(
                        labels,
                        score,
                        args.synthesis_batch_size,
                        num_classes,
                        valid=valid,
                    )
                    bank.append(
                        {
                            "images": images[selected].detach(),
                            "labels": labels[selected].detach(),
                            "modes": torch.full(
                                (selected.numel(),),
                                DualModeQueryGenerator.COVERAGE,
                                device=device,
                                dtype=torch.long,
                            ),
                            "source": "inversion",
                        }
                    )
        finally:
            _remove_hooks(hooks)
    return bank


def _dataset_labels(dataset):
    if hasattr(dataset, "labels"):
        return np.asarray(dataset.labels)
    if hasattr(dataset, "targets"):
        targets = dataset.targets
        if torch.is_tensor(targets):
            return targets.detach().cpu().numpy()
        return np.asarray(targets)
    if hasattr(dataset, "samples"):
        return np.asarray([sample[1] for sample in dataset.samples])
    if hasattr(dataset, "tensors") and len(dataset.tensors) >= 2:
        labels = dataset.tensors[1]
        if torch.is_tensor(labels):
            return labels.detach().cpu().numpy()
        return np.asarray(labels)
    raise ValueError("The dataset does not expose labels for public anchors.")


def build_public_anchor_bank(args, train_dataset, router, batches, seed):
    per_class = int(args.bicert_public_anchor_per_class)
    if per_class <= 0:
        return []
    if int(getattr(args, "bicert_allow_public_anchor", 0)) != 1:
        raise RuntimeError(
            "public-anchor uses real train_dataset samples on the server. "
            "This violates strict data-free FedBiCert. Set "
            "--bicert_public_anchor_per_class 0 for the main data-free "
            "experiment, or explicitly pass --bicert_allow_public_anchor 1 "
            "only for the public-data variant."
        )
    device = next(router.parameters()).device
    num_classes, _, _ = _dataset_spec(args.dataset)
    labels_array = _dataset_labels(train_dataset)
    rng = np.random.RandomState(seed)
    selected_indices = []
    for class_id in range(num_classes):
        class_indices = np.where(labels_array == class_id)[0]
        if class_indices.size == 0:
            continue
        rng.shuffle(class_indices)
        selected_indices.extend(class_indices[:min(per_class, class_indices.size)])
    if not selected_indices:
        return []
    rng.shuffle(selected_indices)
    loader = DataLoader(
        Subset(train_dataset, selected_indices),
        batch_size=args.synthesis_batch_size,
        shuffle=True,
        num_workers=0,
        drop_last=False,
    )
    bank = []
    router.eval()
    with torch.no_grad():
        for batch_index, (images, labels) in enumerate(loader):
            if batch_index >= max(batches, 1):
                break
            images = images.to(device)
            labels = labels.to(device).long()
            route = router(images, labels)
            teacher = route["teacher_probabilities"]
            target_prob = teacher.gather(1, labels[:, None]).squeeze(1)
            keep = (
                teacher.argmax(dim=1).eq(labels)
                & target_prob.ge(args.bicert_generator_min_confidence)
            )
            if keep.sum().item() < max(4, images.size(0) // 4):
                keep = torch.ones_like(labels, dtype=torch.bool)
            bank.append(
                {
                    "images": images[keep].detach(),
                    "labels": labels[keep].detach(),
                    "modes": torch.full(
                        (int(keep.sum().item()),),
                        DualModeQueryGenerator.COVERAGE,
                        device=device,
                        dtype=torch.long,
                    ),
                    "source": "public_anchor",
                }
            )
    return [batch for batch in bank if batch["labels"].numel() > 0]


def build_client_synthetic_anchor_bank(args, router, certificates, batches, seed):
    ablation = str(getattr(args, "bicert_ablation", "a0")).lower()
    if ablation == "a1_model_only":
        return []
    if int(getattr(args, "bicert_use_client_anchors", 1)) != 1:
        return []
    device = next(router.parameters()).device
    images_parts = []
    labels_parts = []
    probability_parts = []
    quality_parts = []
    client_parts = []

    for client_index, certificate in enumerate(certificates):
        images = certificate.get("synthetic_anchor_images")
        labels = certificate.get("synthetic_anchor_labels")
        logits = certificate.get("synthetic_anchor_logits")
        scores = certificate.get("synthetic_anchor_scores")
        if not (
            torch.is_tensor(images)
            and torch.is_tensor(labels)
            and torch.is_tensor(logits)
            and labels.numel() > 0
        ):
            continue
        if images.dim() != 4 or logits.dim() != 2:
            continue
        labels = labels.long()
        probabilities = F.softmax(logits.float(), dim=1)
        if torch.is_tensor(scores) and scores.numel() == labels.numel():
            quality = scores.float().clamp(0.0, 1.0)
        else:
            quality = probabilities.max(dim=1).values
        images_parts.append(images.float())
        labels_parts.append(labels)
        probability_parts.append(probabilities)
        quality_parts.append(quality)
        client_parts.append(
            torch.full(
                (labels.numel(),),
                client_index,
                dtype=torch.long,
            )
        )

    if not images_parts:
        return []

    images = torch.cat(images_parts, dim=0).to(device)
    labels = torch.cat(labels_parts, dim=0).to(device)
    probabilities = torch.cat(probability_parts, dim=0).to(device)
    quality = torch.cat(quality_parts, dim=0).to(device)
    client_ids = torch.cat(client_parts, dim=0).to(device)

    devices = [device.index] if device.type == "cuda" else []
    with torch.random.fork_rng(devices=devices):
        torch.manual_seed(seed)
        if device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
        order = torch.randperm(labels.numel(), device=device)

    if int(getattr(args, "bicert_client_anchor_use_all", 1)) == 1:
        max_examples = labels.numel()
    else:
        max_examples = max(1, batches) * args.synthesis_batch_size
    order = order[:min(order.numel(), max_examples)]
    images = images[order]
    labels = labels[order]
    probabilities = probabilities[order]
    quality = quality[order]
    client_ids = client_ids[order]

    # Uploaded anchor targets are the originating client's probabilities in
    # A0. Keep them identical across router ablations so only the routing of
    # generated/inverted queries changes relative to the existing Full run.

    bank = []
    for start in range(0, labels.numel(), args.synthesis_batch_size):
        end = min(start + args.synthesis_batch_size, labels.numel())
        if end <= start:
            continue
        bank.append(
            {
                "images": images[start:end].detach(),
                "labels": labels[start:end].detach(),
                "modes": torch.full(
                    (end - start,),
                    DualModeQueryGenerator.COVERAGE,
                    device=device,
                    dtype=torch.long,
                ),
                "teacher_probabilities": probabilities[start:end].detach(),
                "quality": quality[start:end].detach(),
                "client_ids": client_ids[start:end].detach(),
                "source": "client_synthetic_anchor",
            }
        )
    return bank


def _query_sources(args):
    if str(getattr(args, "bicert_ablation", "a0")).lower() == "a4_client_only":
        return set()
    source = str(getattr(args, "bicert_query_source", "hybrid")).lower()
    if source in ["generator", "gen"]:
        return {"generator"}
    if source in ["inversion", "direct", "di"]:
        return {"inversion"}
    if source in ["hybrid", "mixed", "all"]:
        return {"generator", "inversion"}
    raise ValueError(
        "--bicert_query_source must be generator, inversion, or hybrid"
    )


def build_fedbicert_banks(
    args,
    generator,
    router,
    train_dataset,
    client_certificates,
    train_seed,
    proxy_seed,
    generator_steps=None,
    include_proxy=True,
):
    sources = _query_sources(args)
    train_bank = []
    proxy_bank = []
    generator_metrics = None

    if "generator" in sources:
        if generator_steps is None:
            generator_steps = args.bicert_generator_steps
        generator_metrics = train_query_generator(
            args,
            generator,
            router,
            generator_steps,
        )
        train_bank.extend(
            build_query_bank(
                args,
                generator,
                args.bicert_bank_batches,
                train_seed,
                router=router,
            )
        )
        if include_proxy:
            proxy_bank.extend(
                build_query_bank(
                    args,
                    generator,
                    args.bicert_proxy_batches,
                    proxy_seed,
                    router=router,
                )
            )

    if "inversion" in sources:
        train_bank.extend(
            build_inversion_query_bank(
                args,
                router,
                args.bicert_bank_batches,
                train_seed + 971,
            )
        )
        if include_proxy:
            proxy_bank.extend(
                build_inversion_query_bank(
                    args,
                    router,
                    max(1, args.bicert_proxy_batches // 2),
                    proxy_seed + 971,
                )
            )

    train_bank.extend(
        build_client_synthetic_anchor_bank(
            args,
            router,
            client_certificates,
            args.bicert_bank_batches,
            train_seed + 2333,
        )
    )
    if include_proxy:
        proxy_bank.extend(
            build_client_synthetic_anchor_bank(
                args,
                router,
                client_certificates,
                max(1, args.bicert_proxy_batches),
                proxy_seed + 2333,
            )
        )

    anchor_batches = int(getattr(args, "bicert_public_anchor_batches", 0))
    train_bank.extend(
        build_public_anchor_bank(
            args,
            train_dataset,
            router,
            anchor_batches,
            train_seed + 1777,
        )
    )
    if include_proxy:
        proxy_bank.extend(
            build_public_anchor_bank(
                args,
                train_dataset,
                router,
                max(1, anchor_batches // 2),
                proxy_seed + 1777,
            )
        )

    if not train_bank or (include_proxy and not proxy_bank):
        raise RuntimeError("FedBiCert built an empty query bank.")
    return train_bank, proxy_bank, generator_metrics


def _augment(dataset, images):
    output = images.clone()
    if output.size(-1) >= 24:
        padding = 2 if dataset.lower() == "svhn" else 4
        padded = F.pad(
            output,
            (padding, padding, padding, padding),
            mode="reflect",
        )
        y_offset = int(
            torch.randint(0, 2 * padding + 1, (1,)).item()
        )
        x_offset = int(
            torch.randint(0, 2 * padding + 1, (1,)).item()
        )
        output = padded[
            :,
            :,
            y_offset:y_offset + images.size(-2),
            x_offset:x_offset + images.size(-1),
        ]
    if dataset.lower() in ["cifar10", "cifar100", "webvision", "webvision20"]:
        flip = torch.rand(output.size(0), device=output.device).lt(0.5)
        output[flip] = torch.flip(output[flip], dims=[3])
    return output + 0.005 * torch.randn_like(output)


def _soft_kl(student_logits, teacher_probabilities, temperature):
    teacher = teacher_probabilities.clamp_min(1e-8)
    if temperature != 1.0:
        teacher = F.softmax(teacher.log() / temperature, dim=1)
    return F.kl_div(
        F.log_softmax(student_logits / temperature, dim=1),
        teacher,
        reduction="none",
    ).sum(dim=1) * (temperature ** 2)


def _class_cvar(losses, labels, num_classes, fraction):
    class_losses = []
    for class_id in range(num_classes):
        mask = labels.eq(class_id)
        if mask.any():
            class_losses.append(losses[mask].mean())
    if not class_losses:
        return losses.mean()
    class_losses = torch.stack(class_losses)
    count = max(1, int(math.ceil(class_losses.numel() * fraction)))
    return class_losses.topk(count).values.mean()


def train_server_epoch(
    args,
    server,
    router,
    optimizer,
    bank,
    kd_scale=1.0,
    freeze_bn=True,
):
    server.train()
    if freeze_bn and int(getattr(args, "bicert_freeze_server_bn", 1)) == 1:
        _freeze_batchnorm_running_stats(server)
    router.eval()
    num_classes, _, _ = _dataset_spec(args.dataset)
    totals = {
        "loss": 0.0,
        "kd": 0.0,
        "hard": 0.0,
        "cvar": 0.0,
        "consistency": 0.0,
        "quality": 0.0,
    }
    order = torch.randperm(len(bank)).tolist()

    for bank_index in order:
        batch = bank[bank_index]
        images = _augment(args.dataset, batch["images"])
        labels = batch["labels"]
        is_public_anchor = batch.get("source") == "public_anchor"
        is_client_anchor = batch.get("source") == "client_synthetic_anchor"
        with torch.no_grad():
            if "teacher_probabilities" in batch:
                teacher = batch["teacher_probabilities"].to(images.device)
                teacher = teacher / teacher.sum(
                    dim=1,
                    keepdim=True,
                ).clamp_min(1e-8)
                confidence = teacher.max(dim=1).values
                if "quality" in batch:
                    quality = batch["quality"].to(images.device).float()
                    quality = quality.clamp(0.05, 1.0)
                else:
                    quality = confidence
            else:
                route = router(images, labels)
                teacher = route["teacher_probabilities"]
                confidence = teacher.max(dim=1).values
                quality = (
                    route["top_evidence"]
                    / (route["top_evidence"] + args.bicert_min_evidence)
                ) * confidence

        logits = server(images)
        per_sample_kd = _soft_kl(
            logits,
            teacher,
            args.bicert_temperature,
        )
        target_agreement = teacher.argmax(dim=1).eq(labels)
        if is_public_anchor:
            hard_weights = torch.ones_like(quality)
            kd_weights = quality * target_agreement.to(quality.dtype)
        elif is_client_anchor:
            hard_weights = quality
            kd_weights = quality * target_agreement.to(quality.dtype)
        else:
            hard_weights = quality * target_agreement.to(quality.dtype)
            kd_weights = quality
        per_sample_hard = F.cross_entropy(
            logits,
            labels,
            reduction="none",
            label_smoothing=0.05,
        )
        weighted_kd = (
            kd_weights.detach() * per_sample_kd
        ).sum() / kd_weights.sum().clamp_min(1e-6)
        hard_loss = (
            hard_weights.detach() * per_sample_hard
        ).sum() / hard_weights.sum().clamp_min(1e-6)
        robust_losses = (
            kd_scale * per_sample_kd
            + 0.5 * per_sample_hard
        )
        cvar = _class_cvar(
            robust_losses,
            labels,
            num_classes,
            args.bicert_cvar_fraction,
        )
        second_logits = server(_augment(args.dataset, images))
        consistency = _soft_kl(
            second_logits,
            F.softmax(logits.detach(), dim=1),
            1.0,
        ).mean()
        loss = (
            args.uplink_kd * kd_scale * weighted_kd
            + args.bicert_hard_weight * hard_loss
            + args.bicert_cvar_weight * cvar
            + args.bicert_consistency_weight * consistency
        )
        if is_client_anchor:
            loss = loss * float(getattr(args, "bicert_client_anchor_loss_weight", 2.0))

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(
            server.parameters(),
            args.bicert_grad_clip,
        )
        optimizer.step()

        totals["loss"] += float(loss.detach())
        totals["kd"] += float(weighted_kd.detach())
        totals["hard"] += float(hard_loss.detach())
        totals["cvar"] += float(cvar.detach())
        totals["consistency"] += float(consistency.detach())
        totals["quality"] += float(quality.mean().detach())

    return {
        key: value / max(len(bank), 1)
        for key, value in totals.items()
    }


def evaluate_server_proxy(args, server, router, bank):
    server.eval()
    router.eval()
    total_loss = 0.0
    total_agreement = 0
    total_target = 0
    total_examples = 0
    class_loss_sum = {}
    class_count = {}
    with torch.no_grad():
        for batch in bank:
            images = batch["images"]
            labels = batch["labels"]
            if "teacher_probabilities" in batch:
                teacher = batch["teacher_probabilities"].to(images.device)
                teacher = teacher / teacher.sum(
                    dim=1,
                    keepdim=True,
                ).clamp_min(1e-8)
            else:
                route = router(images, labels)
                teacher = route["teacher_probabilities"]
            logits = server(images)
            losses = _soft_kl(
                logits,
                teacher,
                args.bicert_temperature,
            )
            predictions = logits.argmax(dim=1)
            teacher_predictions = teacher.argmax(dim=1)
            total_loss += float(losses.sum())
            total_agreement += int(
                predictions.eq(teacher_predictions).sum()
            )
            total_target += int(predictions.eq(labels).sum())
            total_examples += labels.numel()
            for class_id in labels.unique():
                index = int(class_id)
                mask = labels.eq(index)
                class_loss_sum[index] = (
                    class_loss_sum.get(index, 0.0)
                    + float(losses[mask].sum())
                )
                class_count[index] = (
                    class_count.get(index, 0) + int(mask.sum())
                )
    worst_class_loss = max(
        class_loss_sum[key] / max(class_count[key], 1)
        for key in class_loss_sum
    )
    return {
        "loss": total_loss / max(total_examples, 1),
        "worst_class_loss": worst_class_loss,
        "agreement": 100.0 * total_agreement / max(total_examples, 1),
        "target_acc": 100.0 * total_target / max(total_examples, 1),
    }


def evaluate_query_bank(args, router, bank):
    total = 0
    target_correct = 0
    augmented_correct = 0
    target_confidence = 0.0
    augmented_confidence = 0.0
    evidence = 0.0
    disagreement = 0.0
    with torch.no_grad():
        for batch in bank:
            images = batch["images"]
            labels = batch["labels"]
            if "teacher_probabilities" in batch:
                teacher = batch["teacher_probabilities"].to(images.device)
                teacher = teacher / teacher.sum(
                    dim=1,
                    keepdim=True,
                ).clamp_min(1e-8)
                target_probability = teacher.gather(
                    1,
                    labels[:, None],
                ).squeeze(1)
                target_correct += int(teacher.argmax(dim=1).eq(labels).sum())
                augmented_correct += int(teacher.argmax(dim=1).eq(labels).sum())
                target_confidence += float(target_probability.sum())
                augmented_confidence += float(target_probability.sum())
                if "quality" in batch:
                    evidence += float(batch["quality"].to(images.device).sum())
                else:
                    evidence += float(target_probability.sum())
            else:
                route = router(images, labels)
                augmented = router(_augment(args.dataset, images), labels)
                target_probability = route["teacher_probabilities"].gather(
                    1,
                    labels[:, None],
                ).squeeze(1)
                augmented_probability = (
                    augmented["teacher_probabilities"]
                    .gather(1, labels[:, None])
                    .squeeze(1)
                )
                target_correct += int(
                    route["teacher_probabilities"].argmax(dim=1).eq(labels).sum()
                )
                augmented_correct += int(
                    augmented["teacher_probabilities"]
                    .argmax(dim=1).eq(labels).sum()
                )
                target_confidence += float(target_probability.sum())
                augmented_confidence += float(augmented_probability.sum())
                evidence += float(route["top_evidence"].sum())
                disagreement += float(route["disagreement"].sum())
            total += labels.numel()
    return {
        "target_acc": 100.0 * target_correct / max(total, 1),
        "augmented_target_acc": 100.0 * augmented_correct / max(total, 1),
        "target_confidence": target_confidence / max(total, 1),
        "augmented_confidence": augmented_confidence / max(total, 1),
        "evidence": evidence / max(total, 1),
        "disagreement": disagreement / max(total, 1),
    }


def evaluate_teacher_diagnostics(router, loader):
    """Measure the available client knowledge without selecting checkpoints."""
    router.eval()
    total = 0
    uniform_correct = 0
    owner_correct = 0
    routed_correct = 0
    with torch.no_grad():
        for images, labels in loader:
            device = next(router.parameters()).device
            images = images.to(device)
            labels = labels.to(device).long()
            route = router(images, labels)
            client_probabilities = route["client_probabilities"]
            uniform = client_probabilities.mean(dim=1)
            owner = (
                route["class_prior"].unsqueeze(2)
                * client_probabilities
            ).sum(dim=1)
            routed = route["teacher_probabilities"]
            uniform_correct += int(
                uniform.argmax(dim=1).eq(labels).sum()
            )
            owner_correct += int(owner.argmax(dim=1).eq(labels).sum())
            routed_correct += int(routed.argmax(dim=1).eq(labels).sum())
            total += labels.numel()
    return {
        "uniform": 100.0 * uniform_correct / max(total, 1),
        "class_owner_oracle": 100.0 * owner_correct / max(total, 1),
        "certified_oracle": 100.0 * routed_correct / max(total, 1),
    }


def _proxy_rank(proxy):
    return (
        proxy["target_acc"],
        proxy["agreement"],
        -proxy["loss"],
        -proxy["worst_class_loss"],
    )


def _update_ema(ema_state, model_state, decay):
    for key, value in model_state.items():
        if torch.is_floating_point(value):
            ema_state[key].mul_(decay).add_(
                value.detach(),
                alpha=1.0 - decay,
            )
        else:
            ema_state[key].copy_(value)


def _compute_fisher(model, loader, device, max_batches):
    model.eval()
    fisher = {
        name: torch.zeros_like(parameter, device=device)
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    }
    batches = 0
    for images, labels in loader:
        images = images.to(device)
        labels = labels.to(device).long()
        model.zero_grad(set_to_none=True)
        loss = F.cross_entropy(model(images), labels)
        loss.backward()
        for name, parameter in model.named_parameters():
            if name in fisher and parameter.grad is not None:
                fisher[name] += parameter.grad.detach().square()
        batches += 1
        if batches >= max_batches:
            break
    for name in fisher:
        fisher[name] /= max(batches, 1)
        fisher[name].div_(fisher[name].mean().clamp_min(1e-8))
        fisher[name].clamp_(max=10.0)
    model.zero_grad(set_to_none=True)
    return fisher


def _parameter_trust_loss(model, reference, fisher):
    loss = None
    for name, parameter in model.named_parameters():
        if name not in fisher:
            continue
        value = (
            fisher[name]
            * (parameter - reference[name]).square()
        ).sum()
        loss = value if loss is None else loss + value
    if loss is None:
        return torch.zeros((), device=next(model.parameters()).device)
    return loss


def _sample_bank(bank, batch_size):
    batch = bank[int(torch.randint(0, len(bank), (1,)).item())]
    indices = torch.randint(
        0,
        batch["images"].size(0),
        (batch_size,),
        device=batch["images"].device,
    )
    return batch["images"][indices], batch["labels"][indices]


def _weighted_mean(values, weights):
    weights = weights.detach().float()
    return (values * weights).sum() / weights.sum().clamp_min(1e-6)


def _forward_logits_features(model, images):
    try:
        output = model(images, return_feature=True)
    except TypeError:
        return model(images), None
    if isinstance(output, tuple) and len(output) == 2:
        return output
    return output, None


def _feature_distillation_loss(student_features, teacher_features):
    if student_features is None or teacher_features is None:
        return None
    if student_features.shape != teacher_features.shape:
        return None
    student = F.normalize(student_features.float(), dim=1)
    teacher = F.normalize(teacher_features.float(), dim=1)
    return (student - teacher.detach()).square().sum(dim=1)


def train_safe_downlink_epoch(
    args,
    client,
    original_client,
    server,
    loader,
    optimizer,
    bank,
    fisher,
    reference_parameters,
):
    ablation = str(getattr(args, "bicert_ablation", "a0")).lower()
    fixed_downlink = ablation == "d1_fixed_downlink"
    real_only = ablation == "d2_real_only"
    client.train()
    original_client.eval()
    server.eval()
    totals = {
        "loss": 0.0,
        "ce": 0.0,
        "kd_real": 0.0,
        "kd_synth": 0.0,
        "synth_ce": 0.0,
        "feat": 0.0,
        "preserve": 0.0,
        "trust": 0.0,
        "real_gate": 0.0,
        "synth_gate": 0.0,
        "real_weight": 0.0,
        "synth_weight": 0.0,
    }
    batches = 0
    for images, labels in loader:
        device = next(client.parameters()).device
        images = images.to(device)
        labels = labels.to(device).long()
        with torch.no_grad():
            old_logits = original_client(images)
            server_logits, server_features = _forward_logits_features(
                server,
                images,
            )
            old_loss = F.cross_entropy(
                old_logits,
                labels,
                reduction="none",
            )
            server_loss = F.cross_entropy(
                server_logits,
                labels,
                reduction="none",
            )
            server_confidence = F.softmax(
                server_logits,
                dim=1,
            ).max(dim=1).values
            server_correct = server_logits.argmax(dim=1).eq(labels)
            adaptive_downlink = ablation != "a3_ungated_downlink"
            if not adaptive_downlink or fixed_downlink:
                real_gate = torch.ones_like(server_correct)
                real_weights = torch.ones_like(server_confidence)
            elif int(getattr(args, "bicert_downlink_soft_gate", 1)) == 1:
                advantage = torch.sigmoid(
                    (old_loss - server_loss)
                    / max(float(args.bicert_downlink_margin), 1e-3)
                )
                min_weight = float(
                    getattr(args, "bicert_downlink_min_weight", 0.2)
                )
                real_weights = (
                    server_confidence
                    * server_correct.to(server_confidence.dtype)
                    * (min_weight + (1.0 - min_weight) * advantage)
                )
                real_gate = real_weights.gt(0.01)
            else:
                real_gate = (
                    server_correct
                    & (
                        server_loss + args.bicert_downlink_margin
                        < old_loss
                    )
                    & (
                        server_confidence
                        >= args.bicert_downlink_confidence
                    )
                )
                real_weights = real_gate.to(server_confidence.dtype)

        logits, client_features = _forward_logits_features(client, images)
        ce = F.cross_entropy(logits, labels)
        if real_gate.any():
            kd_real = _weighted_mean(
                _soft_kl(
                    logits,
                    F.softmax(server_logits, dim=1),
                    args.downlink_temperature,
                ),
                real_weights,
            )
        else:
            kd_real = torch.zeros((), device=device)
        feature_real = torch.zeros((), device=device)
        real_feature_losses = _feature_distillation_loss(
            client_features,
            server_features,
        )
        if real_feature_losses is not None and real_gate.any():
            feature_real = _weighted_mean(real_feature_losses, real_weights)
        preserve = _soft_kl(
            logits,
            F.softmax(old_logits, dim=1),
            args.downlink_temperature,
        ).mean()

        replay_steps = (
            0 if real_only else max(
                1,
                int(getattr(args, "bicert_downlink_synth_replay_steps", 1)),
            )
        )
        synthetic_batch_size = max(
            1,
            int(
                round(
                    images.size(0)
                    * float(
                        getattr(
                            args,
                            "bicert_downlink_synth_batch_multiplier",
                            1.0,
                        )
                    )
                )
            ),
        )
        kd_synthetic_total = torch.zeros((), device=device)
        synthetic_ce_total = torch.zeros((), device=device)
        feature_synthetic_total = torch.zeros((), device=device)
        synthetic_gate_total = 0.0
        synthetic_weight_total = 0.0
        for _replay in range(replay_steps):
            synthetic_images, _synthetic_labels = _sample_bank(
                bank,
                synthetic_batch_size,
            )
            synthetic_images = _augment(
                args.dataset,
                synthetic_images,
            )
            with torch.no_grad():
                old_synthetic_logits = original_client(synthetic_images)
                server_synthetic_logits, server_synthetic_features = (
                    _forward_logits_features(server, synthetic_images)
                )
                server_synthetic_probs = F.softmax(
                    server_synthetic_logits,
                    dim=1,
                )
                synthetic_confidence, synthetic_teacher_labels = (
                    server_synthetic_probs.max(dim=1)
                )
                old_synthetic_probs = F.softmax(old_synthetic_logits, dim=1)
                old_teacher_confidence = old_synthetic_probs.gather(
                    1,
                    synthetic_teacher_labels[:, None],
                ).squeeze(1)
                synthetic_gate = synthetic_confidence.ge(
                    float(
                        getattr(
                            args,
                            "bicert_downlink_teacher_confidence",
                            0.35,
                        )
                    )
                )
                if not adaptive_downlink or fixed_downlink:
                    synthetic_gate = torch.ones_like(synthetic_gate)
                    synthetic_weights = torch.ones_like(synthetic_confidence)
                elif int(getattr(args, "bicert_downlink_soft_gate", 1)) == 1:
                    synthetic_weights = synthetic_confidence * torch.sigmoid(
                        (synthetic_confidence - old_teacher_confidence)
                        / max(float(args.bicert_downlink_margin), 1e-3)
                    )
                    synthetic_weights = synthetic_weights * synthetic_gate.to(
                        synthetic_weights.dtype
                    )
                else:
                    synthetic_weights = synthetic_gate.to(
                        synthetic_confidence.dtype
                    )
            synthetic_logits, client_synthetic_features = (
                _forward_logits_features(client, synthetic_images)
            )
            if synthetic_gate.any():
                kd_synthetic_total = kd_synthetic_total + _weighted_mean(
                    _soft_kl(
                        synthetic_logits,
                        server_synthetic_probs,
                        args.downlink_temperature,
                    ),
                    synthetic_weights,
                )
                synthetic_ce_total = synthetic_ce_total + _weighted_mean(
                    F.cross_entropy(
                        synthetic_logits,
                        synthetic_teacher_labels,
                        reduction="none",
                    ),
                    synthetic_weights,
                )
                synthetic_feature_losses = _feature_distillation_loss(
                    client_synthetic_features,
                    server_synthetic_features,
                )
                if synthetic_feature_losses is not None:
                    feature_synthetic_total = (
                        feature_synthetic_total
                        + _weighted_mean(
                            synthetic_feature_losses,
                            synthetic_weights,
                        )
                    )
            synthetic_gate_total += float(synthetic_gate.float().mean())
            synthetic_weight_total += float(synthetic_weights.mean().detach())

        replay_denominator = float(max(replay_steps, 1))
        kd_synthetic = kd_synthetic_total / replay_denominator
        synthetic_ce = synthetic_ce_total / replay_denominator
        feature_synthetic = feature_synthetic_total / replay_denominator
        synthetic_replay_scale = float(
            getattr(
                args,
                "bicert_downlink_synth_replay_loss_scale",
                replay_steps,
            )
        )

        trust = _parameter_trust_loss(
            client,
            reference_parameters,
            fisher,
        )
        loss = (
            args.downlink_ce * ce
            + args.downlink_kd * kd_real
            + synthetic_replay_scale
            * args.bicert_synthetic_kd_weight
            * kd_synthetic
            + synthetic_replay_scale
            * float(
                getattr(args, "bicert_downlink_synth_ce_weight", 1.0)
            )
            * synthetic_ce
            + float(getattr(args, "bicert_downlink_feature_weight", 0.2))
            * (feature_real + synthetic_replay_scale * feature_synthetic)
            + args.bicert_preserve_weight * preserve
            + args.bicert_trust_weight * trust
        )
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(
            client.parameters(),
            args.bicert_grad_clip,
        )
        optimizer.step()

        totals["loss"] += float(loss.detach())
        totals["ce"] += float(ce.detach())
        totals["kd_real"] += float(kd_real.detach())
        totals["kd_synth"] += float(kd_synthetic.detach())
        totals["synth_ce"] += float(synthetic_ce.detach())
        totals["feat"] += float(
            (feature_real + feature_synthetic).detach()
        )
        totals["preserve"] += float(preserve.detach())
        totals["trust"] += float(trust.detach())
        totals["real_gate"] += float(real_gate.float().mean())
        totals["synth_gate"] += synthetic_gate_total / replay_denominator
        totals["real_weight"] += float(real_weights.mean().detach())
        totals["synth_weight"] += synthetic_weight_total / replay_denominator
        batches += 1
    return {
        key: value / max(batches, 1)
        for key, value in totals.items()
    }


def _blend_with_reference(reference, candidate, alpha):
    state = {}
    for key, reference_value in reference.items():
        candidate_value = candidate[key]
        if torch.is_floating_point(reference_value):
            state[key] = (
                (1.0 - alpha) * reference_value
                + alpha * candidate_value
            )
        else:
            state[key] = candidate_value
    return state


def _evaluate_client_downlink_proxy(args, client, server, bank):
    if not bank:
        return {"acc": 0.0, "loss": float("inf"), "kd": float("inf")}
    client_was_training = client.training
    server_was_training = server.training
    client.eval()
    server.eval()
    device = next(client.parameters()).device
    total = 0
    correct = 0
    loss_sum = 0.0
    kd_sum = 0.0
    min_confidence = float(
        getattr(args, "bicert_downlink_teacher_confidence", 0.35)
    )
    with torch.no_grad():
        for batch in bank:
            images = batch["images"].to(device)
            if images.numel() == 0:
                continue
            server_logits = server(images)
            server_probabilities = F.softmax(server_logits, dim=1)
            confidence, teacher_labels = server_probabilities.max(dim=1)
            keep = confidence.ge(min_confidence)
            if not keep.any():
                continue
            logits = client(images)
            kept_logits = logits[keep]
            kept_labels = teacher_labels[keep]
            count = int(keep.sum().item())
            loss_sum += float(
                F.cross_entropy(
                    kept_logits,
                    kept_labels,
                    reduction="sum",
                )
            )
            kd_sum += float(
                _soft_kl(
                    kept_logits,
                    server_probabilities[keep],
                    args.downlink_temperature,
                ).sum()
            )
            correct += int(kept_logits.argmax(dim=1).eq(kept_labels).sum())
            total += count
    if client_was_training:
        client.train()
    if server_was_training:
        server.train()
    return {
        "acc": 100.0 * correct / max(total, 1),
        "loss": loss_sum / max(total, 1),
        "kd": kd_sum / max(total, 1),
    }


def _safe_client_selection_with_proxy(
    args,
    client,
    reference_state,
    candidate_state,
    val_loader,
    proxy_bank,
    server,
    test_fn,
    minimum_gain,
):
    client.load_state_dict(reference_state)
    before_acc, before_loss = test_fn(client, val_loader)
    before_proxy = _evaluate_client_downlink_proxy(
        args,
        client,
        server,
        proxy_bank,
    )
    best_state = copy.deepcopy(reference_state)
    best_acc = before_acc
    best_loss = before_loss
    best_proxy = before_proxy
    best_alpha = 0.0
    proxy_weight = float(getattr(args, "bicert_downlink_proxy_weight", 1.0))
    max_val_drop = float(getattr(args, "bicert_downlink_max_val_drop", 5.0))
    min_proxy_gain = float(
        getattr(args, "bicert_downlink_min_proxy_gain", 0.0)
    )
    # Selection is driven by the GLOBAL proxy (label-free agreement with the
    # server on confident samples), which is aligned with the global test
    # objective. The client's local val_loader is non-IID: a specialist already
    # scores ~90%+ on its own few classes, and absorbing global knowledge MUST
    # lower that local score. Using local val as a hard acceptance gate (the old
    # `val_safe = accuracy >= before_acc - max_val_drop`) therefore rejected
    # every genuinely-globalized candidate (alpha collapsed to 0). We now:
    #   * score candidates almost entirely on proxy accuracy/loss, and
    #   * treat local val as a NON-BLOCKING guard that only matters when the
    #     candidate fails to improve the global proxy at all.
    def _proxy_score(acc, proxy):
        return (
            proxy_weight * proxy["acc"]
            - 0.05 * proxy["loss"]
            + 1e-3 * acc  # tie-break: prefer less local-val damage
        )

    best_score = _proxy_score(before_acc, before_proxy)
    for alpha in [0.10, 0.25, 0.50, 0.75, 1.0]:
        state = _blend_with_reference(
            reference_state,
            candidate_state,
            alpha,
        )
        client.load_state_dict(state)
        accuracy, loss = test_fn(client, val_loader)
        proxy = _evaluate_client_downlink_proxy(
            args,
            client,
            server,
            proxy_bank,
        )
        val_gain = accuracy - before_acc
        proxy_gain = proxy["acc"] - before_proxy["acc"]
        useful = (
            proxy_gain > min_proxy_gain
            or val_gain >= minimum_gain
            or (accuracy >= before_acc and loss < before_loss - 1e-6)
        )
        # Non-blocking guard: a real global-proxy gain is never vetoed by local
        # val. The val drop only matters when there is no proxy gain to justify
        # it, in which case we still require the candidate to stay within
        # max_val_drop of the original.
        val_safe = (proxy_gain > min_proxy_gain) or (
            accuracy >= before_acc - max_val_drop
        )
        score = _proxy_score(accuracy, proxy)
        if val_safe and useful and score > best_score:
            best_state = copy.deepcopy(state)
            best_acc = accuracy
            best_loss = loss
            best_proxy = proxy
            best_alpha = alpha
            best_score = score
    client.load_state_dict(best_state)
    return {
        "state": best_state,
        "before_acc": before_acc,
        "before_loss": before_loss,
        "after_acc": best_acc,
        "after_loss": best_loss,
        "before_proxy": before_proxy,
        "after_proxy": best_proxy,
        "alpha": best_alpha,
        "accepted": best_alpha > 0,
    }


def _safe_client_selection(
    client,
    reference_state,
    candidate_state,
    val_loader,
    test_fn,
    minimum_gain,
):
    client.load_state_dict(reference_state)
    before_acc, before_loss = test_fn(client, val_loader)
    best_state = copy.deepcopy(reference_state)
    best_acc = before_acc
    best_loss = before_loss
    best_alpha = 0.0
    for alpha in [0.25, 0.5, 0.75, 1.0]:
        state = _blend_with_reference(
            reference_state,
            candidate_state,
            alpha,
        )
        client.load_state_dict(state)
        accuracy, loss = test_fn(client, val_loader)
        improves = accuracy >= before_acc + minimum_gain
        ties_safely = (
            accuracy >= before_acc
            and loss < before_loss - 1e-6
        )
        if (
            (improves or ties_safely)
            and (
                accuracy > best_acc
                or (
                    abs(accuracy - best_acc) < 1e-8
                    and loss < best_loss
                )
            )
        ):
            best_state = copy.deepcopy(state)
            best_acc = accuracy
            best_loss = loss
            best_alpha = alpha
    client.load_state_dict(best_state)
    return {
        "state": best_state,
        "before_acc": before_acc,
        "before_loss": before_loss,
        "after_acc": best_acc,
        "after_loss": best_loss,
        "alpha": best_alpha,
        "accepted": best_alpha > 0,
    }


def _cpu_bank(bank):
    cpu_batches = []
    for batch in bank:
        cpu_batch = {}
        for key, value in batch.items():
            if torch.is_tensor(value):
                cpu_batch[key] = value.detach().cpu()
            else:
                cpu_batch[key] = value
        cpu_batches.append(cpu_batch)
    return cpu_batches


def _object_nbytes(value):
    if torch.is_tensor(value):
        return int(value.numel() * value.element_size())
    if isinstance(value, np.ndarray):
        return int(value.nbytes)
    if isinstance(value, dict):
        return sum(_object_nbytes(item) for item in value.values())
    if isinstance(value, (list, tuple)):
        return sum(_object_nbytes(item) for item in value)
    return 0


def _bytes_to_mib(num_bytes):
    return float(num_bytes) / (1024.0 ** 2)


def _communication_breakdown(local_weights, client_certificates, server_state, train_bank, num_clients):
    anchor_keys = {
        "synthetic_anchor_images",
        "synthetic_anchor_labels",
        "synthetic_anchor_logits",
        "synthetic_anchor_scores",
    }
    client_rows = []
    total_uplink = 0
    for index, (state_dict, certificate) in enumerate(zip(local_weights, client_certificates)):
        model_bytes = _object_nbytes(state_dict)
        certificate_core = {
            key: value
            for key, value in certificate.items()
            if key not in anchor_keys
        }
        anchor_payload = {
            key: certificate[key]
            for key in anchor_keys
            if key in certificate
        }
        certificate_bytes = _object_nbytes(certificate_core)
        anchor_bytes = _object_nbytes(anchor_payload)
        uplink_bytes = model_bytes + certificate_bytes + anchor_bytes
        total_uplink += uplink_bytes
        client_rows.append(
            {
                "client_id": index,
                "model_bytes": model_bytes,
                "certificate_bytes": certificate_bytes,
                "anchor_bytes": anchor_bytes,
                "uplink_bytes": uplink_bytes,
            }
        )

    server_model_bytes = _object_nbytes(server_state)
    query_bank_bytes = _object_nbytes(_cpu_bank(train_bank))
    downlink_bytes_per_client = server_model_bytes + query_bank_bytes
    total_downlink = downlink_bytes_per_client * num_clients
    return {
        "client_rows": client_rows,
        "uplink_total_bytes": total_uplink,
        "downlink_per_client_bytes": downlink_bytes_per_client,
        "downlink_total_bytes": total_downlink,
        "server_model_bytes": server_model_bytes,
        "query_bank_bytes": query_bank_bytes,
        "grand_total_bytes": total_uplink + total_downlink,
        "uplink_total_mib": _bytes_to_mib(total_uplink),
        "downlink_per_client_mib": _bytes_to_mib(downlink_bytes_per_client),
        "downlink_total_mib": _bytes_to_mib(total_downlink),
        "server_model_mib": _bytes_to_mib(server_model_bytes),
        "query_bank_mib": _bytes_to_mib(query_bank_bytes),
        "grand_total_mib": _bytes_to_mib(total_uplink + total_downlink),
    }


def run_fedbicert(
    args,
    train_dataset,
    server_eval_loader,
    server_case_loader,
    client_test_loader,
    user_groups,
    client_certificates,
    local_weights,
    client_model_types,
    get_server_model,
    get_client_model,
    build_teacher_models,
    local_update_class,
    test_fn,
):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    num_classes, channels, image_size = _dataset_spec(args.dataset)
    ablation = str(getattr(args, "bicert_ablation", "a0")).lower()
    routing_mode = {
        "a1_model_only": "confidence",
        "a2_uniform": "uniform",
        "a2_class_only": "class_only",
        "a2_class_feature": "class_feature",
        "a2_class_margin": "class_margin",
    }.get(ablation, "certified")
    logger = args.flogger
    swanlab_run = getattr(args, "swanlab_run", None)
    pretrain_effective_rows = list(getattr(args, "pretrain_effective_params", []))
    run_start_time = time.perf_counter()
    communication_round = int(getattr(args, "communication_round", 1))
    communication_rounds = int(getattr(args, "communication_rounds", 1))
    configured_server_init_path = str(
        getattr(args, "fedbicert_server_init_checkpoint", "")
    ).strip()
    previous_communication_histories = []
    previous_cumulative_communication_cost = {
        "uplink_total_mib": 0.0,
        "downlink_total_mib": 0.0,
        "grand_total_mib": 0.0,
    }
    if configured_server_init_path:
        configured_previous_report_path = configured_server_init_path.replace(
            "-fedbicert-server.pth",
            "-fedbicert-report.pth",
        )
        if os.path.isfile(configured_previous_report_path):
            try:
                configured_previous_report = torch.load(
                    configured_previous_report_path,
                    map_location="cpu",
                    weights_only=False,
                )
            except TypeError:
                configured_previous_report = torch.load(
                    configured_previous_report_path,
                    map_location="cpu",
                )
            previous_communication_histories = list(
                configured_previous_report.get(
                    "communication_histories",
                    [],
                )
            )
            previous_cumulative_communication_cost.update(
                configured_previous_report.get(
                    "cumulative_communication_cost",
                    {},
                )
            )
    # The configured offsets already represent the number of training epochs
    # completed by previous communication rounds.  Do not add one extra step
    # per round: only round 1 logs the pre-training baseline at step 0.
    warmup_log_offset = int(
        getattr(args, "bicert_anchor_warmup_epoch_offset", 0)
    )
    downlink_log_offset = int(getattr(args, "downlink_epoch_offset", 0))
    uplink_log_offset = sum(
        len(history.get("uplink_test_acc", []))
        for history in previous_communication_histories
    )
    logger.info(
        "========== FedBiCert V3 bidirectional training "
        f"round {communication_round}/{communication_rounds} =========="
    )
    logger.info(
        f"[FedBiCert][Ablation] mode={ablation} routing={routing_mode}"
    )
    logger.info(
        "[FedBiCert][Protocol] "
        + (
            "model-only uplink"
            if ablation == "a1_model_only"
            else "model, risk-certificate, and synthetic-anchor uplink"
        )
        + "; one server/query-bank downlink in this communication round"
    )
    if ablation != "a1_model_only" and int(args.bicert_use_client_anchors) == 1:
        logger.info(
            "[FedBiCert][AnchorTargets] uploaded_client_logits; "
            "same policy for Full and router ablations"
        )

    if ablation != "a1_model_only":
        for certificate in client_certificates:
            validate_risk_certificate(certificate, num_classes)
    teacher_models = build_teacher_models(
        args,
        local_weights,
        client_model_types,
    )
    teacher_models = [model.to(device).eval() for model in teacher_models]
    router = CertifiedExpertRouter(
        teacher_models,
        None if ablation == "a1_model_only" else client_certificates,
        routing_mode=routing_mode,
        num_classes=num_classes,
        support_temperature=args.bicert_support_temperature,
        margin_temperature=args.bicert_margin_temperature,
        routing_temperature=args.bicert_routing_temperature,
        minimum_evidence=args.bicert_min_evidence,
        ownership_power=args.bicert_ownership_power,
        minimum_class_count=args.bicert_min_class_count,
        support_floor=args.bicert_support_floor,
        reliability_floor=args.bicert_reliability_floor,
        query_floor=args.bicert_query_floor,
        inference_chunk_size=args.bicert_router_chunk_size,
    ).to(device)
    owner_ids = router.class_prior.argmax(dim=0).detach().cpu().tolist()
    owner_weights = router.class_prior.max(dim=0).values.detach().cpu().tolist()
    logger.info(
        f"[FedBiCert][Router] dominant_client_per_class={owner_ids} "
        f"weights={[round(value, 4) for value in owner_weights]}"
    )
    teacher_diagnostics = evaluate_teacher_diagnostics(
        router,
        server_eval_loader,
    )
    logger.info(
        "[FedBiCert][Diagnostic only; never used for selection] "
        f"uniform_ensemble={teacher_diagnostics['uniform']:.4f} "
        f"class_owner_oracle={teacher_diagnostics['class_owner_oracle']:.4f} "
        f"certified_oracle={teacher_diagnostics['certified_oracle']:.4f}"
    )

    server = get_server_model(args).to(device)
    server_init_path = configured_server_init_path
    if server_init_path:
        server_ckpt = torch.load(server_init_path, map_location="cpu")
        server_state = server_ckpt.get(
            "server_model",
            server_ckpt.get("state_dict"),
        )
        if server_state is None:
            raise ValueError(
                f"Server init checkpoint {server_init_path} does not contain "
                "server_model or state_dict."
            )
        server.load_state_dict(server_state)
        logger.info(
            f"[FedBiCert][Uplink] resumed server from {server_init_path}"
        )
    server_initial_state = copy.deepcopy(server.state_dict())
    server_before_acc, server_before_loss = test_fn(server, server_eval_loader)
    logger.info(
        f"[FedBiCert][Uplink] "
        f"{'resumed' if server_init_path else 'independent random'} server | "
        f"test_acc={server_before_acc:.4f} test_loss={server_before_loss:.4f}"
    )

    generator = DualModeQueryGenerator(
        noise_dim=args.nz,
        num_classes=num_classes,
        image_size=image_size,
        channels=channels,
        width=args.bicert_generator_width,
    ).to(device)
    train_bank, proxy_bank, generator_metrics = build_fedbicert_banks(
        args,
        generator,
        router,
        train_dataset,
        client_certificates,
        args.seed + 3109,
        args.seed + 6211,
    )
    if generator_metrics is None:
        generator_metrics = {
            "loss": 0.0,
            "coverage_nll": 0.0,
            "disagreement": 0.0,
            "evidence": 0.0,
            "target_acc": 0.0,
        }
        logger.info(
            "[FedBiCert][Generator] skipped because "
            f"query_source={args.bicert_query_source}"
        )
    else:
        logger.info(
            "[FedBiCert][Generator] "
            + " ".join(
                f"{key}={value:.6f}"
                for key, value in generator_metrics.items()
            )
        )
    source_counts = {}
    for batch in train_bank:
        source = batch.get("source", "generator")
        source_counts[source] = source_counts.get(source, 0) + int(
            batch["labels"].numel()
        )
    logger.info(
        f"[FedBiCert][QuerySource] source="
        f"{'client_anchors_only' if ablation == 'a4_client_only' else args.bicert_query_source} "
        f"public_anchor_per_class={args.bicert_public_anchor_per_class} "
        f"train_examples={source_counts}"
    )
    query_quality = evaluate_query_bank(
        args,
        router,
        proxy_bank,
    )
    logger.info(
        "[FedBiCert][QueryBank] "
        + " ".join(
            f"{key}={value:.6f}"
            for key, value in query_quality.items()
        )
    )

    anchor_train_bank = [
        batch
        for batch in train_bank
        if batch.get("source") == "client_synthetic_anchor"
    ]
    anchor_proxy_bank = [
        batch
        for batch in proxy_bank
        if batch.get("source") == "client_synthetic_anchor"
    ]
    if not anchor_proxy_bank:
        anchor_proxy_bank = anchor_train_bank
    warmup_epochs = int(getattr(args, "bicert_anchor_warmup_epochs", 0))
    if ablation == "a5_no_warmup":
        warmup_epochs = 0
    warmup_start_time = time.perf_counter()
    warmup_elapsed_seconds = 0.0
    warmup_executed_epochs = 0
    warmup_test_history = [float(server_before_acc)]
    if warmup_epochs > 0 and anchor_train_bank:
        if communication_round == 1:
            swanlab_run.log(
                {
                    "server/anchor_warmup/test_acc": float(server_before_acc),
                    "compare/server_warmup_test_acc": float(server_before_acc),
                },
                step=warmup_log_offset,
            )
        warmup_optimizer = torch.optim.AdamW(
            server.parameters(),
            lr=float(getattr(args, "bicert_anchor_warmup_lr", 1e-3)),
            weight_decay=5e-4,
        )
        warmup_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            warmup_optimizer,
            T_max=max(warmup_epochs, 1),
            eta_min=float(getattr(args, "bicert_anchor_warmup_lr", 1e-3)) * 0.05,
        )
        warmup_best_state = copy.deepcopy(server.state_dict())
        warmup_best_proxy = evaluate_server_proxy(
            args,
            server,
            router,
            anchor_proxy_bank,
        )
        logger.info(
            f"[FedBiCert][AnchorWarmup] start | "
            f"train_batches={len(anchor_train_bank)} "
            f"proxy_batches={len(anchor_proxy_bank)} "
            f"epochs={warmup_epochs}"
        )
        for epoch in range(warmup_epochs):
            warmup_executed_epochs = epoch + 1
            train_log = train_server_epoch(
                args,
                server,
                router,
                warmup_optimizer,
                anchor_train_bank,
                kd_scale=min(1.0, float(epoch + 1) / 10.0),
                freeze_bn=False,
            )
            warmup_scheduler.step()
            warmup_proxy = evaluate_server_proxy(
                args,
                server,
                router,
                anchor_proxy_bank,
            )
            if _proxy_rank(warmup_proxy) > _proxy_rank(warmup_best_proxy):
                warmup_best_proxy = warmup_proxy
                warmup_best_state = copy.deepcopy(server.state_dict())
            if (
                epoch == 0
                or epoch + 1 == warmup_epochs
                or (epoch + 1) % 10 == 0
            ):
                logger.info(
                    f"[FedBiCert][AnchorWarmup] Epoch {epoch:03d} | "
                    f"loss={train_log['loss']:.5f} "
                    f"hard={train_log['hard']:.5f} "
                    f"kd={train_log['kd']:.5f} "
                    f"proxy_target={warmup_proxy['target_acc']:.2f} "
                    f"best_target={warmup_best_proxy['target_acc']:.2f}"
                )
            warmup_test_acc, _ = test_fn(server, server_eval_loader)
            warmup_test_history.append(float(warmup_test_acc))
            swanlab_run.log(
                {
                    "server/anchor_warmup/test_acc": float(warmup_test_acc),
                    "compare/server_warmup_test_acc": float(warmup_test_acc),
                },
                step=warmup_log_offset + epoch + 1,
            )
        server.load_state_dict(warmup_best_state)
        warmup_acc, warmup_loss = test_fn(server, server_eval_loader)
        warmup_elapsed_seconds = time.perf_counter() - warmup_start_time
        logger.info(
            f"[FedBiCert][AnchorWarmup] diagnostic test | "
            f"before={server_before_acc:.4f} after={warmup_acc:.4f} "
            f"gain={warmup_acc - server_before_acc:+.4f} "
            f"loss={warmup_loss:.4f}"
        )
    elif warmup_epochs > 0:
        logger.info(
            "[FedBiCert][AnchorWarmup] skipped because no uploaded "
            "client synthetic anchors were available"
        )
        warmup_elapsed_seconds = time.perf_counter() - warmup_start_time

    optimizer = torch.optim.AdamW(
        server.parameters(),
        lr=args.bicert_server_lr,
        weight_decay=5e-4,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=max(args.epochs, 1),
        eta_min=args.bicert_server_lr * 0.05,
    )
    ema_state = copy.deepcopy(server.state_dict())
    best_state = copy.deepcopy(server.state_dict())
    best_proxy = evaluate_server_proxy(
        args,
        server,
        router,
        proxy_bank,
    )
    stale = 0
    last_server_log = None
    uplink_start_time = time.perf_counter()
    uplink_executed_epochs = 0
    uplink_test_history = []

    for epoch in range(args.epochs):
        uplink_executed_epochs = epoch + 1
        if (
            epoch > 0
            and args.bicert_refresh_interval > 0
            and epoch % args.bicert_refresh_interval == 0
        ):
            train_bank, _, refresh_metrics = build_fedbicert_banks(
                args,
                generator,
                router,
                train_dataset,
                client_certificates,
                args.seed + 3109 + epoch,
                args.seed + 6211,
                generator_steps=args.bicert_refresh_steps,
                include_proxy=False,
            )
            if refresh_metrics is not None:
                logger.info(
                    f"[FedBiCert][Generator] refresh={epoch:03d} "
                    f"loss={refresh_metrics['loss']:.6f} "
                    f"evidence={refresh_metrics['evidence']:.6f} "
                    f"disagreement={refresh_metrics['disagreement']:.6f}"
                )
            else:
                logger.info(
                    f"[FedBiCert][QueryBank] refresh={epoch:03d} "
                    f"source={args.bicert_query_source}"
                )
        train_log = train_server_epoch(
            args,
            server,
            router,
            optimizer,
            train_bank,
            kd_scale=min(
                1.0,
                float(epoch + 1)
                / max(args.bicert_kd_warmup_epochs, 1),
            ),
        )
        last_server_log = train_log
        scheduler.step()
        _update_ema(
            ema_state,
            server.state_dict(),
            args.bicert_ema_decay,
        )
        current_state = copy.deepcopy(server.state_dict())
        current_proxy = evaluate_server_proxy(
            args,
            server,
            router,
            proxy_bank,
        )
        server.load_state_dict(ema_state)
        ema_proxy = evaluate_server_proxy(
            args,
            server,
            router,
            proxy_bank,
        )
        if _proxy_rank(current_proxy) >= _proxy_rank(ema_proxy):
            candidate_proxy = current_proxy
            candidate_state = current_state
            candidate_name = "current"
        else:
            candidate_proxy = ema_proxy
            candidate_state = copy.deepcopy(ema_state)
            candidate_name = "ema"
        if _proxy_rank(candidate_proxy) > _proxy_rank(best_proxy):
            best_proxy = candidate_proxy
            best_state = copy.deepcopy(candidate_state)
            stale = 0
        else:
            stale += 1
        server.load_state_dict(current_state)
        logger.info(
            f"[FedBiCert][Uplink] Epoch {epoch:03d} | "
            f"loss={train_log['loss']:.5f} kd={train_log['kd']:.5f} "
            f"hard={train_log['hard']:.5f} cvar={train_log['cvar']:.5f} "
            f"quality={train_log['quality']:.5f} | "
            f"candidate={candidate_name} "
            f"proxy_loss={candidate_proxy['loss']:.5f} "
            f"worst={candidate_proxy['worst_class_loss']:.5f} "
            f"agreement={candidate_proxy['agreement']:.2f} "
            f"target={candidate_proxy['target_acc']:.2f} "
            f"best_target={best_proxy['target_acc']:.2f} "
            f"stale={stale}"
        )
        server_eval_acc, _ = test_fn(server, server_eval_loader)
        uplink_test_history.append(float(server_eval_acc))
        swanlab_run.log(
            {
                "server/uplink/test_acc": float(server_eval_acc),
                "compare/server_distill_test_acc": float(server_eval_acc),
            },
            step=uplink_log_offset + epoch + 1,
        )
        if stale >= args.bicert_patience:
            break

    server.load_state_dict(best_state)
    server_after_acc, server_after_loss = test_fn(server, server_eval_loader)
    uplink_elapsed_seconds = time.perf_counter() - uplink_start_time
    logger.info(
        f"[FedBiCert][Uplink] final test | "
        f"before={server_before_acc:.4f} after={server_after_acc:.4f} "
        f"gain={server_after_acc - server_before_acc:+.4f}"
    )
    server_case_acc = server_after_acc
    server_case_loss = server_after_loss
    if len(server_case_loader.dataset) < len(server_eval_loader.dataset):
        server_case_acc, server_case_loss = test_fn(server, server_case_loader)
        logger.info(
            f"[FedBiCert][FinalCaseTest] sampled_test_acc={server_case_acc:.4f} "
            f"sampled_test_loss={server_case_loss:.4f} "
            f"samples={len(server_case_loader.dataset)}"
        )
        swanlab_run.log(
            {
                "server/final_case_test_acc": float(server_case_acc),
                "compare/server_final_case_test_acc": float(server_case_acc),
            },
            step=uplink_log_offset + uplink_executed_epochs,
        )
    enable_downlink = (
        ablation != "d0_no_downlink"
        and (
            ablation == "a3_ungated_downlink"
            or server_after_acc >= args.bicert_min_downlink_server_acc
        )
    )
    if not enable_downlink:
        real_gate_mode = synthetic_mode = selection_mode = "off"
    else:
        real_gate_mode = "fixed" if ablation == "d1_fixed_downlink" else "adaptive"
        synthetic_mode = (
            "off" if ablation == "d2_real_only"
            else "fixed" if ablation == "d1_fixed_downlink"
            else "adaptive"
        )
        selection_mode = "none" if ablation == "a3_ungated_downlink" else "proxy"
        if ablation == "d3_synthetic_gated":
            synthetic_mode = "candidate_gated_full_vs_real_only"
    logger.info(
        f"[FedBiCert][DownlinkMode] mode={ablation} "
        f"enabled={enable_downlink} real_gate={real_gate_mode} "
        f"synthetic={synthetic_mode} selection={selection_mode}"
    )
    if ablation == "d0_no_downlink":
        logger.info("[FedBiCert][Downlink] disabled by no-downlink ablation")
    elif not enable_downlink:
        logger.info(
            f"[FedBiCert][Downlink] skipped because server accuracy "
            f"{server_after_acc:.4f} < "
            f"{args.bicert_min_downlink_server_acc:.4f}"
        )

    client_before = []
    client_candidate_after = []
    client_after = []
    client_val_before = []
    client_val_after = []
    client_proxy_before = []
    client_proxy_after = []
    client_accepted = []
    client_synthetic_gate_real_only = []
    client_states = []
    client_logs = []
    client_downlink_seconds = []
    client_downlink_epoch_counts = []
    client_downlink_test_histories = []
    downlink_start_time = time.perf_counter()

    for client_index in range(args.num_users):
        client_downlink_start = time.perf_counter()
        local_update = local_update_class(
            args=args,
            dataset=train_dataset,
            idxs=user_groups[client_index],
        )
        client = get_client_model(
            args,
            client_index,
            client_model_types,
        ).to(device)
        client.load_state_dict(local_weights[client_index])
        original_client = copy.deepcopy(client).to(device).eval()
        for parameter in original_client.parameters():
            parameter.requires_grad_(False)
        reference_state = copy.deepcopy(client.state_dict())
        reference_parameters = {
            name: parameter.detach().clone()
            for name, parameter in client.named_parameters()
        }
        before_test_acc, _ = test_fn(client, client_test_loader)
        client_test_history = [float(before_test_acc)]
        if communication_round == 1:
            swanlab_run.log(
                {
                    f"client/downlink_test_acc/client_{client_index}": float(before_test_acc),
                    f"compare/client_downlink_test_acc/client_{client_index}": float(before_test_acc),
                },
                step=downlink_log_offset,
            )
        if not enable_downlink:
            client_before.append(before_test_acc)
            client_candidate_after.append(before_test_acc)
            client_after.append(before_test_acc)
            before_val_acc, _ = test_fn(
                client,
                local_update.val_loader,
            )
            client_val_before.append(before_val_acc)
            client_val_after.append(before_val_acc)
            client_proxy_before.append({"acc": 0.0, "loss": 0.0, "kd": 0.0})
            client_proxy_after.append({"acc": 0.0, "loss": 0.0, "kd": 0.0})
            client_accepted.append(False)
            client_synthetic_gate_real_only.append(False)
            client_states.append(copy.deepcopy(reference_state))
            client_logs.append(None)
            client_downlink_seconds.append(0.0)
            client_downlink_epoch_counts.append(0)
            client_downlink_test_histories.append(client_test_history)
            logger.info(
                f"[FedBiCert][Downlink][Client {client_index}] final | "
                f"accepted=False alpha=0.00 test={before_test_acc:.4f}->"
                f"{before_test_acc:.4f} gain=+0.0000"
            )
            continue
        fisher = _compute_fisher(
            client,
            local_update.train_loader,
            device,
            args.bicert_fisher_batches,
        )
        optimizer_client = torch.optim.AdamW(
            client.parameters(),
            lr=args.downlink_lr,
            weight_decay=5e-4,
        )
        scheduler_client = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer_client,
            T_max=max(args.downlink_epochs, 1),
            eta_min=args.downlink_lr * 0.05,
        )
        last_log = None
        client_epoch_count = 0
        if ablation == "d3_synthetic_gated":
            full_rng_state = torch.get_rng_state()
            full_cuda_rng_state = (
                torch.cuda.get_rng_state_all() if device.type == "cuda" else None
            )
        for epoch in range(args.downlink_epochs):
            client_epoch_count = epoch + 1
            last_log = train_safe_downlink_epoch(
                args,
                client,
                original_client,
                server,
                local_update.train_loader,
                optimizer_client,
                train_bank,
                fisher,
                reference_parameters,
            )
            scheduler_client.step()
            epoch_test_acc, _ = test_fn(client, client_test_loader)
            client_test_history.append(float(epoch_test_acc))
            swanlab_run.log(
                {
                    f"client/downlink_test_acc/client_{client_index}": float(epoch_test_acc),
                    f"compare/client_downlink_test_acc/client_{client_index}": float(epoch_test_acc),
                },
                step=downlink_log_offset + epoch + 1,
            )
            logger.info(
                f"[FedBiCert][Downlink][Client {client_index}] "
                f"Epoch {epoch:02d} | loss={last_log['loss']:.5f} "
                f"ce={last_log['ce']:.5f} kd_real={last_log['kd_real']:.5f} "
                f"kd_synth={last_log['kd_synth']:.5f} "
                f"synth_ce={last_log['synth_ce']:.5f} "
                f"feat={last_log['feat']:.5f} "
                f"preserve={last_log['preserve']:.5f} "
                f"gate_real={last_log['real_gate']:.3f} "
                f"gate_synth={last_log['synth_gate']:.3f} "
                f"w_real={last_log['real_weight']:.3f} "
                f"w_synth={last_log['synth_weight']:.3f}"
            )
        candidate_state = copy.deepcopy(client.state_dict())
        candidate_test_acc, _ = test_fn(client, client_test_loader)
        if ablation == "d3_synthetic_gated":
            full_end_rng_state = torch.get_rng_state()
            full_end_cuda_rng_state = (
                torch.cuda.get_rng_state_all() if device.type == "cuda" else None
            )
            torch.set_rng_state(full_rng_state)
            if full_cuda_rng_state is not None:
                torch.cuda.set_rng_state_all(full_cuda_rng_state)
            client.load_state_dict(reference_state)
            real_only_args = copy.copy(args)
            real_only_args.bicert_ablation = "d2_real_only"
            real_optimizer = torch.optim.AdamW(
                client.parameters(), lr=args.downlink_lr, weight_decay=5e-4,
            )
            real_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                real_optimizer,
                T_max=max(args.downlink_epochs, 1),
                eta_min=args.downlink_lr * 0.05,
            )
            for _epoch in range(args.downlink_epochs):
                train_safe_downlink_epoch(
                    real_only_args, client, original_client, server,
                    local_update.train_loader, real_optimizer, train_bank,
                    fisher, reference_parameters,
                )
                real_scheduler.step()
            real_candidate_state = copy.deepcopy(client.state_dict())
            real_candidate_test_acc, _ = test_fn(client, client_test_loader)
            torch.set_rng_state(full_end_rng_state)
            if full_end_cuda_rng_state is not None:
                torch.cuda.set_rng_state_all(full_end_cuda_rng_state)
        if ablation == "a3_ungated_downlink":
            client.load_state_dict(reference_state)
            before_val_acc, before_val_loss = test_fn(
                client,
                local_update.val_loader,
            )
            before_proxy = _evaluate_client_downlink_proxy(
                args, client, server, proxy_bank
            )
            client.load_state_dict(candidate_state)
            after_val_acc, after_val_loss = test_fn(
                client,
                local_update.val_loader,
            )
            after_proxy = _evaluate_client_downlink_proxy(
                args, client, server, proxy_bank
            )
            selection = {
                "state": copy.deepcopy(candidate_state),
                "before_acc": before_val_acc,
                "before_loss": before_val_loss,
                "after_acc": after_val_acc,
                "after_loss": after_val_loss,
                "before_proxy": before_proxy,
                "after_proxy": after_proxy,
                "alpha": 1.0,
                "accepted": True,
            }
        elif ablation == "d3_synthetic_gated":
            full_selection = _safe_client_selection_with_proxy(
                args, client, reference_state, candidate_state,
                local_update.val_loader, proxy_bank, server, test_fn,
                args.bicert_min_val_gain,
            )
            real_selection = _safe_client_selection_with_proxy(
                args, client, reference_state, real_candidate_state,
                local_update.val_loader, proxy_bank, server, test_fn,
                args.bicert_min_val_gain,
            )
            # Candidate gate: the synthetic branch is suppressed only when the
            # real-only candidate is clearly better on the held-out global
            # proxy, without excessive local-validation damage. Test accuracy
            # is measured for reporting only and never enters this decision.
            choose_real_only = (
                real_selection["after_proxy"]["acc"]
                >= full_selection["after_proxy"]["acc"] + 1.0
                and real_selection["after_acc"]
                >= full_selection["after_acc"]
                - float(args.bicert_downlink_max_val_drop)
            )
            selection = real_selection if choose_real_only else full_selection
            client.load_state_dict(selection["state"])
            client_synthetic_gate_real_only.append(choose_real_only)
            if choose_real_only:
                candidate_test_acc = real_candidate_test_acc
            logger.info(
                f"[FedBiCert][SyntheticGate][Client {client_index}] "
                f"full_proxy={full_selection['after_proxy']['acc']:.4f} "
                f"real_only_proxy={real_selection['after_proxy']['acc']:.4f} "
                f"full_val={full_selection['after_acc']:.4f} "
                f"real_only_val={real_selection['after_acc']:.4f} "
                f"selected={'real_only' if choose_real_only else 'full'}"
            )
        else:
            selection = _safe_client_selection_with_proxy(
                args,
                client,
                reference_state,
                candidate_state,
                local_update.val_loader,
                proxy_bank,
                server,
                test_fn,
                args.bicert_min_val_gain,
            )
        if ablation != "d3_synthetic_gated":
            client_synthetic_gate_real_only.append(False)
        after_test_acc, _ = test_fn(client, client_test_loader)
        client_before.append(before_test_acc)
        client_candidate_after.append(candidate_test_acc)
        client_after.append(after_test_acc)
        client_val_before.append(selection["before_acc"])
        client_val_after.append(selection["after_acc"])
        client_proxy_before.append(selection["before_proxy"])
        client_proxy_after.append(selection["after_proxy"])
        client_accepted.append(selection["accepted"])
        if ablation == "d3_synthetic_gated":
            swanlab_run.log(
                {f"downlink/synthetic_gate_real_only/client_{client_index}":
                 int(client_synthetic_gate_real_only[-1])},
                step=downlink_log_offset + args.downlink_epochs,
            )
        client_states.append(copy.deepcopy(selection["state"]))
        client_logs.append(last_log)
        client_seconds = time.perf_counter() - client_downlink_start
        client_downlink_seconds.append(client_seconds)
        client_downlink_epoch_counts.append(client_epoch_count)
        client_downlink_test_histories.append(client_test_history)
        logger.info(
            f"[FedBiCert][Downlink][Client {client_index}] final | "
            f"accepted={selection['accepted']} alpha={selection['alpha']:.2f} "
            f"val={selection['before_acc']:.4f}->{selection['after_acc']:.4f} "
            f"proxy={selection['before_proxy']['acc']:.2f}->"
            f"{selection['after_proxy']['acc']:.2f} "
            f"candidate_test={candidate_test_acc:.4f} "
            f"test={before_test_acc:.4f}->{after_test_acc:.4f} "
            f"gain={after_test_acc - before_test_acc:+.4f}"
        )

    downlink_elapsed_seconds = time.perf_counter() - downlink_start_time
    client_gain = [
        after - before for before, after in zip(client_before, client_after)
    ]
    candidate_client_gain = [
        after - before
        for before, after in zip(client_before, client_candidate_after)
    ]
    negative_transfer_count = sum(gain < 0.0 for gain in client_gain)
    candidate_negative_transfer_count = sum(
        gain < 0.0 for gain in candidate_client_gain
    )
    negative_transfer_fraction = negative_transfer_count / max(len(client_gain), 1)
    candidate_negative_transfer_fraction = (
        candidate_negative_transfer_count / max(len(candidate_client_gain), 1)
    )
    mean_client_gain = float(np.mean(client_gain)) if client_gain else 0.0
    logger.info(
        "[FedBiCert][DownlinkSummary] "
        f"mean_gain={mean_client_gain:+.4f} "
        f"negative_transfer={negative_transfer_count}/{len(client_gain)} "
        f"fraction={negative_transfer_fraction:.4f} "
        f"candidate_negative_transfer="
        f"{candidate_negative_transfer_count}/{len(candidate_client_gain)}"
    )
    for client_index, (before, candidate, after, gain) in enumerate(
        zip(client_before, client_candidate_after, client_after, client_gain)
    ):
        swanlab_run.log(
            {
                f"downlink/client_before_test_acc/client_{client_index}": float(before),
                f"downlink/client_candidate_test_acc/client_{client_index}": float(candidate),
                f"downlink/client_after_test_acc/client_{client_index}": float(after),
                f"downlink/client_gain_test_acc/client_{client_index}": float(gain),
            },
            step=communication_round,
        )
    swanlab_run.log(
        {
            "downlink/mean_client_gain_test_acc": mean_client_gain,
            "downlink/negative_transfer_fraction": negative_transfer_fraction,
            "downlink/candidate_negative_transfer_fraction": candidate_negative_transfer_fraction,
        },
        step=communication_round,
    )

    os.makedirs("df_ckpt", exist_ok=True)
    server_path = (
        f"df_ckpt/{args.timestr}-fedbicert-server.pth"
    )
    client_path = (
        f"df_ckpt/{args.timestr}-fedbicert-clients.pth"
    )
    report_path = (
        f"df_ckpt/{args.timestr}-fedbicert-report.pth"
    )
    torch.save(
        {
            "server_initial_state": server_initial_state,
            "server_model": best_state,
            "generator": generator.state_dict(),
            "query_bank": _cpu_bank(train_bank),
            "proxy_bank": _cpu_bank(proxy_bank),
            "server_before": server_before_acc,
            "server_after": server_after_acc,
            "server_case_acc": server_case_acc,
            "server_case_loss": server_case_loss,
            "best_proxy": best_proxy,
            "client_model_types": client_model_types,
            "protocol": "segmented_local_train_uplink_distill_downlink",
            "communication_round": communication_round,
            "communication_rounds": communication_rounds,
            "server_init_checkpoint": server_init_path,
            "parameter_copying_used": False,
            "ablation": ablation,
        },
        server_path,
    )
    torch.save(
        {
            "client_models": client_states,
            "client_before": client_before,
            "client_candidate_after": client_candidate_after,
            "client_after": client_after,
            "client_val_before": client_val_before,
            "client_val_after": client_val_after,
            "client_proxy_before": client_proxy_before,
            "client_proxy_after": client_proxy_after,
            "client_accepted": client_accepted,
            "client_model_types": client_model_types,
            "communication_round": communication_round,
            "communication_rounds": communication_rounds,
            "ablation": ablation,
        },
        client_path,
    )
    failures = []
    if server_after_acc <= server_before_acc:
        failures.append("server did not improve after uplink distillation")
    required_server = (
        args.server_target_acc
        if args.server_target_acc > 0
        else args.target_acc
    )
    if server_after_acc <= required_server:
        failures.append(
            f"server accuracy {server_after_acc:.4f} <= {required_server:.4f}"
        )
    if ablation != "d0_no_downlink":
        for index, (before, after) in enumerate(
            zip(client_before, client_after)
        ):
            if after <= before:
                failures.append(
                    f"client {index} did not strictly improve "
                    f"({before:.4f}->{after:.4f})"
                )
            if after <= args.target_acc:
                failures.append(
                    f"client {index} accuracy {after:.4f} <= "
                    f"{args.target_acc:.4f}"
                )
    communicated_certificates = (
        [{} for _ in client_certificates]
        if ablation == "a1_model_only"
        else client_certificates
    )
    communication = _communication_breakdown(
        local_weights,
        communicated_certificates,
        best_state,
        train_bank,
        args.num_users,
    )
    if ablation == "d0_no_downlink":
        communication["downlink_per_client_bytes"] = 0
        communication["downlink_total_bytes"] = 0
        communication["downlink_per_client_mib"] = 0.0
        communication["downlink_total_mib"] = 0.0
        communication["server_model_bytes"] = 0
        communication["query_bank_bytes"] = 0
        communication["server_model_mib"] = 0.0
        communication["query_bank_mib"] = 0.0
        communication["grand_total_bytes"] = communication["uplink_total_bytes"]
        communication["grand_total_mib"] = communication["uplink_total_mib"]
    if client_downlink_epoch_counts:
        downlink_effective = (
            f"min={min(client_downlink_epoch_counts)} "
            f"max={max(client_downlink_epoch_counts)} "
            f"avg={float(np.mean(client_downlink_epoch_counts)):.1f}"
        )
    else:
        downlink_effective = "0"
    runtime_effective_rows = pretrain_effective_rows + [
        [
            "distill",
            "anchor_warmup_epochs",
            str(int(warmup_epochs)),
            str(int(warmup_executed_epochs)),
            (
                "executed warmup epochs; 0 means warmup skipped "
                "because no client anchors were available"
            ),
        ],
        [
            "distill",
            "uplink_epochs",
            str(int(args.epochs)),
            str(int(uplink_executed_epochs)),
            "actual server uplink epochs before patience-based early stop",
        ],
        [
            "distill",
            "bicert_patience",
            str(int(args.bicert_patience)),
            str(int(args.bicert_patience)),
            "early-stop patience threshold used during uplink",
        ],
        [
            "distill",
            "downlink_epochs",
            str(int(args.downlink_epochs)),
            downlink_effective,
            "actual per-client downlink epochs; 0 means downlink skipped",
        ],
        [
            "distill",
            "bicert_min_downlink_server_acc",
            str(float(args.bicert_min_downlink_server_acc)),
            (
                f"enabled={int(enable_downlink)} "
                f"(server_after_acc={float(server_after_acc):.4f})"
            ),
            "downlink requires the server accuracy threshold and is disabled by d0_no_downlink",
        ],
        [
            "distill",
            "refresh_interval",
            str(int(args.bicert_refresh_interval)),
            str(int(args.bicert_refresh_interval)),
            "query-bank refresh interval used in uplink stage",
        ],
    ]
    timing = {
        "warmup_seconds": warmup_elapsed_seconds,
        "uplink_seconds": uplink_elapsed_seconds,
        "downlink_seconds": downlink_elapsed_seconds,
        "total_seconds": time.perf_counter() - run_start_time,
        "client_pretrain_seconds": [
            float(certificate.get("local_train_seconds", 0.0))
            for certificate in client_certificates
        ],
        "client_downlink_seconds": client_downlink_seconds,
    }
    max_downlink_points = max(
        (len(history) for history in client_downlink_test_histories),
        default=0,
    )
    downlink_mean_test_history = []
    for point_index in range(max_downlink_points):
        active_values = [
            history[point_index]
            for history in client_downlink_test_histories
            if point_index < len(history)
        ]
        downlink_mean_test_history.append(
            float(np.mean(active_values)) if active_values else None
        )

    communication_histories = list(previous_communication_histories)
    communication_histories.append(
        {
            "round": communication_round,
            "warmup_test_acc": warmup_test_history,
            "uplink_test_acc": uplink_test_history,
            "downlink_mean_test_acc": downlink_mean_test_history,
        }
    )

    cumulative_communication_cost = {
        "uplink_total_mib": (
            float(previous_cumulative_communication_cost["uplink_total_mib"])
            + float(communication["uplink_total_mib"])
        ),
        "downlink_total_mib": (
            float(previous_cumulative_communication_cost["downlink_total_mib"])
            + float(communication["downlink_total_mib"])
        ),
        "grand_total_mib": (
            float(previous_cumulative_communication_cost["grand_total_mib"])
            + float(communication["grand_total_mib"])
        ),
    }

    report = {
        "method": "FedBiCert-V3",
        "ablation": ablation,
        "communication_round": communication_round,
        "communication_rounds": communication_rounds,
        "local_epoch_offset": int(getattr(args, "local_epoch_offset", 0)),
        "local_segment_epochs": int(getattr(args, "local_ep", 0)),
        "local_total_epochs": int(getattr(args, "local_total_epochs", 0)),
        "server_before": server_before_acc,
        "server_after": server_after_acc,
        "server_gain": server_after_acc - server_before_acc,
        "server_case_acc": server_case_acc,
        "server_case_loss": server_case_loss,
        "server_last_loss": last_server_log,
        "server_proxy": best_proxy,
        "teacher_diagnostics": teacher_diagnostics,
        "generator": generator_metrics,
        "query_bank": query_quality,
        "client_before": client_before,
        "client_candidate_after": client_candidate_after,
        "client_after": client_after,
        "client_gain": client_gain,
        "client_candidate_gain": candidate_client_gain,
        "mean_client_gain": mean_client_gain,
        "negative_transfer_count": negative_transfer_count,
        "negative_transfer_fraction": negative_transfer_fraction,
        "candidate_negative_transfer_count": candidate_negative_transfer_count,
        "candidate_negative_transfer_fraction": candidate_negative_transfer_fraction,
        "client_val_before": client_val_before,
        "client_val_after": client_val_after,
        "client_proxy_before": client_proxy_before,
        "client_proxy_after": client_proxy_after,
        "client_accepted": client_accepted,
        "client_synthetic_gate_real_only": client_synthetic_gate_real_only,
        "client_last_loss": client_logs,
        "client_downlink_seconds": client_downlink_seconds,
        "client_downlink_epoch_counts": client_downlink_epoch_counts,
        "communication_histories": communication_histories,
        "passed": not failures,
        "failures": failures,
        "test_set_used_for_selection": False,
        "parameter_copying_used": False,
        "effective_params_table": runtime_effective_rows,
        "communication_cost": communication,
        "cumulative_communication_cost": cumulative_communication_cost,
        "timing": timing,
        "communication": {
            "uplink": (
                "client model only"
                if ablation == "a1_model_only"
                else "client model, risk certificate, and client-side synthetic anchors"
            ),
            "downlink": (
                "none" if ablation == "d0_no_downlink"
                else "server model and synthetic query bank"
            ),
            "return_uplink": False,
        },
    }
    torch.save(report, report_path)
    logger.info(f"[FedBiCert][Summary] {report}")
    client_upload_labels = [
        f"client_{row['client_id']}"
        for row in communication["client_rows"]
    ]
    swanlab_run.log_bar(
        "cost/uplink_breakdown_mib",
        client_upload_labels,
        {
            "model_upload_mib": [
                round(_bytes_to_mib(row["model_bytes"]), 4)
                for row in communication["client_rows"]
            ],
            "certificate_upload_mib": [
                round(_bytes_to_mib(row["certificate_bytes"]), 4)
                for row in communication["client_rows"]
            ],
            "anchor_upload_mib": [
                round(_bytes_to_mib(row["anchor_bytes"]), 4)
                for row in communication["client_rows"]
            ],
        },
    )
    swanlab_run.log_line(
        "cost/upload_mib",
        client_upload_labels,
        {
            "total_uplink_mib": [
                round(_bytes_to_mib(row["uplink_bytes"]), 4)
                for row in communication["client_rows"]
            ],
        },
    )
    swanlab_run.log(
        {
            "cost/uplink_total_mib": float(
                cumulative_communication_cost["uplink_total_mib"]
            ),
            "compare/upload_MB": float(
                cumulative_communication_cost["uplink_total_mib"]
            ),
        },
        step=communication_round,
    )
    if args.strict_target and failures:
        raise RuntimeError(
            "FedBiCert strict validation failed: "
            + "; ".join(failures)
        )
    return server
